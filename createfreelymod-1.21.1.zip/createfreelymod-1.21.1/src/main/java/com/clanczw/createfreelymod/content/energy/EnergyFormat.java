package com.clanczw.createfreelymod.content.energy;

public final class EnergyFormat {
    private EnergyFormat() {
    }

    public static String format(int value) {
        if (value >= 1_000_000) {
            double m = value / 1_000_000.0;
            return m == Math.rint(m) ? String.format("%.0fM", m) : String.format("%.2fM", m);
        }
        if (value >= 1_000) {
            double k = value / 1_000.0;
            return k == Math.rint(k) ? String.format("%.0fk", k) : String.format("%.1fk", k);
        }
        return Integer.toString(value);
    }
}
