package com.clanczw.createfreelymod.content.jetpack;

import com.clanczw.createfreelymod.CreateFreelyMod;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record JetpackJumpPayload(boolean jumping) implements CustomPacketPayload {
    public static final Type<JetpackJumpPayload> TYPE = new Type<>(
            ResourceLocation.fromNamespaceAndPath(CreateFreelyMod.MOD_ID, "jetpack_jump"));

    public static final StreamCodec<RegistryFriendlyByteBuf, JetpackJumpPayload> STREAM_CODEC =
            StreamCodec.composite(ByteBufCodecs.BOOL, JetpackJumpPayload::jumping, JetpackJumpPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    static void handle(JetpackJumpPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player) {
                JetpackFlight.setHoldingJump(player, payload.jumping());
            }
        });
    }
}
