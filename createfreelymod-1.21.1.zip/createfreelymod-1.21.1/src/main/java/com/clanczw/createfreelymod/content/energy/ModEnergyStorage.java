package com.clanczw.createfreelymod.content.energy;

import org.jetbrains.annotations.Nullable;

import net.neoforged.neoforge.energy.EnergyStorage;

/**
 * 带变更回调的 FE 存储；电容用它在收/放电时立刻同步客户端。
 */
public class ModEnergyStorage extends EnergyStorage {
    private final Runnable onChanged;

    public ModEnergyStorage(int capacity) {
        this(capacity, null);
    }

    public ModEnergyStorage(int capacity, @Nullable Runnable onChanged) {
        super(capacity);
        this.onChanged = onChanged == null ? () -> {
        } : onChanged;
    }

    public void setStoredEnergy(int value) {
        this.energy = Math.max(0, Math.min(capacity, value));
    }

    public void setCapacity(int newCapacity) {
        this.capacity = Math.max(1, newCapacity);
        this.maxReceive = this.capacity;
        this.maxExtract = this.capacity;
        this.energy = Math.min(this.energy, this.capacity);
    }

    @Override
    public int receiveEnergy(int maxReceive, boolean simulate) {
        int accepted = super.receiveEnergy(maxReceive, simulate);
        if (accepted > 0 && !simulate) {
            onChanged.run();
        }
        return accepted;
    }

    @Override
    public int extractEnergy(int maxExtract, boolean simulate) {
        int extracted = super.extractEnergy(maxExtract, simulate);
        if (extracted > 0 && !simulate) {
            onChanged.run();
        }
        return extracted;
    }
}
