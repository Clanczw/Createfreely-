package com.clanczw.createfreelymod.content.energy;

import com.clanczw.createfreelymod.config.CreateFreelyCommonConfig;

import net.neoforged.neoforge.energy.IEnergyStorage;

/**
 * Creative infinite FE source. Transfer is rate-limited so other mods that
 * add/multiply FE amounts do not overflow on {@link Integer#MAX_VALUE}.
 */
public final class CreativeEnergyStorages {
    public static int transferRate() {
        return CreateFreelyCommonConfig.creativeTransferRate();
    }

    public static int emptyCapacity() {
        return CreateFreelyCommonConfig.creativeEmptyCapacity();
    }

    public static final IEnergyStorage FULL = new IEnergyStorage() {
        @Override
        public int receiveEnergy(int maxReceive, boolean simulate) {
            return 0;
        }

        @Override
        public int extractEnergy(int maxExtract, boolean simulate) {
            if (maxExtract <= 0) {
                return 0;
            }
            return Math.min(maxExtract, transferRate());
        }

        @Override
        public int getEnergyStored() {
            return transferRate();
        }

        @Override
        public int getMaxEnergyStored() {
            return transferRate();
        }

        @Override
        public boolean canExtract() {
            return true;
        }

        @Override
        public boolean canReceive() {
            return false;
        }
    };

    private CreativeEnergyStorages() {
    }
}
