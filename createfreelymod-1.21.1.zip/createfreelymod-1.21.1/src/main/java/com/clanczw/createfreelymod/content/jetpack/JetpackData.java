package com.clanczw.createfreelymod.content.jetpack;

import com.clanczw.createfreelymod.config.CreateFreelyCommonConfig;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;

/**
 * 喷气背包 NBT（CustomData）：燃油量 + 飞行模式。
 * <p>
 * <b>思路</b>：新背包默认 0 油，避免创造栏取出即满油；燃油单位与流体 mB 对齐，方便喷口/桶灌注。
 * 热路径尽量只 {@link CustomData#copyTag()} 一次；写入走 {@link CustomData#update}。
 */
public final class JetpackData {
    public static final int BUCKET_FUEL = 1_000;

    private static final String TAG_FUEL = "Fuel";
    private static final String TAG_MODE = "FlightMode";

    private JetpackData() {
    }

    public static int maxFuel() {
        return CreateFreelyCommonConfig.jetpackMaxFuel();
    }

    public static boolean hasFuelInitialized(ItemStack stack) {
        CustomData data = stack.get(DataComponents.CUSTOM_DATA);
        return data != null && data.copyTag().contains(TAG_FUEL);
    }

    /** New packs start empty until refueled. */
    public static void ensureInitialized(ItemStack stack) {
        if (!hasFuelInitialized(stack)) {
            setFuel(stack, 0);
        }
    }

    /**
     * Single-copy snapshot for per-tick flight logic (fuel + mode + init).
     */
    public static State readState(ItemStack stack) {
        CustomData data = stack.get(DataComponents.CUSTOM_DATA);
        if (data == null) {
            return State.UNINITIALIZED;
        }
        CompoundTag tag = data.copyTag();
        if (!tag.contains(TAG_FUEL)) {
            return State.UNINITIALIZED;
        }
        int fuel = Math.clamp(tag.getInt(TAG_FUEL), 0, maxFuel());
        String modeName = tag.getString(TAG_MODE);
        JetpackFlightMode mode = modeName.isEmpty()
                ? JetpackFlightMode.NORMAL
                : JetpackFlightMode.byName(modeName);
        return new State(true, fuel, mode);
    }

    public static int getFuel(ItemStack stack) {
        return readState(stack).fuel();
    }

    public static void setFuel(ItemStack stack, int fuel) {
        int clamped = Math.clamp(fuel, 0, maxFuel());
        CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> tag.putInt(TAG_FUEL, clamped));
    }

    public static boolean consumeFuel(ItemStack stack, int amount) {
        if (amount <= 0) {
            return true;
        }
        State state = readState(stack);
        if (!state.initialized()) {
            setFuel(stack, 0);
            return false;
        }
        if (state.fuel() < amount) {
            return false;
        }
        setFuel(stack, state.fuel() - amount);
        return true;
    }

    public static int addFuel(ItemStack stack, int amount) {
        if (amount <= 0) {
            return 0;
        }
        State state = readState(stack);
        int before = state.initialized() ? state.fuel() : 0;
        int after = Math.min(maxFuel(), before + amount);
        setFuel(stack, after);
        return after - before;
    }

    public static JetpackFlightMode getMode(ItemStack stack) {
        return readState(stack).mode();
    }

    public static void setMode(ItemStack stack, JetpackFlightMode mode) {
        CustomData.update(DataComponents.CUSTOM_DATA, stack,
                tag -> tag.putString(TAG_MODE, mode.getSerializedName()));
    }

    public static JetpackFlightMode cycleMode(ItemStack stack) {
        JetpackFlightMode next = getMode(stack).next();
        setMode(stack, next);
        return next;
    }

    public record State(boolean initialized, int fuel, JetpackFlightMode mode) {
        static final State UNINITIALIZED = new State(false, 0, JetpackFlightMode.NORMAL);
    }
}
