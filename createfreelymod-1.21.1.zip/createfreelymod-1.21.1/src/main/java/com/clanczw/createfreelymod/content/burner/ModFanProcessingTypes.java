package com.clanczw.createfreelymod.content.burner;

import java.util.List;

import org.jetbrains.annotations.Nullable;

import com.clanczw.createfreelymod.CreateFreelyMod;
import com.simibubi.create.api.registry.CreateRegistries;
import com.simibubi.create.content.kinetics.fan.processing.AllFanProcessingTypes;
import com.simibubi.create.content.kinetics.fan.processing.FanProcessingType;

import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Fan catalysts driven by {@link FluidBurnerBlockEntity} contents:
 * water → washing, lava / azure fuel → blasting.
 */
public final class ModFanProcessingTypes {
    public static final DeferredRegister<FanProcessingType> FAN_PROCESSING_TYPES =
            DeferredRegister.create(CreateRegistries.FAN_PROCESSING_TYPE, CreateFreelyMod.MOD_ID);

    public static final DeferredHolder<FanProcessingType, FanProcessingType> FLUID_BURNER_SPLASHING =
            FAN_PROCESSING_TYPES.register("fluid_burner_splashing", FluidBurnerSplashingType::new);

    public static final DeferredHolder<FanProcessingType, FanProcessingType> FLUID_BURNER_BLASTING =
            FAN_PROCESSING_TYPES.register("fluid_burner_blasting", FluidBurnerBlastingType::new);

    public static void register(IEventBus modEventBus) {
        FAN_PROCESSING_TYPES.register(modEventBus);
    }

    private ModFanProcessingTypes() {
    }

    private static final class FluidBurnerSplashingType implements FanProcessingType {
        @Override
        public boolean isValidAt(Level level, BlockPos pos) {
            return level.getBlockEntity(pos) instanceof FluidBurnerBlockEntity be && be.providesSplashing();
        }

        @Override
        public int getPriority() {
            // Slightly above Create's built-in so fluid-burner catalysts win when both valid.
            return AllFanProcessingTypes.SPLASHING.getPriority() + 1;
        }

        @Override
        public boolean canProcess(ItemStack stack, Level level) {
            return AllFanProcessingTypes.SPLASHING.canProcess(stack, level);
        }

        @Override
        @Nullable
        public List<ItemStack> process(ItemStack stack, Level level) {
            return AllFanProcessingTypes.SPLASHING.process(stack, level);
        }

        @Override
        public void spawnProcessingParticles(Level level, Vec3 pos) {
            AllFanProcessingTypes.SPLASHING.spawnProcessingParticles(level, pos);
        }

        @Override
        public void morphAirFlow(AirFlowParticleAccess particleAccess, RandomSource random) {
            AllFanProcessingTypes.SPLASHING.morphAirFlow(particleAccess, random);
        }

        @Override
        public void affectEntity(Entity entity, Level level) {
            AllFanProcessingTypes.SPLASHING.affectEntity(entity, level);
        }
    }

    private static final class FluidBurnerBlastingType implements FanProcessingType {
        @Override
        public boolean isValidAt(Level level, BlockPos pos) {
            return level.getBlockEntity(pos) instanceof FluidBurnerBlockEntity be && be.providesBlasting();
        }

        @Override
        public int getPriority() {
            return AllFanProcessingTypes.BLASTING.getPriority() + 1;
        }

        @Override
        public boolean canProcess(ItemStack stack, Level level) {
            return AllFanProcessingTypes.BLASTING.canProcess(stack, level);
        }

        @Override
        @Nullable
        public List<ItemStack> process(ItemStack stack, Level level) {
            return AllFanProcessingTypes.BLASTING.process(stack, level);
        }

        @Override
        public void spawnProcessingParticles(Level level, Vec3 pos) {
            AllFanProcessingTypes.BLASTING.spawnProcessingParticles(level, pos);
        }

        @Override
        public void morphAirFlow(AirFlowParticleAccess particleAccess, RandomSource random) {
            AllFanProcessingTypes.BLASTING.morphAirFlow(particleAccess, random);
        }

        @Override
        public void affectEntity(Entity entity, Level level) {
            AllFanProcessingTypes.BLASTING.affectEntity(entity, level);
        }
    }
}
