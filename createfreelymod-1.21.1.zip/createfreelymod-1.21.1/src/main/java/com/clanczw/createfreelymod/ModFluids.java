package com.clanczw.createfreelymod;

import java.util.function.Supplier;

import org.joml.Vector3f;

import com.tterrag.registrate.builders.FluidBuilder.FluidTypeFactory;
import com.tterrag.registrate.util.entry.FluidEntry;

import net.createmod.catnip.theme.Color;
import net.minecraft.core.BlockPos;
import net.minecraft.core.dispenser.BlockSource;
import net.minecraft.core.dispenser.DefaultDispenseItemBehavior;
import net.minecraft.core.dispenser.DispenseItemBehavior;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.DispensibleContainerItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.MapColor;

import net.neoforged.neoforge.common.Tags;
import net.neoforged.neoforge.fluids.BaseFlowingFluid;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.FluidType;

/**
 * 天蓝超燃燃料（Azure Fuel）。
 * <p>
 * <b>思路</b>：服务端只注册 FluidType / 流体块 / 桶；贴图与雾效走客户端
 * {@link com.clanczw.createfreelymod.client.AzureFuelClientExtensions}，避免把客户端类拉进公共路径。
 * 桶注册投掷器行为，便于自动化灌注喷气背包 / 烈焰人燃烧室。
 */
public final class ModFluids {
    /** Fog color (~#7EC8E3). Sprites are pre-colored azure. */
    public static final int AZURE_COLOR = 0x7EC8E3;

    public static final FluidEntry<BaseFlowingFluid.Flowing> AZURE_FUEL =
            CreateFreelyMod.REGISTRATE
                    .standardFluid("azure_fuel", AzureFuelType.create(AZURE_COLOR, () -> 1f / 8f))
                    .lang("Super Fuel")
                    .properties(b -> b.viscosity(1500).density(1400))
                    .fluidProperties(p -> p.levelDecreasePerBlock(2)
                            .tickRate(25)
                            .slopeFindDistance(3)
                            .explosionResistance(100f))
                    .source(BaseFlowingFluid.Source::new)
                    .block()
                    .properties(p -> p.mapColor(MapColor.COLOR_LIGHT_BLUE))
                    .build()
                    .bucket()
                    .onRegister(ModFluids::registerFluidDispenseBehavior)
                    .tag(Tags.Items.BUCKETS)
                    .build()
                    .register();

    public static void init() {
    }

    private static final DispenseItemBehavior DEFAULT = new DefaultDispenseItemBehavior();
    private static final DispenseItemBehavior DISPENSE_FLUID = new DefaultDispenseItemBehavior() {
        @Override
        protected ItemStack execute(BlockSource source, ItemStack stack) {
            DispensibleContainerItem container = (DispensibleContainerItem) stack.getItem();
            BlockPos pos = source.pos().relative(source.state().getValue(DispenserBlock.FACING));
            Level level = source.level();
            if (container.emptyContents(null, level, pos, null, stack)) {
                return new ItemStack(Items.BUCKET);
            }
            return DEFAULT.dispense(source, stack);
        }
    };

    private static void registerFluidDispenseBehavior(BucketItem bucket) {
        DispenserBlock.registerBehavior(bucket, DISPENSE_FLUID);
    }

    /** True for flowing or still Super Fuel. */
    public static boolean isAzureFuel(Fluid fluid) {
        return fluid != null
                && (fluid.isSame(AZURE_FUEL.get()) || fluid.isSame(AZURE_FUEL.getSource()));
    }

    public static boolean isAzureFuel(FluidStack stack) {
        return stack != null && !stack.isEmpty() && isAzureFuel(stack.getFluid());
    }

    private ModFluids() {
    }

    /**
     * Server-safe fluid type. Client fog/tint lives in {@code AzureFuelClientExtensions}.
     */
    public static final class AzureFuelType extends FluidType {
        private final ResourceLocation stillTexture;
        private final ResourceLocation flowingTexture;
        private Vector3f fogColor;
        private Supplier<Float> fogDistance;

        public static FluidTypeFactory create(int fogRgb, Supplier<Float> fogDistance) {
            return (properties, still, flowing) -> {
                AzureFuelType type = new AzureFuelType(properties, still, flowing);
                type.fogColor = new Color(fogRgb, false).asVectorF();
                type.fogDistance = fogDistance;
                return type;
            };
        }

        private AzureFuelType(Properties properties, ResourceLocation stillTexture,
                ResourceLocation flowingTexture) {
            super(properties);
            this.stillTexture = stillTexture;
            this.flowingTexture = flowingTexture;
        }

        public ResourceLocation stillTexture() {
            return stillTexture;
        }

        public ResourceLocation flowingTexture() {
            return flowingTexture;
        }

        public Vector3f fogColor() {
            return fogColor;
        }

        public float fogDistanceModifier() {
            return fogDistance.get();
        }
    }
}
