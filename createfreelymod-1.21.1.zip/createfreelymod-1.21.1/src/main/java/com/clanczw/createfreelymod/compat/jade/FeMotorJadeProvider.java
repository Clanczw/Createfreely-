package com.clanczw.createfreelymod.compat.jade;

import com.clanczw.createfreelymod.content.energy.EnergyFormat;
import com.clanczw.createfreelymod.content.kinetics.FeMotorBlockEntity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import snownee.jade.api.BlockAccessor;
import snownee.jade.api.IBlockComponentProvider;
import snownee.jade.api.IServerDataProvider;
import snownee.jade.api.ITooltip;
import snownee.jade.api.config.IPluginConfig;

public enum FeMotorJadeProvider implements IBlockComponentProvider, IServerDataProvider<BlockAccessor> {
    INSTANCE;

    @Override
    public void appendTooltip(ITooltip tooltip, BlockAccessor accessor, IPluginConfig config) {
        CompoundTag data = accessor.getServerData();
        if (!data.contains("Consume") || !data.contains("Energy") || !data.contains("MaxEnergy")
                || !data.contains("Rpm") || !data.contains("Stress")) {
            return;
        }
        tooltip.add(Component.translatable(
                "createfreelymod.jade.consuming",
                EnergyFormat.format(data.getInt("Consume"))));
        if (data.contains("Efficiency")) {
            tooltip.add(Component.translatable(
                    "createfreelymod.jade.efficiency",
                    data.getInt("Efficiency")));
        }
        tooltip.add(Component.translatable(
                "createfreelymod.jade.speed",
                data.getInt("Rpm"),
                data.contains("MaxRpm") ? data.getInt("MaxRpm") : FeMotorBlockEntity.MAX_RPM));
        tooltip.add(Component.translatable(
                "createfreelymod.jade.stress_capacity",
                data.getFloat("Stress")));
        tooltip.add(Component.translatable(
                "createfreelymod.jade.energy",
                EnergyFormat.format(data.getInt("Energy")),
                EnergyFormat.format(data.getInt("MaxEnergy"))));
    }

    @Override
    public void appendServerData(CompoundTag data, BlockAccessor accessor) {
        if (!(accessor.getBlockEntity() instanceof FeMotorBlockEntity be)) {
            return;
        }
        data.putInt("Consume", be.getLastConsumedFe());
        data.putInt("Efficiency", be.getEfficiencyPercent());
        data.putInt("Rpm", be.getGeneratedRpm());
        data.putInt("MaxRpm", be.getMaxRpm());
        data.putFloat("Stress", be.getStressCapacityValue());
        data.putInt("Energy", be.getEnergyStored());
        data.putInt("MaxEnergy", be.getMaxEnergyStored());
    }

    @Override
    public ResourceLocation getUid() {
        return CreateFreelyModJadePlugin.FE_MOTOR;
    }
}
