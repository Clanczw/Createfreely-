package com.clanczw.createfreelymod.content.energy;

import org.jetbrains.annotations.Nullable;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;

/**
 * 电容 / 创造电容共用的 FE NBT 读写与方块更新发包。
 * <p>
 * {@link #markDirty} 只落盘脏标记；客户端视觉同步由方块实体 tick 末尾
 * {@link #flushClientSync} 合并，避免每次收放电都 {@code sendBlockUpdated}。
 */
public final class EnergyBlockSync {
    private EnergyBlockSync() {
    }

    /** Persist dirty; defer client packet to {@link #flushClientSync}. */
    public static void markDirty(BlockEntity be) {
        be.setChanged();
    }

    /** Send one block-entity update packet if the level is server-side. */
    public static void flushClientSync(BlockEntity be) {
        if (be.getLevel() != null && !be.getLevel().isClientSide) {
            be.getLevel().sendBlockUpdated(be.getBlockPos(), be.getBlockState(), be.getBlockState(), 3);
        }
    }

    public static void write(CompoundTag tag, ModEnergyStorage energy) {
        tag.putInt("Energy", energy.getEnergyStored());
    }

    public static void read(CompoundTag tag, ModEnergyStorage energy) {
        energy.setStoredEnergy(tag.getInt("Energy"));
    }

    public static void readPacket(@Nullable CompoundTag tag, ModEnergyStorage energy) {
        if (tag != null) {
            read(tag, energy);
        }
    }

    public static ClientboundBlockEntityDataPacket packet(BlockEntity be) {
        return ClientboundBlockEntityDataPacket.create(be);
    }

    /**
     * Banded energy client sync: edges, ~2% band change, or periodic interval.
     *
     * @return true if the caller should {@code sendData()} and update {@code lastSyncedEnergy}
     */
    public static boolean shouldSyncEnergy(
            int stored, int max, int lastSynced, long gameTime, int intervalTicks, boolean force) {
        if (force) {
            return true;
        }
        if (stored == 0 || stored >= max) {
            return true;
        }
        if (lastSynced == Integer.MIN_VALUE
                || Math.abs(stored - lastSynced) >= Math.max(1, max / 50)) {
            return true;
        }
        return Math.floorMod(gameTime, intervalTicks) == 0;
    }
}
