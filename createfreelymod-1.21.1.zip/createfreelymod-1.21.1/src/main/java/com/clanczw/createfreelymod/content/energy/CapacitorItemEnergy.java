package com.clanczw.createfreelymod.content.energy;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.block.entity.BlockEntityType;

import net.neoforged.neoforge.energy.IEnergyStorage;

public final class CapacitorItemEnergy {
    private static final String ENERGY_KEY = "Energy";

    private CapacitorItemEnergy() {
    }

    public static int getEnergy(ItemStack stack) {
        CustomData data = stack.get(DataComponents.BLOCK_ENTITY_DATA);
        if (data == null) {
            return 0;
        }
        return Math.max(0, data.copyTag().getInt(ENERGY_KEY));
    }

    public static void write(ItemStack stack, int energy, BlockEntityType<?> type) {
        CompoundTag tag = new CompoundTag();
        CustomData existing = stack.get(DataComponents.BLOCK_ENTITY_DATA);
        if (existing != null) {
            tag = existing.copyTag();
        }
        tag.putInt(ENERGY_KEY, Math.max(0, energy));
        BlockItem.setBlockEntityData(stack, type, tag);
    }

    public static IEnergyStorage storage(ItemStack stack, int capacity, @Nullable BlockEntityType<?> type) {
        return new IEnergyStorage() {
            @Override
            public int receiveEnergy(int maxReceive, boolean simulate) {
                if (maxReceive <= 0 || capacity <= 0) {
                    return 0;
                }
                int stored = getEnergy(stack);
                int accepted = Math.min(maxReceive, capacity - stored);
                if (accepted > 0 && !simulate && type != null) {
                    write(stack, stored + accepted, type);
                }
                return accepted;
            }

            @Override
            public int extractEnergy(int maxExtract, boolean simulate) {
                if (maxExtract <= 0) {
                    return 0;
                }
                int stored = getEnergy(stack);
                int extracted = Math.min(maxExtract, stored);
                if (extracted > 0 && !simulate && type != null) {
                    write(stack, stored - extracted, type);
                }
                return extracted;
            }

            @Override
            public int getEnergyStored() {
                return getEnergy(stack);
            }

            @Override
            public int getMaxEnergyStored() {
                return capacity;
            }

            @Override
            public boolean canExtract() {
                return true;
            }

            @Override
            public boolean canReceive() {
                return true;
            }
        };
    }
}
