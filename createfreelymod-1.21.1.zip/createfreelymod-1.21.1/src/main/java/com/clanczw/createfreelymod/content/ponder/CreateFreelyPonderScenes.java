package com.clanczw.createfreelymod.content.ponder;

import com.simibubi.create.foundation.ponder.CreateSceneBuilder;

import net.createmod.catnip.math.Pointing;
import net.createmod.ponder.api.PonderPalette;
import net.createmod.ponder.api.scene.SceneBuilder;
import net.createmod.ponder.api.scene.SceneBuildingUtil;
import net.createmod.ponder.api.scene.Selection;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import com.clanczw.createfreelymod.ModFluids;
import com.clanczw.createfreelymod.ModItems;

/**
 * Storyboards for Create Freely ponder schematics under assets/.../ponder/*.nbt
 */
public final class CreateFreelyPonderScenes {
    private CreateFreelyPonderScenes() {
    }

    public static void stressSink(SceneBuilder builder, SceneBuildingUtil util) {
        CreateSceneBuilder scene = new CreateSceneBuilder(builder);
        scene.title("stress_sink", "Stress Generator");
        scene.configureBasePlate(0, 0, 5);
        scene.showBasePlate();
        scene.idle(10);

        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);

        Selection sink = util.select().position(2, 1, 2);
        Selection shaft = util.select().position(1, 1, 2);
        Selection capacitor = util.select().position(3, 1, 2);
        Selection kinetics = shaft.add(sink);

        scene.overlay().showText(70)
                .text("The Stress Generator turns Create rotation into FE power")
                .attachKeyFrame()
                .pointAt(util.vector().centerOf(2, 1, 2))
                .placeNearTarget();
        scene.idle(80);

        scene.world().setKineticSpeed(kinetics, 64);
        scene.effects().rotationSpeedIndicator(new BlockPos(1, 1, 2));
        scene.overlay().showText(80)
                .text("Needs at least 16 RPM. Tiers: 16-64 → 75%, 64-128 → 80%, 128-256 → 85%")
                .attachKeyFrame()
                .colored(PonderPalette.RED)
                .pointAt(util.vector().topOf(2, 1, 2))
                .placeNearTarget();
        scene.idle(90);

        scene.overlay().showOutlineWithText(capacitor, 80)
                .colored(PonderPalette.GREEN)
                .text("FE is pushed from non-shaft faces into neighbors such as capacitors")
                .attachKeyFrame()
                .pointAt(util.vector().centerOf(3, 1, 2))
                .placeNearTarget();
        scene.idle(90);

        scene.overlay().showText(70)
                .text("At 256 RPM with 85% efficiency it makes about 408 FE/t — tunable in config")
                .independent(20);
        scene.idle(80);
        scene.markAsFinished();
    }

    public static void feMotor(SceneBuilder builder, SceneBuildingUtil util) {
        CreateSceneBuilder scene = new CreateSceneBuilder(builder);
        scene.title("fe_motor", "FE Motor");
        scene.configureBasePlate(0, 0, 5);
        scene.showBasePlate();
        scene.idle(10);

        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);

        Selection motor = util.select().position(2, 1, 2);
        Selection capacitor = util.select().position(1, 1, 2);
        Selection shaft = util.select().position(3, 1, 2);

        scene.overlay().showText(70)
                .text("The FE Motor spends FE to spin a Create shaft")
                .attachKeyFrame()
                .pointAt(util.vector().centerOf(2, 1, 2))
                .placeNearTarget();
        scene.idle(80);

        scene.overlay().showOutlineWithText(capacitor, 80)
                .colored(PonderPalette.BLUE)
                .text("Feed FE into the back face (opposite the shaft)")
                .attachKeyFrame()
                .pointAt(util.vector().centerOf(1, 1, 2))
                .placeNearTarget();
        scene.idle(90);

        scene.world().setKineticSpeed(motor.add(shaft), 64);
        scene.effects().rotationSpeedIndicator(new BlockPos(3, 1, 2));
        scene.overlay().showText(80)
                .text("Speed auto-scales with FE; same efficiency tiers as the Dynamo; stress is 64x RPM")
                .attachKeyFrame()
                .pointAt(util.vector().topOf(2, 1, 2))
                .placeNearTarget();
        scene.idle(90);

        scene.overlay().showText(70)
                .text("Full speed costs about 565 FE/t and provides ~16384 SU (85% tier) — set in config")
                .independent(20);
        scene.idle(80);
        scene.markAsFinished();
    }

    public static void fluidBurner(SceneBuilder builder, SceneBuildingUtil util) {
        CreateSceneBuilder scene = new CreateSceneBuilder(builder);
        scene.title("fluid_burner", "Fluid Burner");
        scene.configureBasePlate(0, 0, 5);
        scene.showBasePlate();
        scene.idle(10);

        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);

        scene.overlay().showText(70)
                .text("The Fluid Burner is a fan catalyst tank — not a heat source by itself")
                .attachKeyFrame()
                .pointAt(util.vector().centerOf(2, 1, 2))
                .placeNearTarget();
        scene.idle(80);

        scene.overlay().showText(80)
                .text("Pipe in water for washing, or lava / Super Fuel for blasting")
                .attachKeyFrame()
                .colored(PonderPalette.BLUE)
                .pointAt(util.vector().topOf(2, 1, 2))
                .placeNearTarget();
        scene.idle(90);

        scene.overlay().showText(70)
                .text("Place it in an Encased Fan air stream to change processing type")
                .independent(20);
        scene.idle(80);
        scene.markAsFinished();
    }

    public static void coalBoiler(SceneBuilder builder, SceneBuildingUtil util) {
        CreateSceneBuilder scene = new CreateSceneBuilder(builder);
        scene.title("coal_boiler", "Thermal Boiler");
        scene.configureBasePlate(0, 0, 5);
        scene.showBasePlate();
        scene.idle(10);

        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);

        Selection boiler = util.select().position(2, 1, 2);
        Selection shaft = util.select().position(3, 1, 2);
        BlockPos boilerPos = new BlockPos(2, 1, 2);

        scene.overlay().showText(70)
                .text("The Thermal Boiler burns fuel to spin a Create shaft — no water tanks or steam engines")
                .attachKeyFrame()
                .pointAt(util.vector().centerOf(boilerPos))
                .placeNearTarget();
        scene.idle(80);

        scene.overlay().showOutlineWithText(shaft, 80)
                .colored(PonderPalette.GREEN)
                .text("Front is the furnace face; the shaft attaches on the back")
                .attachKeyFrame()
                .pointAt(util.vector().centerOf(3, 1, 2))
                .placeNearTarget();
        scene.idle(90);

        ItemStack coal = new ItemStack(Items.COAL);
        ItemStack lavaBucket = new ItemStack(Items.LAVA_BUCKET);
        scene.overlay().showControls(util.vector().topOf(boilerPos), Pointing.DOWN, 50).withItem(coal);
        scene.overlay().showControls(util.vector().blockSurface(boilerPos, Direction.NORTH), Pointing.RIGHT, 50)
                .withItem(lavaBucket);
        scene.overlay().showText(90)
                .text("Solid furnace fuels in the GUI, or pipe lava / Super Fuel into any face except the shaft")
                .attachKeyFrame()
                .colored(PonderPalette.BLUE)
                .pointAt(util.vector().topOf(boilerPos))
                .placeNearTarget();
        scene.idle(100);

        scene.world().setKineticSpeed(boiler.add(shaft), 32);
        scene.effects().rotationSpeedIndicator(new BlockPos(3, 1, 2));
        scene.overlay().showText(90)
                .text("Defaults: solid 16 RPM, lava 32 RPM, Super Fuel 128 RPM — stress scales with speed")
                .attachKeyFrame()
                .colored(PonderPalette.RED)
                .pointAt(util.vector().topOf(boilerPos))
                .placeNearTarget();
        scene.idle(100);

        scene.overlay().showText(70)
                .text("Fluid burns in full 1000 mB charges; tiers are tunable in config")
                .independent(20);
        scene.idle(80);
        scene.markAsFinished();
    }

    public static void capacitor(SceneBuilder builder, SceneBuildingUtil util) {
        CreateSceneBuilder scene = new CreateSceneBuilder(builder);
        scene.title("capacitor", "FE Capacitors");
        scene.configureBasePlate(0, 0, 5);
        scene.showBasePlate();
        scene.idle(10);

        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);

        Selection caps = util.select().fromTo(1, 1, 2, 3, 1, 2);
        scene.overlay().showOutlineWithText(caps, 80)
                .colored(PonderPalette.GREEN)
                .text("Low / Medium / High capacitors store FE and push it to neighbors")
                .attachKeyFrame()
                .pointAt(util.vector().centerOf(2, 1, 2))
                .placeNearTarget();
        scene.idle(90);

        scene.overlay().showText(70)
                .text("Breaking or middle-clicking keeps stored energy on the item")
                .attachKeyFrame()
                .independent(20);
        scene.idle(80);
        scene.markAsFinished();
    }

    public static void fuelJetpack(SceneBuilder builder, SceneBuildingUtil util) {
        CreateSceneBuilder scene = new CreateSceneBuilder(builder);
        scene.title("fuel_jetpack", "Fuel Jetpack");
        scene.configureBasePlate(0, 0, 5);
        scene.showBasePlate();
        scene.idle(10);

        BlockPos depotPos = new BlockPos(2, 1, 2);
        BlockPos spoutPos = new BlockPos(2, 2, 2);
        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);

        ItemStack jetpack = new ItemStack(ModItems.FUEL_JETPACK.get());
        scene.world().createItemOnBeltLike(depotPos, Direction.NORTH, jetpack);
        scene.overlay().showControls(util.vector().topOf(depotPos), Pointing.DOWN, 50).withItem(jetpack);
        scene.overlay().showText(70)
                .text("Wear the Fuel Jetpack as a chestplate (or Curios back slot)")
                .attachKeyFrame()
                .pointAt(util.vector().topOf(depotPos))
                .placeNearTarget();
        scene.idle(80);

        ItemStack fuelBucket = new ItemStack(ModFluids.AZURE_FUEL.getBucket().get());
        scene.overlay().showControls(util.vector().blockSurface(spoutPos, Direction.WEST), Pointing.RIGHT, 60)
                .withItem(fuelBucket);
        scene.overlay().showOutlineWithText(util.select().fromTo(2, 1, 2, 2, 2, 2), 80)
                .colored(PonderPalette.BLUE)
                .text("Refuel with a Super Fuel bucket, or drip Super Fuel from a Spout onto a Depot")
                .attachKeyFrame()
                .pointAt(util.vector().centerOf(spoutPos))
                .placeNearTarget();
        scene.idle(90);

        scene.overlay().showText(80)
                .text("Thrust: hold Space to climb. Hover: creative-like flight. Switch with V or sneak-use")
                .attachKeyFrame()
                .colored(PonderPalette.GREEN)
                .independent(20);
        scene.idle(90);

        scene.overlay().showText(70)
                .text("The corner dial shows speed, fuel, and mode while worn")
                .independent(40);
        scene.idle(80);
        scene.markAsFinished();
    }
}
