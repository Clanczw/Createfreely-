package com.clanczw.createfreelymod.client;

import com.clanczw.createfreelymod.CreateFreelyMod;
import com.clanczw.createfreelymod.content.jetpack.JetpackFlight;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

/**
 * 手写喷气背包护甲模型。
 * idle：隐藏火焰；flight：推进器微抖 + 火焰缩放摆动。
 */
public class FuelJetpackModel extends HumanoidModel<LivingEntity> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(CreateFreelyMod.MOD_ID, "fuel_jetpack"), "main");
    /** 与 {@link com.clanczw.createfreelymod.ModArmorMaterials#FUEL_JETPACK} 护甲层贴图一致。 */
    public static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(CreateFreelyMod.MOD_ID, "textures/models/armor/fuel_jetpack_layer_1.png");

    private final ModelPart jetpack;
    private final ModelPart thrusterLeft;
    private final ModelPart thrusterRight;
    private final ModelPart flameLeft;
    private final ModelPart flameRight;

    private final float jetpackRestY;
    private final float thrusterLeftRestY;
    private final float thrusterRightRestY;
    private final float flameLeftRestY;
    private final float flameRightRestY;

    public FuelJetpackModel(ModelPart root) {
        super(root);
        this.jetpack = this.body.getChild("jetpack");
        this.thrusterLeft = this.jetpack.getChild("thruster_left");
        this.thrusterRight = this.jetpack.getChild("thruster_right");
        this.flameLeft = this.thrusterLeft.getChild("nozzle_left").getChild("flame_left");
        this.flameRight = this.thrusterRight.getChild("nozzle_right").getChild("flame_right");
        this.jetpackRestY = this.jetpack.y;
        this.thrusterLeftRestY = this.thrusterLeft.y;
        this.thrusterRightRestY = this.thrusterRight.y;
        this.flameLeftRestY = this.flameLeft.y;
        this.flameRightRestY = this.flameRight.y;
    }

    /** 为胸甲 / Curios 渲染准备可见部件。 */
    public void prepareForRender() {
        setAllVisible(false);
        this.body.visible = true;
    }

    public void applyJetpackAnimation(LivingEntity entity, ItemStack stack, float ageInTicks) {
        resetAnimatedParts();
        if (!JetpackFlight.isJetting(entity, stack)) {
            this.flameLeft.visible = false;
            this.flameRight.visible = false;
            return;
        }

        // flight 周期约 8 tick
        float cycle = (ageInTicks % 8.0F) / 8.0F;
        float bob = Mth.sin(cycle * Mth.PI);
        float sway = Mth.sin(cycle * Mth.TWO_PI);

        this.jetpack.y = this.jetpackRestY - bob * 0.12F;
        this.thrusterLeft.y = this.thrusterLeftRestY - bob * 0.25F;
        this.thrusterRight.y = this.thrusterRightRestY - bob * 0.25F;

        float flameScaleXZ = 1.0F + 0.15F * sway;
        float flameScaleY = 1.55F + 0.4F * bob;
        applyFlame(this.flameLeft, this.flameLeftRestY, flameScaleXZ, flameScaleY, bob, -3.0F + 6.0F * bob);
        applyFlame(this.flameRight, this.flameRightRestY, flameScaleXZ, flameScaleY, bob, 3.0F - 6.0F * bob);
    }

    private static void applyFlame(ModelPart flame, float restY, float scaleXZ, float scaleY, float bob, float zRotDeg) {
        flame.xScale = scaleXZ;
        flame.yScale = scaleY;
        flame.zScale = scaleXZ;
        flame.y = restY + bob * 0.7F;
        flame.zRot = zRotDeg * Mth.DEG_TO_RAD;
    }

    private void resetAnimatedParts() {
        this.jetpack.y = this.jetpackRestY;
        this.thrusterLeft.y = this.thrusterLeftRestY;
        this.thrusterRight.y = this.thrusterRightRestY;
        this.flameLeft.y = this.flameLeftRestY;
        this.flameRight.y = this.flameRightRestY;
        this.flameLeft.xScale = this.flameLeft.yScale = this.flameLeft.zScale = 1.0F;
        this.flameRight.xScale = this.flameRight.yScale = this.flameRight.zScale = 1.0F;
        this.flameLeft.zRot = 0.0F;
        this.flameRight.zRot = 0.0F;
        this.flameLeft.visible = true;
        this.flameRight.visible = true;
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition body = root.addOrReplaceChild("body", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("right_arm", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("left_arm", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("right_leg", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("left_leg", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition jetpack = body.addOrReplaceChild("jetpack",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-5.5F, -5.0F, 0.2F, 11.0F, 12.5F, 5.2F)
                        .texOffs(0, 0).addBox(-5.8F, -5.8F, 0.0F, 11.6F, 1.2F, 5.6F)
                        .texOffs(0, 0).addBox(-5.8F, 7.3F, 0.0F, 11.6F, 0.9F, 5.6F)
                        .texOffs(24, 48).addBox(-6.0F, -4.5F, 0.5F, 0.6F, 12.0F, 4.6F)
                        .texOffs(24, 48).addBox(5.4F, -4.5F, 0.5F, 0.6F, 12.0F, 4.6F)
                        .texOffs(52, 48).addBox(-4.8F, -3.0F, 5.2F, 9.6F, 9.0F, 0.45F)
                        .texOffs(16, 40).addBox(-2.2F, -0.5F, 5.5F, 4.4F, 4.0F, 0.4F)
                , PartPose.offset(0.0F, 4.0F, 2.0F));
        PartDefinition harness = jetpack.addOrReplaceChild("harness",
                CubeListBuilder.create()
                        .texOffs(40, 38).addBox(-5.0F, -5.0F, 1.4F, 10.0F, 1.8F, 1.0F)
                        .texOffs(40, 38).addBox(-4.5F, 5.6F, -2.6F, 9.0F, 1.8F, 1.0F)
                        .texOffs(40, 38).addBox(-4.5F, 5.6F, 1.4F, 9.0F, 1.8F, 0.4F)
                        .texOffs(40, 38).addBox(3.4F, 5.6F, -2.4F, 1.4F, 1.8F, 4.4F)
                        .texOffs(40, 38).addBox(-4.8F, 5.6F, -2.4F, 1.4F, 1.8F, 4.4F)
                        .texOffs(40, 42).addBox(-1.4F, 1.4F, -3.4F, 2.8F, 2.8F, 1.0F)
                        .texOffs(24, 48).addBox(2.6F, -3.4F, 1.1F, 2.6F, 3.4F, 0.7F)
                        .texOffs(24, 48).addBox(-5.2F, -3.4F, 1.1F, 2.6F, 3.4F, 0.7F)
                , PartPose.offset(0.0F, 0.0F, -2.0F));
        harness.addOrReplaceChild("strap_left",
                CubeListBuilder.create()
                        .texOffs(40, 38).addBox(-0.9F, -1.6F, 0.0F, 1.8F, 2.6F, 2.2F)
                        .texOffs(40, 38).addBox(-0.9F, -2.6F, -2.3F, 1.8F, 1.4F, 5.0F)
                        .texOffs(40, 38).addBox(-0.9F, -1.4F, -2.8F, 1.8F, 9.0F, 1.0F)
                , PartPose.offset(4.0F, -2.0F, 0.0F));
        harness.addOrReplaceChild("strap_right",
                CubeListBuilder.create()
                        .texOffs(40, 38).addBox(-0.9F, -1.6F, 0.0F, 1.8F, 2.6F, 2.2F)
                        .texOffs(40, 38).addBox(-0.9F, -2.6F, -2.3F, 1.8F, 1.4F, 5.0F)
                        .texOffs(40, 38).addBox(-0.9F, -1.4F, -2.8F, 1.8F, 9.0F, 1.0F)
                , PartPose.offset(-4.0F, -2.0F, 0.0F));
        jetpack.addOrReplaceChild("top_valve",
                CubeListBuilder.create()
                        .texOffs(0, 40).addBox(-2.0F, 0.3F, -1.6F, 4.0F, 1.2F, 3.6F)
                        .texOffs(0, 40).addBox(-1.2F, -0.9F, -0.8F, 2.4F, 1.4F, 2.2F)
                        .texOffs(8, 48).addBox(-0.5F, -1.6F, -0.2F, 1.0F, 0.9F, 1.0F)
                , PartPose.offset(0.0F, -7.0F, 3.0F));
        jetpack.addOrReplaceChild("fuel_gauge",
                CubeListBuilder.create()
                        .texOffs(16, 40).addBox(-1.6F, -1.6F, -0.65F, 3.2F, 2.8F, 0.7F)
                , PartPose.offset(0.0F, -1.0F, 6.2F));
        jetpack.addOrReplaceChild("tank_left",
                CubeListBuilder.create()
                        .texOffs(36, 0).addBox(-1.9F, -4.8F, -2.0F, 4.0F, 10.0F, 4.0F)
                        .texOffs(24, 48).addBox(-2.0F, 4.7F, -2.1F, 4.2F, 0.8F, 4.2F)
                        .texOffs(24, 48).addBox(-2.0F, -5.3F, -2.1F, 4.2F, 0.9F, 4.2F)
                        .texOffs(16, 48).addBox(-1.5F, -2.6F, 1.85F, 3.2F, 6.4F, 0.25F)
                        .texOffs(16, 48).addBox(1.95F, -2.6F, -1.6F, 0.25F, 6.4F, 3.2F)
                , PartPose.offset(8.0F, 1.0F, 3.0F));
        jetpack.addOrReplaceChild("tank_right",
                CubeListBuilder.create()
                        .texOffs(36, 0).addBox(-2.1F, -4.8F, -2.0F, 4.0F, 10.0F, 4.0F)
                        .texOffs(24, 48).addBox(-2.2F, 4.7F, -2.1F, 4.2F, 0.8F, 4.2F)
                        .texOffs(24, 48).addBox(-2.2F, -5.3F, -2.1F, 4.2F, 0.9F, 4.2F)
                        .texOffs(16, 48).addBox(-1.7F, -2.6F, 1.85F, 3.2F, 6.4F, 0.25F)
                        .texOffs(16, 48).addBox(-2.2F, -2.6F, -1.6F, 0.25F, 6.4F, 3.2F)
                , PartPose.offset(-8.0F, 1.0F, 3.0F));
        jetpack.addOrReplaceChild("pipe_frame",
                CubeListBuilder.create()
                        .texOffs(0, 48).addBox(-5.7F, -5.85F, 2.2F, 11.4F, 0.65F, 0.65F)
                        .texOffs(0, 48).addBox(-5.7F, 5.95F, 2.2F, 11.4F, 0.65F, 0.65F)
                        .texOffs(0, 48).addBox(-5.75F, -5.2F, 2.2F, 0.65F, 11.2F, 0.65F)
                        .texOffs(0, 48).addBox(5.1F, -5.2F, 2.2F, 0.65F, 11.2F, 0.65F)
                        .texOffs(8, 48).addBox(5.4F, -0.6F, -0.6F, 1.0F, 1.0F, 1.0F)
                        .texOffs(8, 48).addBox(-6.4F, -0.6F, -0.6F, 1.0F, 1.0F, 1.0F)
                        .texOffs(8, 48).addBox(-6.0F, -6.0F, 2.0F, 1.2F, 1.2F, 1.2F)
                        .texOffs(8, 48).addBox(4.8F, -6.0F, 2.0F, 1.2F, 1.2F, 1.2F)
                , PartPose.offset(0.0F, 1.0F, 3.0F));
        PartDefinition thruster_left = jetpack.addOrReplaceChild("thruster_left",
                CubeListBuilder.create()
                        .texOffs(52, 48).addBox(-2.1F, -2.25F, -2.6F, 4.2F, 0.55F, 5.2F)
                        .texOffs(0, 22).addBox(-1.8F, -1.8F, -2.2F, 3.6F, 3.5F, 4.4F)
                        .texOffs(24, 48).addBox(-1.5F, 1.65F, -1.9F, 3.0F, 0.55F, 3.8F)
                , PartPose.offset(4.0F, 10.3F, 3.0F));
        PartDefinition nozzle_left = thruster_left.addOrReplaceChild("nozzle_left",
                CubeListBuilder.create()
                        .texOffs(26, 22).addBox(-1.3F, -1.05F, -1.3F, 2.6F, 2.2F, 2.6F)
                        .texOffs(40, 48).addBox(-1.0F, 1.1F, -1.0F, 2.0F, 0.45F, 2.0F)
                , PartPose.offset(0.0F, 3.25F, 0.0F));
        nozzle_left.addOrReplaceChild("flame_left",
                CubeListBuilder.create()
                        .texOffs(48, 16).addBox(-1.2F, -1.35F, -1.2F, 2.4F, 3.0F, 2.4F)
                        .texOffs(48, 16).addBox(-0.9F, 0.95F, -0.9F, 1.8F, 2.2F, 1.8F)
                        .texOffs(52, 20).addBox(-0.6F, 2.75F, -0.6F, 1.2F, 1.6F, 1.2F)
                , PartPose.offset(0.0F, 3.6F, 0.0F));
        PartDefinition thruster_right = jetpack.addOrReplaceChild("thruster_right",
                CubeListBuilder.create()
                        .texOffs(52, 48).addBox(-2.1F, -2.25F, -2.6F, 4.2F, 0.55F, 5.2F)
                        .texOffs(0, 22).addBox(-1.8F, -1.8F, -2.2F, 3.6F, 3.5F, 4.4F)
                        .texOffs(24, 48).addBox(-1.5F, 1.65F, -1.9F, 3.0F, 0.55F, 3.8F)
                , PartPose.offset(-4.0F, 10.3F, 3.0F));
        PartDefinition nozzle_right = thruster_right.addOrReplaceChild("nozzle_right",
                CubeListBuilder.create()
                        .texOffs(26, 22).addBox(-1.3F, -1.05F, -1.3F, 2.6F, 2.2F, 2.6F)
                        .texOffs(40, 48).addBox(-1.0F, 1.1F, -1.0F, 2.0F, 0.45F, 2.0F)
                , PartPose.offset(0.0F, 3.25F, 0.0F));
        nozzle_right.addOrReplaceChild("flame_right",
                CubeListBuilder.create()
                        .texOffs(48, 16).addBox(-1.2F, -1.35F, -1.2F, 2.4F, 3.0F, 2.4F)
                        .texOffs(48, 16).addBox(-0.9F, 0.95F, -0.9F, 1.8F, 2.2F, 1.8F)
                        .texOffs(52, 20).addBox(-0.6F, 2.75F, -0.6F, 1.2F, 1.6F, 1.2F)
                , PartPose.offset(0.0F, 3.6F, 0.0F));
        jetpack.addOrReplaceChild("warning_band",
                CubeListBuilder.create()
                        .texOffs(36, 16).addBox(-4.2F, -0.3F, -0.45F, 8.4F, 0.8F, 0.25F)
                , PartPose.offset(0.0F, 6.5F, 6.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }
}

