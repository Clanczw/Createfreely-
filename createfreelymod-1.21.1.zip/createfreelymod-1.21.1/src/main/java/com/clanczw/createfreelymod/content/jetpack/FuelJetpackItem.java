package com.clanczw.createfreelymod.content.jetpack;

import java.util.List;

import com.clanczw.createfreelymod.ModFluids;
import com.clanczw.createfreelymod.compat.curios.JetpackCurios;

import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * 天蓝燃料喷气背包（胸甲 + 可选 Curios 背饰）。
 * <p>
 * 加油：手持超级燃料桶右键（穿戴中 / 另一只手的背包），或手持背包对另一只手的桶右键。
 * 潜行右键切换模式。{@link #getWorn} 优先胸甲，其次 Curios 背饰。
 */
public class FuelJetpackItem extends ArmorItem {
    public FuelJetpackItem(Holder<ArmorMaterial> material, Properties properties) {
        super(material, Type.CHESTPLATE, properties);
    }

    @Override
    public ItemStack getDefaultInstance() {
        ItemStack stack = super.getDefaultInstance();
        JetpackData.setFuel(stack, 0);
        return stack;
    }

    public static boolean isJetpack(ItemStack stack) {
        return stack.getItem() instanceof FuelJetpackItem;
    }

    public static boolean isWornAsChest(LivingEntity entity) {
        return isJetpack(entity.getItemBySlot(EquipmentSlot.CHEST));
    }

    /**
     * 当前生效的喷气背包：胸甲优先，否则查 Curios 背饰（无 Curios 时仅胸甲）。
     */
    public static ItemStack getWorn(LivingEntity entity) {
        ItemStack chest = entity.getItemBySlot(EquipmentSlot.CHEST);
        if (isJetpack(chest)) {
            return chest;
        }
        return JetpackCurios.findJetpack(entity);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        ItemStack other = player.getItemInHand(hand == InteractionHand.MAIN_HAND
                ? InteractionHand.OFF_HAND
                : InteractionHand.MAIN_HAND);

        if (tryRefuel(player, stack, other)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }

        if (player.isShiftKeyDown()) {
            if (!level.isClientSide()) {
                JetpackData.cycleMode(stack);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }

        return super.use(level, player, hand);
    }

    public static boolean tryRefuel(Player player, ItemStack jetpack, ItemStack fluidSource) {
        if (!isJetpack(jetpack) || fluidSource.isEmpty()) {
            return false;
        }
        if (ModFluids.AZURE_FUEL.getBucket().isEmpty()
                || !fluidSource.is(ModFluids.AZURE_FUEL.getBucket().get())) {
            return false;
        }
        if (JetpackData.getFuel(jetpack) >= JetpackData.maxFuel()) {
            return false;
        }
        if (!player.level().isClientSide()) {
            JetpackData.addFuel(jetpack, JetpackData.BUCKET_FUEL);
            if (!player.getAbilities().instabuild) {
                fluidSource.shrink(1);
                ItemStack empty = new ItemStack(Items.BUCKET);
                if (!player.getInventory().add(empty)) {
                    player.drop(empty, false);
                }
            }
            player.displayClientMessage(Component.translatable(
                    "createfreelymod.message.jetpack.refueled",
                    JetpackData.getFuel(jetpack),
                    JetpackData.maxFuel()).withStyle(ChatFormatting.GREEN), true);
        }
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        JetpackData.ensureInitialized(stack);
        JetpackFlightMode mode = JetpackData.getMode(stack);
        tooltip.add(Component.translatable(
                "createfreelymod.tooltip.jetpack.fuel",
                JetpackData.getFuel(stack),
                JetpackData.maxFuel()).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable(
                "createfreelymod.tooltip.jetpack.mode",
                Component.translatable(mode.translationKey())).withStyle(ChatFormatting.AQUA));
    }
}
