package com.clanczw.createfreelymod.content.kinetics;

import com.clanczw.createfreelymod.ModMenuTypes;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.items.SlotItemHandler;

/**
 * Layout shared with {@link com.clanczw.createfreelymod.client.CoalBoilerScreen}.
 * <pre>
 *   [flame]              [ tank ]
 *   [fuel ]              [bucket]
 * </pre>
 * Fuel and bucket share the same baseline; tank is centered on the bucket slot.
 */
public class CoalBoilerMenu extends AbstractContainerMenu {
    /** Item slot positions (16×16 content). */
    public static final int FUEL_SLOT_X = 44;
    public static final int FUEL_SLOT_Y = 49;
    public static final int BUCKET_SLOT_X = 116;
    public static final int BUCKET_SLOT_Y = 49;

    /** 14×14 flame icon, centered over the 16×16 fuel item area. */
    public static final int FLAME_X = FUEL_SLOT_X + 1;
    public static final int FLAME_Y = 32;

    /** 16×W tank, left-aligned with bucket item area; sits just above the slot. */
    public static final int TANK_X = BUCKET_SLOT_X;
    public static final int TANK_Y = 14;
    public static final int TANK_W = 16;
    public static final int TANK_H = 30;

    private final CoalBoilerBlockEntity boiler;
    private final ContainerData data;

    public CoalBoilerMenu(int containerId, Inventory playerInventory, FriendlyByteBuf extraData) {
        this(containerId, playerInventory, playerInventory.player.level().getBlockEntity(extraData.readBlockPos()),
                new SimpleContainerData(3));
    }

    public CoalBoilerMenu(int containerId, Inventory playerInventory, BlockEntity be, ContainerData data) {
        super(ModMenuTypes.COAL_BOILER.get(), containerId);
        this.boiler = (CoalBoilerBlockEntity) be;
        this.data = data;

        addSlot(new SlotItemHandler(boiler.getInventory(), CoalBoilerBlockEntity.FUEL_SLOT,
                FUEL_SLOT_X, FUEL_SLOT_Y));
        addSlot(new SlotItemHandler(boiler.getInventory(), CoalBoilerBlockEntity.BUCKET_SLOT,
                BUCKET_SLOT_X, BUCKET_SLOT_Y));

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
        }

        addDataSlots(data);
    }

    public CoalBoilerBlockEntity getBoiler() {
        return boiler;
    }

    public int getBurnTimeRemaining() {
        return data.get(0);
    }

    public int getBurnTimeTotal() {
        return data.get(1);
    }

    public int getSyncedFluidAmount() {
        return data.get(2);
    }

    public FluidStack getFluid() {
        return boiler == null ? FluidStack.EMPTY : boiler.getFluid();
    }

    public float getBurnProgress() {
        int total = getBurnTimeTotal();
        if (total <= 0) {
            return 0.0F;
        }
        return Math.min(1.0F, (float) getBurnTimeRemaining() / (float) total);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            if (index == CoalBoilerBlockEntity.FUEL_SLOT || index == CoalBoilerBlockEntity.BUCKET_SLOT) {
                if (!moveItemStackTo(stack, 2, slots.size(), true)) {
                    return ItemStack.EMPTY;
                }
            } else if (CoalBoilerBlockEntity.isFillBucket(stack)) {
                if (!moveItemStackTo(stack, CoalBoilerBlockEntity.BUCKET_SLOT,
                        CoalBoilerBlockEntity.BUCKET_SLOT + 1, false)) {
                    return ItemStack.EMPTY;
                }
            } else if (CoalBoilerBlockEntity.getBurnDuration(stack) > 0) {
                if (!moveItemStackTo(stack, CoalBoilerBlockEntity.FUEL_SLOT,
                        CoalBoilerBlockEntity.FUEL_SLOT + 1, false)) {
                    return ItemStack.EMPTY;
                }
            } else if (index < 29) {
                if (!moveItemStackTo(stack, 29, slots.size(), false)) {
                    return ItemStack.EMPTY;
                }
            } else if (!moveItemStackTo(stack, 2, 29, false)) {
                return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) {
                slot.setByPlayer(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
        }
        return result;
    }

    @Override
    public boolean stillValid(Player player) {
        return boiler != null
                && !boiler.isRemoved()
                && player.distanceToSqr(
                        boiler.getBlockPos().getX() + 0.5D,
                        boiler.getBlockPos().getY() + 0.5D,
                        boiler.getBlockPos().getZ() + 0.5D) <= 64.0D;
    }
}
