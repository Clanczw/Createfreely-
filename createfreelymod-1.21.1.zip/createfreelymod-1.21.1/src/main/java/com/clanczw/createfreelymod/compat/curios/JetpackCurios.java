package com.clanczw.createfreelymod.compat.curios;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModList;
import net.neoforged.fml.loading.FMLEnvironment;

/**
 * Curios 软依赖门面：无 Curios 时永不触碰 API 类。
 * <p>
 * <b>思路</b>：{@link ModList} 判定后再进入 {@link JetpackCuriosCompat}；
 * 客户端渲染注册拆到 {@link JetpackCuriosClient}，避免专用服务器加载客户端类。
 */
public final class JetpackCurios {
    public static final boolean LOADED = ModList.get().isLoaded("curios");

    private JetpackCurios() {
    }

    public static void bootstrap(IEventBus modEventBus) {
        if (!LOADED) {
            return;
        }
        JetpackCuriosCompat.bootstrap(modEventBus);
        if (FMLEnvironment.dist == Dist.CLIENT) {
            JetpackCuriosClient.bootstrap(modEventBus);
        }
    }

    /** 背饰槽中的喷气背包；无 Curios / 未装备时返回 EMPTY。 */
    public static ItemStack findJetpack(LivingEntity entity) {
        if (!LOADED) {
            return ItemStack.EMPTY;
        }
        return JetpackCuriosCompat.findJetpack(entity);
    }
}
