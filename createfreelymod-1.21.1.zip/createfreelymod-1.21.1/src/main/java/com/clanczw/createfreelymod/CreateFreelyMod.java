package com.clanczw.createfreelymod;

import com.clanczw.createfreelymod.client.CreateFreelyModClient;
import com.clanczw.createfreelymod.compat.curios.JetpackCurios;
import com.clanczw.createfreelymod.config.CreateFreelyClientConfig;
import com.clanczw.createfreelymod.config.CreateFreelyCommonConfig;
import com.clanczw.createfreelymod.content.jetpack.JetpackItemFluidHandler;
import com.clanczw.createfreelymod.content.jetpack.JetpackNetwork;
import com.clanczw.createfreelymod.content.burner.BlazeBurnerFuelCapabilities;
import com.clanczw.createfreelymod.content.burner.FluidBurnerBlockEntity;
import com.clanczw.createfreelymod.content.burner.ModFanProcessingTypes;
import com.clanczw.createfreelymod.content.energy.CapacitorBlockEntity;
import com.clanczw.createfreelymod.content.energy.CreativeCapacitorBlockEntity;
import com.clanczw.createfreelymod.content.kinetics.CoalBoilerBlockEntity;
import com.clanczw.createfreelymod.content.kinetics.FeMotorBlockEntity;
import com.clanczw.createfreelymod.content.kinetics.StressSinkBlockEntity;
import com.simibubi.create.foundation.data.CreateRegistrate;
import com.simibubi.create.foundation.item.ItemDescription;
import com.simibubi.create.foundation.item.KineticStats;
import com.simibubi.create.foundation.item.TooltipModifier;

import org.slf4j.Logger;

import com.mojang.logging.LogUtils;

import net.createmod.catnip.lang.FontHelper;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.loading.FMLEnvironment;

/**
 * Create Freely Mod 入口。
 * <p>
 * <b>思路</b>：用 Create Registrate 统一注册方块/物品/流体，并挂上 Create 风格的动能 tooltip。
 * 能力（FE / 流体）与喷气背包网络包在构造时挂到 mod bus；游戏逻辑走 {@code @EventBusSubscriber}。
 * 内容线：动能↔FE 桥、电容、流体燃烧室、烈焰人管道燃料、天蓝燃料喷气背包。
 */
@Mod(CreateFreelyMod.MOD_ID)
public class CreateFreelyMod {
    public static final String MOD_ID = "createfreelymod";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static final CreateRegistrate REGISTRATE = CreateRegistrate.create(MOD_ID)
            .defaultCreativeTab((ResourceKey<CreativeModeTab>) null)
            .setTooltipModifierFactory(item ->
                    new ItemDescription.Modifier(item, FontHelper.Palette.STANDARD_CREATE)
                            .andThen(TooltipModifier.mapNull(KineticStats.create(item))));

    public CreateFreelyMod(IEventBus modEventBus, ModContainer modContainer) {
        modContainer.registerConfig(ModConfig.Type.COMMON, CreateFreelyCommonConfig.SPEC);
        // Client config only on client — dedicated servers never touch HUD prefs.
        if (FMLEnvironment.dist == Dist.CLIENT) {
            modContainer.registerConfig(ModConfig.Type.CLIENT, CreateFreelyClientConfig.SPEC);
            CreateFreelyModClient.registerConfigScreen(modContainer);
        }

        REGISTRATE.registerEventListeners(modEventBus);

        ModCreativeTabs.register(modEventBus);
        ModMenuTypes.register(modEventBus);
        REGISTRATE.defaultCreativeTab(ModCreativeTabs.MAIN_TAB.getKey());
        REGISTRATE.setCreativeTab(ModCreativeTabs.MAIN_TAB);

        // DeferredRegister / static BlockEntry 初始化：调用 init() 只为触发类加载
        ModFanProcessingTypes.register(modEventBus);
        ModArmorMaterials.register(modEventBus);
        ModBlocks.init();
        ModFluids.init();
        ModItems.init();
        ModBlockEntityTypes.init();

        modEventBus.addListener(StressSinkBlockEntity::registerCapabilities);
        modEventBus.addListener(FeMotorBlockEntity::registerCapabilities);
        modEventBus.addListener(CoalBoilerBlockEntity::registerCapabilities);
        modEventBus.addListener(CapacitorBlockEntity::registerCapabilities);
        modEventBus.addListener(CreativeCapacitorBlockEntity::registerCapabilities);
        modEventBus.addListener(FluidBurnerBlockEntity::registerCapabilities);
        modEventBus.addListener(BlazeBurnerFuelCapabilities::register);
        modEventBus.addListener(JetpackItemFluidHandler::registerCapabilities);
        modEventBus.addListener(JetpackNetwork::register);

        // Curios 可选：给玩家 back 槽，喷气背包可当背饰，与胸甲同逻辑
        JetpackCurios.bootstrap(modEventBus);
    }
}
