package com.clanczw.createfreelymod.compat.jade;

import com.clanczw.createfreelymod.CreateFreelyMod;
import com.clanczw.createfreelymod.content.energy.CapacitorBlock;
import com.clanczw.createfreelymod.content.energy.CreativeCapacitorBlock;
import com.clanczw.createfreelymod.content.kinetics.FeMotorBlock;
import com.clanczw.createfreelymod.content.kinetics.StressSinkBlock;

import net.minecraft.resources.ResourceLocation;

import snownee.jade.api.IWailaClientRegistration;
import snownee.jade.api.IWailaCommonRegistration;
import snownee.jade.api.IWailaPlugin;
import snownee.jade.api.WailaPlugin;

@WailaPlugin
public class CreateFreelyModJadePlugin implements IWailaPlugin {
    public static final ResourceLocation ENERGY = id("energy");
    public static final ResourceLocation FE_MOTOR = id("fe_motor");
    public static final ResourceLocation STRESS_SINK = id("stress_sink");

    private static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(CreateFreelyMod.MOD_ID, path);
    }

    @Override
    public void register(IWailaCommonRegistration registration) {
        registration.registerBlockDataProvider(EnergyJadeProvider.INSTANCE, CapacitorBlock.class);
        registration.registerBlockDataProvider(EnergyJadeProvider.INSTANCE, CreativeCapacitorBlock.class);
        registration.registerBlockDataProvider(StressSinkJadeProvider.INSTANCE, StressSinkBlock.class);
        registration.registerBlockDataProvider(FeMotorJadeProvider.INSTANCE, FeMotorBlock.class);
    }

    @Override
    public void registerClient(IWailaClientRegistration registration) {
        registration.registerBlockComponent(EnergyJadeProvider.INSTANCE, CapacitorBlock.class);
        registration.registerBlockComponent(EnergyJadeProvider.INSTANCE, CreativeCapacitorBlock.class);
        registration.registerBlockComponent(StressSinkJadeProvider.INSTANCE, StressSinkBlock.class);
        registration.registerBlockComponent(FeMotorJadeProvider.INSTANCE, FeMotorBlock.class);
    }
}
