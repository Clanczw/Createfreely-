package com.clanczw.createfreelymod.content.kinetics;

import com.clanczw.createfreelymod.ModBlockEntityTypes;
import com.mojang.serialization.MapCodec;
import com.simibubi.create.AllShapes;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * 热力锅炉：右键打开燃料 UI，燃烧中从背面（朝向反面）输出 Create 动力。
 */
public class CoalBoilerBlock extends HalfShaftKineticBlock<CoalBoilerBlockEntity> {
    public static final BooleanProperty LIT = BlockStateProperties.LIT;
    public static final MapCodec<CoalBoilerBlock> CODEC = simpleCodec(CoalBoilerBlock::new);

    public CoalBoilerBlock(Properties properties) {
        super(properties);
        registerDefaultState(defaultBlockState()
                .setValue(FACING, Direction.NORTH)
                .setValue(LIT, false));
    }

    /** Shaft / kinetic port is on the back; FACING is the furnace front. */
    public static Direction getShaftFacing(BlockState state) {
        return state.getValue(FACING).getOpposite();
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(LIT);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter worldIn, BlockPos pos, CollisionContext context) {
        return AllShapes.MOTOR_BLOCK.get(getShaftFacing(state));
    }

    @Override
    public boolean hasShaftTowards(LevelReader world, BlockPos pos, BlockState state, Direction face) {
        return face == getShaftFacing(state);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
            BlockHitResult hitResult) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof CoalBoilerBlockEntity boiler && player instanceof ServerPlayer serverPlayer) {
            serverPlayer.openMenu(boiler, buf -> buf.writeBlockPos(pos));
            return InteractionResult.CONSUME;
        }
        return InteractionResult.PASS;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        if (!state.is(newState.getBlock())) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof CoalBoilerBlockEntity boiler) {
                boiler.dropContents();
            }
        }
        super.onRemove(state, level, pos, newState, isMoving);
    }

    @Override
    public Class<CoalBoilerBlockEntity> getBlockEntityClass() {
        return CoalBoilerBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends CoalBoilerBlockEntity> getBlockEntityType() {
        return ModBlockEntityTypes.COAL_BOILER.get();
    }
}
