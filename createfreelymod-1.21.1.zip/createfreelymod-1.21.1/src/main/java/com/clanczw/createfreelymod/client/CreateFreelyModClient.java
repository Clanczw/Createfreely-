package com.clanczw.createfreelymod.client;

import com.clanczw.createfreelymod.CreateFreelyMod;
import com.clanczw.createfreelymod.ModFluids;
import com.clanczw.createfreelymod.ModItems;
import com.clanczw.createfreelymod.ModMenuTypes;
import com.clanczw.createfreelymod.content.ponder.CreateFreelyPonderPlugin;

import net.createmod.ponder.foundation.PonderIndex;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;
import net.neoforged.neoforge.client.model.DynamicFluidContainerModel;

@EventBusSubscriber(modid = CreateFreelyMod.MOD_ID, value = Dist.CLIENT)
public final class CreateFreelyModClient {
    private CreateFreelyModClient() {
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            ModRenderOptimization.bootstrap();
            registerPonder();
        });
    }

    @SubscribeEvent
    public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(ModMenuTypes.COAL_BOILER.get(), CoalBoilerScreen::new);
    }

    /** Mods list → Configure opens the client/common config screens. */
    public static void registerConfigScreen(ModContainer modContainer) {
        modContainer.registerExtensionPoint(IConfigScreenFactory.class,
                (minecraft, parent) -> new ConfigurationScreen(modContainer, parent));
    }

    private static void registerPonder() {
        // ordering=AFTER create/ponder in mods.toml; still guard against broken installs.
        if (!ModList.get().isLoaded("create") || !ModList.get().isLoaded("ponder")) {
            CreateFreelyMod.LOGGER.warn("Skipping Ponder scenes: Create/Ponder not loaded");
            return;
        }
        try {
            PonderIndex.addPlugin(new CreateFreelyPonderPlugin());
        } catch (Throwable t) {
            CreateFreelyMod.LOGGER.error("Failed to register Ponder scenes", t);
        }
    }

    @SubscribeEvent
    public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(FuelJetpackModel.LAYER_LOCATION, FuelJetpackModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerClientExtensions(RegisterClientExtensionsEvent event) {
        ModFluids.AzureFuelType type = (ModFluids.AzureFuelType) ModFluids.AZURE_FUEL.getType();
        event.registerFluidType(new AzureFuelClientExtensions(type), type);
        event.registerItem(FuelJetpackClientExtensions.INSTANCE, ModItems.FUEL_JETPACK.get());
    }

    @SubscribeEvent
    public static void registerItemColors(RegisterColorHandlersEvent.Item event) {
        ModFluids.AZURE_FUEL.getBucket().ifPresent(bucket ->
                event.register(new DynamicFluidContainerModel.Colors(), bucket));
    }
}
