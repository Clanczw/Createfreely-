package com.clanczw.createfreelymod.content.energy;

import java.util.List;

import org.jetbrains.annotations.Nullable;

import com.clanczw.createfreelymod.ModBlockEntityTypes;
import com.simibubi.create.content.equipment.wrench.IWrenchable;
import com.simibubi.create.foundation.block.IBE;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class CapacitorBlock extends Block implements IBE<CapacitorBlockEntity>, IWrenchable {
    private final CapacitorTier tier;

    public CapacitorBlock(BlockBehaviour.Properties properties, CapacitorTier tier) {
        super(properties);
        this.tier = tier;
    }

    public CapacitorTier getTier() {
        return tier;
    }

    public static int getCapacity(BlockState state) {
        if (state.getBlock() instanceof CapacitorBlock capacitor) {
            return capacitor.tier.getCapacity();
        }
        return CapacitorTier.LOW.getCapacity();
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return CapacitorShapes.SHAPE;
    }

    @Override
    protected boolean useShapeForLightOcclusion(BlockState state) {
        return true;
    }

    @Override
    public Class<CapacitorBlockEntity> getBlockEntityClass() {
        return CapacitorBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends CapacitorBlockEntity> getBlockEntityType() {
        return ModBlockEntityTypes.CAPACITOR.get();
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
            BlockEntityType<T> type) {
        return CapacitorBlockEntity.createTicker(level, type);
    }

    @Override
    protected List<ItemStack> getDrops(BlockState state, LootParams.Builder params) {
        List<ItemStack> drops = super.getDrops(state, params);
        BlockEntity be = params.getOptionalParameter(LootContextParams.BLOCK_ENTITY);
        if (be instanceof CapacitorBlockEntity capacitor) {
            for (ItemStack stack : drops) {
                if (stack.getItem() == asItem()) {
                    CapacitorItemEnergy.write(stack, capacitor.getEnergyStored(), getBlockEntityType());
                }
            }
        }
        return drops;
    }

    @Override
    public ItemStack getCloneItemStack(BlockState state, HitResult target, LevelReader level, BlockPos pos,
            Player player) {
        ItemStack stack = new ItemStack(this);
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof CapacitorBlockEntity capacitor) {
            CapacitorItemEnergy.write(stack, capacitor.getEnergyStored(), getBlockEntityType());
        }
        return stack;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
            BlockHitResult hitResult) {
        return onBlockEntityUse(level, pos, be -> be.onUse(player));
    }

    /** 电容无朝向；扳手不旋转，留给玩家空手查看电量。 */
    @Override
    public InteractionResult onWrenched(BlockState state, UseOnContext context) {
        return InteractionResult.PASS;
    }

    @Override
    protected boolean isPathfindable(BlockState state, PathComputationType pathComputationType) {
        return false;
    }
}
