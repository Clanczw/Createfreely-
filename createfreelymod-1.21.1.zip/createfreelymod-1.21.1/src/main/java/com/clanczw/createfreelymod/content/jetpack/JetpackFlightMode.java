package com.clanczw.createfreelymod.content.jetpack;

import net.minecraft.util.StringRepresentable;

public enum JetpackFlightMode implements StringRepresentable {
    NORMAL("normal"),
    HOVER("hover");

    private final String name;

    JetpackFlightMode(String name) {
        this.name = name;
    }

    public JetpackFlightMode next() {
        return this == NORMAL ? HOVER : NORMAL;
    }

    public String translationKey() {
        return "createfreelymod.jetpack.mode." + name;
    }

    public static JetpackFlightMode byName(String name) {
        for (JetpackFlightMode mode : values()) {
            if (mode.name.equals(name)) {
                return mode;
            }
        }
        return NORMAL;
    }

    @Override
    public String getSerializedName() {
        return name;
    }
}
