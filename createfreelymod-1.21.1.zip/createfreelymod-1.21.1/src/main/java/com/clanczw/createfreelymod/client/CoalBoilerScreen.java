package com.clanczw.createfreelymod.client;

import java.util.List;

import com.clanczw.createfreelymod.content.kinetics.CoalBoilerBlockEntity;
import com.clanczw.createfreelymod.content.kinetics.CoalBoilerMenu;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.level.material.Fluid;

import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;
import net.neoforged.neoforge.fluids.FluidStack;

/**
 * Solid fuel + flame on the left; fluid tank stacked over the bucket slot on the right.
 */
public class CoalBoilerScreen extends AbstractContainerScreen<CoalBoilerMenu> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.withDefaultNamespace("textures/gui/container/furnace.png");
    private static final int PANEL = 0xFFC6C6C6;

    public CoalBoilerScreen(CoalBoilerMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
    }

    @Override
    protected void init() {
        super.init();
        titleLabelX = (imageWidth - font.width(title)) / 2;
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int left = leftPos;
        int top = topPos;
        graphics.blit(TEXTURE, left, top, 0, 0, imageWidth, imageHeight);

        // Wipe all furnace machine chrome; keep only the player inventory strip.
        graphics.fill(left + 7, top + 14, left + 169, top + 82, PANEL);

        // Slot frames (18×18 from furnace.png).
        blitSlot(graphics, left, top, CoalBoilerMenu.FUEL_SLOT_X, CoalBoilerMenu.FUEL_SLOT_Y);
        blitSlot(graphics, left, top, CoalBoilerMenu.BUCKET_SLOT_X, CoalBoilerMenu.BUCKET_SLOT_Y);

        // Empty flame cavity, then lit progress overlay.
        graphics.blit(TEXTURE, left + CoalBoilerMenu.FLAME_X, top + CoalBoilerMenu.FLAME_Y,
                56, 36, 14, 14);
        float progress = menu.getBurnProgress();
        if (progress > 0.0F) {
            int flameHeight = Mth.ceil(progress * 14.0F);
            graphics.blit(TEXTURE,
                    left + CoalBoilerMenu.FLAME_X,
                    top + CoalBoilerMenu.FLAME_Y + 14 - flameHeight,
                    176, 14 - flameHeight, 14, flameHeight);
        }

        renderFluidTank(graphics, left + CoalBoilerMenu.TANK_X, top + CoalBoilerMenu.TANK_Y);
    }

    private static void blitSlot(GuiGraphics graphics, int left, int top, int slotX, int slotY) {
        graphics.blit(TEXTURE, left + slotX - 1, top + slotY - 1, 55, 16, 18, 18);
    }

    private void renderFluidTank(GuiGraphics graphics, int x, int y) {
        int w = CoalBoilerMenu.TANK_W;
        int h = CoalBoilerMenu.TANK_H;
        graphics.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF373737);
        graphics.fill(x, y, x + w, y + h, 0xFF8B8B8B);

        FluidStack fluid = menu.getFluid();
        int amount = menu.getSyncedFluidAmount();
        if (!fluid.isEmpty() && amount > 0) {
            int fill = Mth.clamp(amount * h / CoalBoilerBlockEntity.FLUID_CAPACITY, 1, h);
            renderFluid(graphics, fluid, x, y + h - fill, w, fill);
        }

        for (int i = 1; i < 4; i++) {
            int gy = y + (h * i / 4);
            graphics.fill(x, gy, x + 3, gy + 1, 0xFF555555);
        }
    }

    private void renderFluid(GuiGraphics graphics, FluidStack stack, int x, int y, int width, int height) {
        Fluid fluid = stack.getFluid();
        IClientFluidTypeExtensions extensions = IClientFluidTypeExtensions.of(fluid);
        ResourceLocation still = extensions.getStillTexture(stack);
        if (still == null) {
            graphics.fill(x, y, x + width, y + height, extensions.getTintColor(stack) | 0xFF000000);
            return;
        }
        TextureAtlasSprite sprite = minecraft.getTextureAtlas(InventoryMenu.BLOCK_ATLAS).apply(still);
        int color = extensions.getTintColor(stack);
        float a = ((color >> 24) & 0xFF) / 255.0F;
        float r = ((color >> 16) & 0xFF) / 255.0F;
        float g = ((color >> 8) & 0xFF) / 255.0F;
        float b = (color & 0xFF) / 255.0F;
        if (a <= 0.0F) {
            a = 1.0F;
        }
        graphics.setColor(r, g, b, a);
        graphics.blit(x, y, 0, width, height, sprite);
        graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        super.renderLabels(graphics, mouseX, mouseY);
        int color = 0x404040;
        // Beside fuel slot
        graphics.drawString(this.font,
                Component.translatable("createfreelymod.gui.coal_boiler.fuel_slot"),
                CoalBoilerMenu.FUEL_SLOT_X + 20,
                CoalBoilerMenu.FUEL_SLOT_Y + 5,
                color, false);
        // Beside fluid tank (mid-height)
        graphics.drawString(this.font,
                Component.translatable("createfreelymod.gui.coal_boiler.fluid_tank"),
                CoalBoilerMenu.TANK_X + CoalBoilerMenu.TANK_W + 4,
                CoalBoilerMenu.TANK_Y + CoalBoilerMenu.TANK_H / 2 - 4,
                color, false);
        // Beside bucket slot
        graphics.drawString(this.font,
                Component.translatable("createfreelymod.gui.coal_boiler.bucket_slot"),
                CoalBoilerMenu.BUCKET_SLOT_X + 20,
                CoalBoilerMenu.BUCKET_SLOT_Y + 5,
                color, false);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics, mouseX, mouseY, partialTick);
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
        if (isHovering(CoalBoilerMenu.TANK_X, CoalBoilerMenu.TANK_Y,
                CoalBoilerMenu.TANK_W, CoalBoilerMenu.TANK_H, mouseX, mouseY)) {
            FluidStack fluid = menu.getFluid();
            int amount = menu.getSyncedFluidAmount();
            if (fluid.isEmpty() || amount <= 0) {
                graphics.renderComponentTooltip(font,
                        List.of(Component.translatable("createfreelymod.tooltip.coal_boiler.tank_empty")),
                        mouseX, mouseY);
            } else {
                graphics.renderComponentTooltip(font, List.of(
                        fluid.getHoverName(),
                        Component.literal(amount + " / " + CoalBoilerBlockEntity.FLUID_CAPACITY + " mB")
                ), mouseX, mouseY);
            }
        }
    }
}
