package com.clanczw.createfreelymod.compat.curios;

import com.clanczw.createfreelymod.ModItems;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import top.theillusivec4.curios.api.client.CuriosRendererRegistry;

/** Curios 客户端：背饰槽用手写护甲模型渲染喷气背包。 */
public final class JetpackCuriosClient {
    private JetpackCuriosClient() {
    }

    public static void bootstrap(IEventBus modEventBus) {
        modEventBus.addListener(JetpackCuriosClient::onClientSetup);
    }

    private static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> CuriosRendererRegistry.register(
                ModItems.FUEL_JETPACK.get(), JetpackCurioRenderer::new));
    }
}
