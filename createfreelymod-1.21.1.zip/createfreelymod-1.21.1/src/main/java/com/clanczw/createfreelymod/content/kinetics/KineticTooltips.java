package com.clanczw.createfreelymod.content.kinetics;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

/** Shared Create goggle tooltip formatting for kinetic machines. */
public final class KineticTooltips {
    private KineticTooltips() {
    }

    public static void addLabeledValue(List<Component> tooltip, String translationKey, String value) {
        tooltip.add(Component.literal("    ")
                .append(Component.translatable(translationKey).withStyle(ChatFormatting.GRAY)));
        tooltip.add(Component.literal("        ")
                .append(Component.literal(value).withStyle(ChatFormatting.AQUA)));
    }
}
