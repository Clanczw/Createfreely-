package com.clanczw.createfreelymod.client;

import org.lwjgl.glfw.GLFW;

import com.clanczw.createfreelymod.CreateFreelyMod;
import com.clanczw.createfreelymod.config.CreateFreelyClientConfig;
import com.clanczw.createfreelymod.config.JetpackHudAnchor;
import com.clanczw.createfreelymod.content.jetpack.FuelJetpackItem;
import com.clanczw.createfreelymod.content.jetpack.JetpackFlight;
import com.clanczw.createfreelymod.content.jetpack.JetpackJumpPayload;
import com.clanczw.createfreelymod.content.jetpack.ToggleJetpackModePayload;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.common.util.Lazy;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * 喷气背包客户端输入。
 * <p>
 * <b>思路</b>：V 键切换飞行模式；[ 键循环 HUD 角落（写入 client 配置）；
 * 跳跃状态每 tick 本地缓存并在变化时发包。
 */
@EventBusSubscriber(modid = CreateFreelyMod.MOD_ID, value = Dist.CLIENT)
public final class JetpackClientEvents {
    public static final Lazy<KeyMapping> TOGGLE_MODE = Lazy.of(() -> new KeyMapping(
            "key.createfreelymod.jetpack_toggle_mode",
            GLFW.GLFW_KEY_V,
            "key.categories.createfreelymod"));

    public static final Lazy<KeyMapping> CYCLE_HUD_ANCHOR = Lazy.of(() -> new KeyMapping(
            "key.createfreelymod.jetpack_hud_anchor",
            GLFW.GLFW_KEY_LEFT_BRACKET,
            "key.categories.createfreelymod"));

    private static boolean lastJumpSent;
    private static int jumpResendTicks;

    private JetpackClientEvents() {
    }

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(TOGGLE_MODE.get());
        event.register(CYCLE_HUD_ANCHOR.get());
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Pre event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            return;
        }

        ItemStack worn = FuelJetpackItem.getWorn(mc.player);

        while (TOGGLE_MODE.get().consumeClick()) {
            if (!worn.isEmpty()) {
                PacketDistributor.sendToServer(new ToggleJetpackModePayload());
            }
        }

        while (CYCLE_HUD_ANCHOR.get().consumeClick()) {
            if (worn.isEmpty()) {
                continue;
            }
            JetpackHudAnchor next = CreateFreelyClientConfig.cycleJetpackHudAnchor();
            mc.player.displayClientMessage(
                    Component.translatable("createfreelymod.message.jetpack.hud_anchor",
                            Component.translatable(next.translationKey())),
                    true);
        }

        if (worn.isEmpty()) {
            if (lastJumpSent) {
                lastJumpSent = false;
                jumpResendTicks = 0;
                JetpackFlight.setHoldingJump(mc.player, false);
                PacketDistributor.sendToServer(new JetpackJumpPayload(false));
            }
            return;
        }

        boolean jumping = mc.options.keyJump.isDown();
        JetpackFlight.setHoldingJump(mc.player, jumping);
        if (jumping != lastJumpSent || (jumping && ++jumpResendTicks >= 10)) {
            lastJumpSent = jumping;
            jumpResendTicks = 0;
            PacketDistributor.sendToServer(new JetpackJumpPayload(jumping));
        }
    }
}
