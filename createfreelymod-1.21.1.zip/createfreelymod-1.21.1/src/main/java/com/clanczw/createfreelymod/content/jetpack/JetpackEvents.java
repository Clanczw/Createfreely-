package com.clanczw.createfreelymod.content.jetpack;

import com.clanczw.createfreelymod.CreateFreelyMod;
import com.clanczw.createfreelymod.ModFluids;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@EventBusSubscriber(modid = CreateFreelyMod.MOD_ID)
public final class JetpackEvents {
    private JetpackEvents() {
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        ItemStack jetpack = FuelJetpackItem.getWorn(player);
        if (jetpack.isEmpty()) {
            JetpackFlight.clearHover(player);
            return;
        }
        JetpackFlight.tick(player, jetpack);
    }

    /** 手持超级燃料桶右键：给穿戴中或另一只手的喷气背包加油。 */
    @SubscribeEvent
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        ItemStack held = event.getItemStack();
        if (ModFluids.AZURE_FUEL.getBucket().isEmpty() || !held.is(ModFluids.AZURE_FUEL.getBucket().get())) {
            return;
        }

        Player player = event.getEntity();
        ItemStack worn = FuelJetpackItem.getWorn(player);
        if (!worn.isEmpty() && FuelJetpackItem.tryRefuel(player, worn, held)) {
            event.setCancellationResult(InteractionResult.sidedSuccess(player.level().isClientSide()));
            event.setCanceled(true);
            return;
        }

        ItemStack other = player.getItemInHand(event.getHand() == InteractionHand.MAIN_HAND
                ? InteractionHand.OFF_HAND
                : InteractionHand.MAIN_HAND);
        if (FuelJetpackItem.isJetpack(other) && FuelJetpackItem.tryRefuel(player, other, held)) {
            event.setCancellationResult(InteractionResult.sidedSuccess(player.level().isClientSide()));
            event.setCanceled(true);
        }
    }
}
