package com.clanczw.createfreelymod;

import com.clanczw.createfreelymod.content.jetpack.FuelJetpackItem;
import com.tterrag.registrate.util.entry.ItemEntry;

import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Rarity;

public final class ModItems {
    public static final ItemEntry<FuelJetpackItem> FUEL_JETPACK = CreateFreelyMod.REGISTRATE
            .item("fuel_jetpack", props -> new FuelJetpackItem(ModArmorMaterials.FUEL_JETPACK, props))
            .properties(p -> p.stacksTo(1)
                    .rarity(Rarity.UNCOMMON)
                    .durability(ArmorItem.Type.CHESTPLATE.getDurability(25)))
            .lang("Fuel Jetpack")
            .register();

    public static void init() {
    }

    private ModItems() {
    }
}
