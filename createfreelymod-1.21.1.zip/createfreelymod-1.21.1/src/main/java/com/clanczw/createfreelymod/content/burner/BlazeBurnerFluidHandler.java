package com.clanczw.createfreelymod.content.burner;

import com.clanczw.createfreelymod.CreateFreelyMod;
import com.clanczw.createfreelymod.ModFluids;
import com.simibubi.create.content.processing.burner.BlazeBurnerBlock;
import com.simibubi.create.content.processing.burner.BlazeBurnerBlockEntity;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;

import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;

/**
 * Accepts lava (normal heat) or azure fuel (super heat) via pipes / fluid handlers.
 * Each full bucket (1000 mB) is applied as the matching bucket item.
 * <p>
 * Partial fill is stored on the blaze burner BE via NeoForge persistent data so it survives chunk unload.
 */
public class BlazeBurnerFluidHandler implements IFluidHandler {
    private static final String NBT_KEY = CreateFreelyMod.MOD_ID + ":pipe_fuel";
    private static final String NBT_FLUID = "Fluid";
    private static final String NBT_AMOUNT = "Amount";

    private final BlazeBurnerBlockEntity burner;

    public BlazeBurnerFluidHandler(BlazeBurnerBlockEntity burner) {
        this.burner = burner;
    }

    @Override
    public int getTanks() {
        return 1;
    }

    @Override
    public FluidStack getFluidInTank(int tank) {
        if (tank != 0) {
            return FluidStack.EMPTY;
        }
        Buffer buffer = readBuffer();
        if (buffer.amount() <= 0 || buffer.fluid() == null) {
            return FluidStack.EMPTY;
        }
        return new FluidStack(buffer.fluid(), buffer.amount());
    }

    @Override
    public int getTankCapacity(int tank) {
        return tank == 0 ? FluidType.BUCKET_VOLUME : 0;
    }

    @Override
    public boolean isFluidValid(int tank, FluidStack stack) {
        return tank == 0 && isAcceptedFuel(stack);
    }

    @Override
    public int fill(FluidStack resource, FluidAction action) {
        if (!isAcceptedFuel(resource) || resource.getAmount() <= 0) {
            return 0;
        }

        Fluid incoming = resource.getFluid();
        Buffer buffer = readBuffer();
        if (buffer.amount() > 0 && buffer.fluid() != null && !incoming.isSame(buffer.fluid())) {
            return 0;
        }

        if (action.simulate()) {
            int simBuffered = buffer.amount();
            Fluid simFluid = buffer.fluid() != null ? buffer.fluid() : incoming;
            if (simBuffered >= FluidType.BUCKET_VOLUME && tryApplyBucket(simFluid, true)) {
                simBuffered -= FluidType.BUCKET_VOLUME;
            }
            int space = FluidType.BUCKET_VOLUME - simBuffered;
            return space <= 0 ? 0 : Math.min(space, resource.getAmount());
        }

        tryConsumeBufferedBucket(buffer);
        buffer = readBuffer();

        if (buffer.amount() > 0 && buffer.fluid() != null && !incoming.isSame(buffer.fluid())) {
            return 0;
        }

        int space = FluidType.BUCKET_VOLUME - buffer.amount();
        if (space <= 0) {
            return 0;
        }

        int accepted = Math.min(space, resource.getAmount());
        Fluid stored = buffer.fluid() != null ? buffer.fluid() : incoming;
        writeBuffer(stored, buffer.amount() + accepted);
        tryConsumeBufferedBucket(readBuffer());
        return accepted;
    }

    @Override
    public FluidStack drain(FluidStack resource, FluidAction action) {
        return FluidStack.EMPTY;
    }

    @Override
    public FluidStack drain(int maxDrain, FluidAction action) {
        return FluidStack.EMPTY;
    }

    private void tryConsumeBufferedBucket(Buffer buffer) {
        if (buffer.amount() < FluidType.BUCKET_VOLUME || buffer.fluid() == null) {
            return;
        }
        if (tryApplyBucket(buffer.fluid(), false)) {
            int remaining = buffer.amount() - FluidType.BUCKET_VOLUME;
            if (remaining <= 0) {
                clearBuffer();
            } else {
                writeBuffer(buffer.fluid(), remaining);
            }
        }
    }

    private boolean tryApplyBucket(Fluid fluid, boolean simulate) {
        Level level = burner.getLevel();
        if (level == null || level.isClientSide) {
            return false;
        }

        ItemStack fuelBucket = bucketFor(fluid);
        if (fuelBucket.isEmpty()) {
            return false;
        }

        InteractionResultHolder<ItemStack> result;
        try {
            result = BlazeBurnerBlock.tryInsert(
                    burner.getBlockState(),
                    level,
                    burner.getBlockPos(),
                    fuelBucket,
                    true,
                    true,
                    simulate);
        } catch (RuntimeException ex) {
            // Fail soft if Create's burner API changes or another mod breaks heater state.
            return false;
        }
        return result.getResult() == InteractionResult.SUCCESS;
    }

    private Buffer readBuffer() {
        CompoundTag root = burner.getPersistentData();
        if (!root.contains(NBT_KEY)) {
            return Buffer.EMPTY;
        }
        CompoundTag tag = root.getCompound(NBT_KEY);
        int amount = tag.getInt(NBT_AMOUNT);
        if (amount <= 0 || !tag.contains(NBT_FLUID)) {
            return Buffer.EMPTY;
        }
        ResourceLocation id = ResourceLocation.tryParse(tag.getString(NBT_FLUID));
        if (id == null || !BuiltInRegistries.FLUID.containsKey(id)) {
            return Buffer.EMPTY;
        }
        Fluid fluid = BuiltInRegistries.FLUID.get(id);
        if (fluid == Fluids.EMPTY) {
            return Buffer.EMPTY;
        }
        return new Buffer(fluid, amount);
    }

    private void writeBuffer(Fluid fluid, int amount) {
        if (fluid == null || amount <= 0) {
            clearBuffer();
            return;
        }
        CompoundTag tag = new CompoundTag();
        tag.putString(NBT_FLUID, BuiltInRegistries.FLUID.getKey(fluid).toString());
        tag.putInt(NBT_AMOUNT, amount);
        burner.getPersistentData().put(NBT_KEY, tag);
        burner.setChanged();
    }

    private void clearBuffer() {
        if (burner.getPersistentData().contains(NBT_KEY)) {
            burner.getPersistentData().remove(NBT_KEY);
            burner.setChanged();
        }
    }

    private static ItemStack bucketFor(Fluid fluid) {
        if (fluid.isSame(Fluids.LAVA)) {
            return new ItemStack(Items.LAVA_BUCKET);
        }
        if (ModFluids.isAzureFuel(fluid)) {
            return new ItemStack(ModFluids.AZURE_FUEL.getBucket().get());
        }
        return ItemStack.EMPTY;
    }

    private static boolean isAcceptedFuel(FluidStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        Fluid fluid = stack.getFluid();
        return fluid.isSame(Fluids.LAVA) || ModFluids.isAzureFuel(fluid);
    }

    private record Buffer(Fluid fluid, int amount) {
        private static final Buffer EMPTY = new Buffer(null, 0);
    }
}
