package com.clanczw.createfreelymod.content.energy;

import org.jetbrains.annotations.Nullable;

import com.clanczw.createfreelymod.ModBlockEntityTypes;
import com.clanczw.createfreelymod.config.CreateFreelyCommonConfig;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.energy.IEnergyStorage;

/**
 * 创造电容：FULL 无限源按速率灌邻居；EMPTY 超大缓冲可吸走多余 FE。
 * <p>
 * <b>思路</b>：不用 Integer.MAX_VALUE，避免其他模组倍率 UI 溢出；FULL 侧不挂物品 FE 能力。
 */
public class CreativeCapacitorBlockEntity extends BlockEntity {
    private final CreativeCapacitorMode mode;
    private final IEnergyStorage energy;
    @Nullable
    private final ModEnergyStorage buffer;
    private boolean clientSyncPending;

    public CreativeCapacitorBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
        this.mode = CreativeCapacitorBlock.getMode(state);
        if (mode == CreativeCapacitorMode.FULL) {
            this.buffer = null;
            this.energy = CreativeEnergyStorages.FULL;
        } else {
            this.buffer = new ModEnergyStorage(CreateFreelyCommonConfig.creativeEmptyCapacity(),
                    this::onEnergyChanged);
            this.energy = this.buffer;
        }
    }

    private void onEnergyChanged() {
        EnergyBlockSync.markDirty(this);
        clientSyncPending = true;
    }

    private void syncCapacityFromConfig() {
        if (buffer == null) {
            return;
        }
        int cap = CreateFreelyCommonConfig.creativeEmptyCapacity();
        if (buffer.getMaxEnergyStored() != cap) {
            buffer.setCapacity(cap);
            clientSyncPending = true;
        }
    }

    public CreativeCapacitorMode getMode() {
        return mode;
    }

    public int getEnergyStored() {
        return energy.getEnergyStored();
    }

    public int getMaxEnergyStored() {
        return energy.getMaxEnergyStored();
    }

    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(
                Capabilities.EnergyStorage.BLOCK,
                ModBlockEntityTypes.CREATIVE_CAPACITOR.get(),
                (be, side) -> be.energy);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, CreativeCapacitorBlockEntity be) {
        if (be.mode == CreativeCapacitorMode.FULL) {
            EnergyTransfer.feedNeighborsInfinite(level, pos);
        } else if (be.buffer != null) {
            be.syncCapacityFromConfig();
            if (EnergyTransfer.pushToNeighbors(level, pos, be.buffer)) {
                be.clientSyncPending = true;
            }
            if (be.clientSyncPending) {
                EnergyBlockSync.flushClientSync(be);
                be.clientSyncPending = false;
            }
        }
    }

    @Nullable
    public static <T extends BlockEntity> BlockEntityTicker<T> createTicker(
            Level level, BlockEntityType<T> type) {
        return level.isClientSide ? null
                : BlockEntityTickers.create(type, ModBlockEntityTypes.CREATIVE_CAPACITOR.get(),
                        CreativeCapacitorBlockEntity::serverTick);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        if (buffer != null) {
            EnergyBlockSync.write(tag, buffer);
        }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        if (buffer != null) {
            EnergyBlockSync.read(tag, buffer);
        }
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        CompoundTag tag = super.getUpdateTag(registries);
        if (buffer != null) {
            EnergyBlockSync.write(tag, buffer);
        }
        return tag;
    }

    @Override
    public void handleUpdateTag(CompoundTag tag, HolderLookup.Provider registries) {
        super.handleUpdateTag(tag, registries);
        if (buffer != null) {
            EnergyBlockSync.read(tag, buffer);
        }
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return EnergyBlockSync.packet(this);
    }

    @Override
    public void onDataPacket(Connection connection, ClientboundBlockEntityDataPacket packet,
            HolderLookup.Provider registries) {
        if (buffer != null) {
            EnergyBlockSync.readPacket(packet.getTag(), buffer);
        }
    }

    public InteractionResult onUse(Player player) {
        if (!player.level().isClientSide) {
            if (mode == CreativeCapacitorMode.FULL) {
                player.displayClientMessage(
                        Component.translatable("createfreelymod.message.creative_capacitor_full"), true);
            } else if (buffer != null) {
                player.displayClientMessage(
                        Component.translatable(
                                "createfreelymod.message.creative_capacitor_empty",
                                EnergyFormat.format(buffer.getEnergyStored()),
                                EnergyFormat.format(buffer.getMaxEnergyStored())),
                        true);
            }
        }
        return InteractionResult.SUCCESS;
    }
}
