package com.clanczw.createfreelymod.content.energy;

import java.util.List;
import java.util.function.Supplier;

import com.clanczw.createfreelymod.ModBlockEntityTypes;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;

public class CapacitorBlockItem extends BlockItem {
    public enum Kind {
        TIERED,
        CREATIVE_EMPTY,
        CREATIVE_FULL
    }

    private final Kind kind;
    private final Supplier<Integer> capacity;

    public CapacitorBlockItem(Block block, Properties properties, Kind kind, Supplier<Integer> capacity) {
        super(block, properties);
        this.kind = kind;
        this.capacity = capacity;
    }

    public Kind getKind() {
        return kind;
    }

    public int getCapacity() {
        return capacity.get();
    }

    public BlockEntityType<?> getBlockEntityType() {
        return kind == Kind.TIERED
                ? ModBlockEntityTypes.CAPACITOR.get()
                : ModBlockEntityTypes.CREATIVE_CAPACITOR.get();
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip,
            TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        if (kind == Kind.CREATIVE_FULL) {
            tooltip.add(Component.translatable("createfreelymod.tooltip.item.creative_full")
                    .withStyle(ChatFormatting.LIGHT_PURPLE));
            return;
        }
        int stored = CapacitorItemEnergy.getEnergy(stack);
        int max = getCapacity();
        tooltip.add(Component.translatable(
                "createfreelymod.tooltip.item.stored",
                EnergyFormat.format(stored),
                EnergyFormat.format(max)).withStyle(ChatFormatting.GRAY));
    }
}
