package com.clanczw.createfreelymod.content.energy;

import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Collision / outline matching the battery-pack mesh AABB. */
public final class CapacitorShapes {
    public static final VoxelShape SHAPE = Shapes.box(
            0.25 / 16.0,
            0.0,
            1.25 / 16.0,
            15.75 / 16.0,
            15.5 / 16.0,
            14.75 / 16.0);

    private CapacitorShapes() {
    }
}
