package com.clanczw.createfreelymod.content.energy;

import org.jetbrains.annotations.Nullable;

import com.clanczw.createfreelymod.ModBlockEntityTypes;
import com.clanczw.createfreelymod.ModBlocks;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;

/**
 * 分级电容：存 FE，并向邻居自动均分推送。
 * <p>
 * <b>思路</b>：物品与方块共用 {@link CapacitorItemEnergy}（写入 BLOCK_ENTITY_DATA），
 * 破坏/中键复制保留电量；物品侧也注册 FE 能力，可被应力汇等充能。
 */
public class CapacitorBlockEntity extends BlockEntity {
    private final ModEnergyStorage energy;
    private boolean clientSyncPending;

    public CapacitorBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
        this.energy = new ModEnergyStorage(CapacitorBlock.getCapacity(state), this::onEnergyChanged);
    }

    private void onEnergyChanged() {
        EnergyBlockSync.markDirty(this);
        clientSyncPending = true;
    }

    public int getEnergyStored() {
        return energy.getEnergyStored();
    }

    public int getMaxEnergyStored() {
        return energy.getMaxEnergyStored();
    }

    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(
                Capabilities.EnergyStorage.BLOCK,
                ModBlockEntityTypes.CAPACITOR.get(),
                (be, side) -> be.energy);

        event.registerItem(
                Capabilities.EnergyStorage.ITEM,
                (stack, ctx) -> {
                    if (!(stack.getItem() instanceof CapacitorBlockItem item)) {
                        return null;
                    }
                    if (item.getKind() == CapacitorBlockItem.Kind.CREATIVE_FULL) {
                        return null;
                    }
                    return CapacitorItemEnergy.storage(stack, item.getCapacity(), item.getBlockEntityType());
                },
                ModBlocks.CAPACITOR_LOW.get(),
                ModBlocks.CAPACITOR_MEDIUM.get(),
                ModBlocks.CAPACITOR_HIGH.get(),
                ModBlocks.CREATIVE_CAPACITOR_EMPTY.get());
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, CapacitorBlockEntity be) {
        if (EnergyTransfer.pushToNeighbors(level, pos, be.energy)) {
            be.clientSyncPending = true;
        }
        if (be.clientSyncPending) {
            EnergyBlockSync.flushClientSync(be);
            be.clientSyncPending = false;
        }
    }

    @Nullable
    public static <T extends BlockEntity> BlockEntityTicker<T> createTicker(
            Level level, BlockEntityType<T> type) {
        return level.isClientSide ? null
                : BlockEntityTickers.create(type, ModBlockEntityTypes.CAPACITOR.get(), CapacitorBlockEntity::serverTick);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        EnergyBlockSync.write(tag, energy);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        EnergyBlockSync.read(tag, energy);
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        CompoundTag tag = super.getUpdateTag(registries);
        EnergyBlockSync.write(tag, energy);
        return tag;
    }

    @Override
    public void handleUpdateTag(CompoundTag tag, HolderLookup.Provider registries) {
        super.handleUpdateTag(tag, registries);
        EnergyBlockSync.read(tag, energy);
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return EnergyBlockSync.packet(this);
    }

    @Override
    public void onDataPacket(Connection connection, ClientboundBlockEntityDataPacket packet,
            HolderLookup.Provider registries) {
        EnergyBlockSync.readPacket(packet.getTag(), energy);
    }

    public InteractionResult onUse(Player player) {
        if (!player.level().isClientSide) {
            player.displayClientMessage(
                    Component.translatable(
                            "createfreelymod.message.capacitor",
                            EnergyFormat.format(energy.getEnergyStored()),
                            EnergyFormat.format(energy.getMaxEnergyStored())),
                    true);
        }
        return InteractionResult.SUCCESS;
    }
}
