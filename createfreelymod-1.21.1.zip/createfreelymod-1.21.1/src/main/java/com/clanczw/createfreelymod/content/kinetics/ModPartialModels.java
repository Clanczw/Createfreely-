package com.clanczw.createfreelymod.content.kinetics;

import com.clanczw.createfreelymod.CreateFreelyMod;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;

import net.minecraft.resources.ResourceLocation;

public final class ModPartialModels {
    /** Short Create-style axis stub that only peeks out of the machine's shaft port. */
    public static final PartialModel SHAFT_STUB = PartialModel.of(
            ResourceLocation.fromNamespaceAndPath(CreateFreelyMod.MOD_ID, "block/shaft_stub"));

    private ModPartialModels() {
    }

    /** Forces class init so {@link #SHAFT_STUB} registers before model bake. */
    public static void init() {
    }
}
