package com.clanczw.createfreelymod.client;

import com.clanczw.createfreelymod.CreateFreelyMod;
import com.clanczw.createfreelymod.ModBlocks;
import com.clanczw.createfreelymod.content.kinetics.ModPartialModels;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.kinetics.base.DirectionalKineticBlock;

import net.createmod.catnip.render.CachedBuffers;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ModelEvent;

/**
 * Runtime model/render warm-up that does not alter mesh JSON.
 * <p>
 * Prefills Create {@link CachedBuffers} for every shaft facing so the first
 * on-screen kinetic tick does not hitch while baking SuperByteBuffers.
 */
@EventBusSubscriber(modid = CreateFreelyMod.MOD_ID, value = Dist.CLIENT)
public final class ModRenderOptimization {
    private ModRenderOptimization() {
    }

    /** Touch partial-model statics early so Flywheel registers them in time. */
    public static void bootstrap() {
        ModPartialModels.init();
    }

    @SubscribeEvent
    public static void onModelBakingCompleted(ModelEvent.BakingCompleted event) {
        prewarmKineticBuffers();
    }

    private static void prewarmKineticBuffers() {
        try {
            for (Direction facing : Direction.values()) {
                BlockState sink = ModBlocks.STRESS_SINK.getDefaultState()
                        .setValue(DirectionalKineticBlock.FACING, facing);
                BlockState motor = ModBlocks.FE_MOTOR.getDefaultState()
                        .setValue(DirectionalKineticBlock.FACING, facing);
                BlockState boiler = ModBlocks.COAL_BOILER.getDefaultState()
                        .setValue(DirectionalKineticBlock.FACING, facing);
                CachedBuffers.partialFacing(ModPartialModels.SHAFT_STUB, sink);
                CachedBuffers.partialFacing(AllPartialModels.SHAFT_HALF, motor);
                CachedBuffers.partialFacing(AllPartialModels.SHAFT_HALF, boiler, facing.getOpposite());
            }
        } catch (RuntimeException ex) {
            // Baking race / missing model — first in-world render will fill the cache instead.
            CreateFreelyMod.LOGGER.debug("Kinetic buffer prewarm skipped: {}", ex.toString());
        }
    }
}
