package com.clanczw.createfreelymod.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.Model;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;

/** 喷气背包客户端扩展：自定义护甲模型 + 手写 idle/flight 动画。 */
public final class FuelJetpackClientExtensions implements IClientItemExtensions {
    public static final FuelJetpackClientExtensions INSTANCE = new FuelJetpackClientExtensions();

    private FuelJetpackModel model;

    private FuelJetpackClientExtensions() {
    }

    public FuelJetpackModel model() {
        if (this.model == null) {
            this.model = new FuelJetpackModel(
                    Minecraft.getInstance().getEntityModels().bakeLayer(FuelJetpackModel.LAYER_LOCATION));
        }
        return this.model;
    }

    @Override
    public HumanoidModel<?> getHumanoidArmorModel(
            LivingEntity livingEntity,
            ItemStack itemStack,
            EquipmentSlot equipmentSlot,
            HumanoidModel<?> original) {
        FuelJetpackModel jetpackModel = model();
        jetpackModel.prepareForRender();
        return jetpackModel;
    }

    @Override
    public void setupModelAnimations(
            LivingEntity livingEntity,
            ItemStack itemStack,
            EquipmentSlot equipmentSlot,
            Model model,
            float limbSwing,
            float limbSwingAmount,
            float partialTick,
            float ageInTicks,
            float netHeadYaw,
            float headPitch) {
        if (model instanceof FuelJetpackModel jetpackModel) {
            jetpackModel.applyJetpackAnimation(livingEntity, itemStack, ageInTicks);
        }
    }
}
