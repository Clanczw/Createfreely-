package com.clanczw.createfreelymod.compat.jade;

import com.clanczw.createfreelymod.content.energy.CapacitorBlockEntity;
import com.clanczw.createfreelymod.content.energy.CreativeCapacitorBlockEntity;
import com.clanczw.createfreelymod.content.energy.CreativeCapacitorMode;
import com.clanczw.createfreelymod.content.energy.EnergyFormat;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import snownee.jade.api.BlockAccessor;
import snownee.jade.api.IBlockComponentProvider;
import snownee.jade.api.IServerDataProvider;
import snownee.jade.api.ITooltip;
import snownee.jade.api.config.IPluginConfig;

public enum EnergyJadeProvider implements IBlockComponentProvider, IServerDataProvider<BlockAccessor> {
    INSTANCE;

    @Override
    public void appendTooltip(ITooltip tooltip, BlockAccessor accessor, IPluginConfig config) {
        CompoundTag data = accessor.getServerData();
        if (data.getBoolean("CreativeFull")) {
            tooltip.add(Component.translatable("createfreelymod.jade.creative_full"));
            return;
        }
        if (!data.contains("Energy") || !data.contains("MaxEnergy")) {
            return;
        }
        tooltip.add(Component.translatable(
                "createfreelymod.jade.energy",
                EnergyFormat.format(data.getInt("Energy")),
                EnergyFormat.format(data.getInt("MaxEnergy"))));
    }

    @Override
    public void appendServerData(CompoundTag data, BlockAccessor accessor) {
        if (accessor.getBlockEntity() instanceof CapacitorBlockEntity be) {
            data.putInt("Energy", be.getEnergyStored());
            data.putInt("MaxEnergy", be.getMaxEnergyStored());
            return;
        }
        if (accessor.getBlockEntity() instanceof CreativeCapacitorBlockEntity be) {
            boolean full = be.getMode() == CreativeCapacitorMode.FULL;
            data.putBoolean("CreativeFull", full);
            if (!full) {
                data.putInt("Energy", be.getEnergyStored());
                data.putInt("MaxEnergy", be.getMaxEnergyStored());
            }
        }
    }

    @Override
    public ResourceLocation getUid() {
        return CreateFreelyModJadePlugin.ENERGY;
    }
}
