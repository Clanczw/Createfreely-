package com.clanczw.createfreelymod;

import static com.simibubi.create.foundation.data.TagGen.pickaxeOnly;

import com.clanczw.createfreelymod.content.burner.FluidBurnerBlock;
import com.clanczw.createfreelymod.content.energy.CapacitorBlock;
import com.clanczw.createfreelymod.content.energy.CapacitorBlockItem;
import com.clanczw.createfreelymod.content.energy.CapacitorTier;
import com.clanczw.createfreelymod.content.energy.CreativeCapacitorBlock;
import com.clanczw.createfreelymod.content.energy.CreativeCapacitorMode;
import com.clanczw.createfreelymod.content.energy.CreativeEnergyStorages;
import com.clanczw.createfreelymod.content.kinetics.CoalBoilerBlock;
import com.clanczw.createfreelymod.content.kinetics.FeMotorBlock;
import com.clanczw.createfreelymod.content.kinetics.StressSinkBlock;
import com.clanczw.createfreelymod.config.CreateFreelyCommonConfig;
import com.simibubi.create.api.stress.BlockStressValues;
import com.simibubi.create.foundation.data.SharedProperties;
import com.tterrag.registrate.util.entry.BlockEntry;

import net.minecraft.world.level.material.MapColor;

/**
 * 模组方块注册表。
 * <p>
 * 动能：应力汇（SU→FE）、FE 马达（FE→SU）、热力锅炉（燃料→SU）；能量：三级电容 + 创造满/空；
 * 加工：流体燃烧室（风扇催化剂）。
 */
public final class ModBlocks {
    public static final BlockEntry<FluidBurnerBlock> FLUID_BURNER = CreateFreelyMod.REGISTRATE
            .block("fluid_burner", FluidBurnerBlock::new)
            .initialProperties(SharedProperties::softMetal)
            .properties(p -> p.mapColor(MapColor.GOLD).noOcclusion().forceSolidOn())
            .transform(pickaxeOnly())
            .item()
            .build()
            .register();

    public static final BlockEntry<CoalBoilerBlock> COAL_BOILER = CreateFreelyMod.REGISTRATE
            .block("coal_boiler", CoalBoilerBlock::new)
            .initialProperties(SharedProperties::stone)
            .properties(p -> p.mapColor(MapColor.TERRACOTTA_YELLOW)
                    .noOcclusion()
                    .forceSolidOn()
                    .lightLevel(state -> state.getValue(CoalBoilerBlock.LIT) ? 8 : 0))
            .transform(pickaxeOnly())
            .onRegister(block -> BlockStressValues.CAPACITIES.register(block,
                    CreateFreelyCommonConfig::coalBoilerMaxStressCapacity))
            .item()
            .build()
            .register();

    public static final BlockEntry<StressSinkBlock> STRESS_SINK = CreateFreelyMod.REGISTRATE
            .block("stress_sink", StressSinkBlock::new)
            .initialProperties(SharedProperties::stone)
            .properties(p -> p.mapColor(MapColor.TERRACOTTA_YELLOW).noOcclusion().forceSolidOn())
            .transform(pickaxeOnly())
            .onRegister(block -> BlockStressValues.IMPACTS.register(block,
                    CreateFreelyCommonConfig::stressSinkImpact))
            .item()
            .build()
            .register();

    public static final BlockEntry<FeMotorBlock> FE_MOTOR = CreateFreelyMod.REGISTRATE
            .block("fe_motor", FeMotorBlock::new)
            .initialProperties(SharedProperties::stone)
            .properties(p -> p.mapColor(MapColor.TERRACOTTA_YELLOW).noOcclusion().forceSolidOn())
            .transform(pickaxeOnly())
            .onRegister(block -> BlockStressValues.CAPACITIES.register(block,
                    CreateFreelyCommonConfig::feMotorMaxStressCapacity))
            .item()
            .build()
            .register();

    public static final BlockEntry<CapacitorBlock> CAPACITOR_LOW = capacitor(CapacitorTier.LOW, MapColor.TERRACOTTA_ORANGE);
    public static final BlockEntry<CapacitorBlock> CAPACITOR_MEDIUM = capacitor(CapacitorTier.MEDIUM, MapColor.TERRACOTTA_YELLOW);
    public static final BlockEntry<CapacitorBlock> CAPACITOR_HIGH = capacitor(CapacitorTier.HIGH, MapColor.GOLD);

    public static final BlockEntry<CreativeCapacitorBlock> CREATIVE_CAPACITOR_FULL = CreateFreelyMod.REGISTRATE
            .block("creative_capacitor_full", p -> new CreativeCapacitorBlock(p, CreativeCapacitorMode.FULL))
            .initialProperties(SharedProperties::stone)
            .properties(p -> p.mapColor(MapColor.COLOR_PURPLE).strength(2.0f).lightLevel(s -> 10).noOcclusion())
            .transform(pickaxeOnly())
            .item((block, props) -> new CapacitorBlockItem(block, props, CapacitorBlockItem.Kind.CREATIVE_FULL, () -> 0))
            .build()
            .register();

    public static final BlockEntry<CreativeCapacitorBlock> CREATIVE_CAPACITOR_EMPTY = CreateFreelyMod.REGISTRATE
            .block("creative_capacitor_empty", p -> new CreativeCapacitorBlock(p, CreativeCapacitorMode.EMPTY))
            .initialProperties(SharedProperties::stone)
            .properties(p -> p.mapColor(MapColor.TERRACOTTA_BROWN).strength(2.0f).noOcclusion())
            .transform(pickaxeOnly())
            .item((block, props) -> new CapacitorBlockItem(block, props, CapacitorBlockItem.Kind.CREATIVE_EMPTY,
                    () -> CreativeEnergyStorages.emptyCapacity()))
            .build()
            .register();

    public static void init() {
    }

    private static BlockEntry<CapacitorBlock> capacitor(CapacitorTier tier, MapColor color) {
        return CreateFreelyMod.REGISTRATE
                .block("capacitor_" + tier.getIdSuffix(), p -> new CapacitorBlock(p, tier))
                .initialProperties(SharedProperties::stone)
                .properties(p -> p.mapColor(color)
                        .strength(tier.getStrength())
                        .lightLevel(s -> tier.getLightLevel())
                        .noOcclusion())
                .transform(pickaxeOnly())
                .item((block, props) -> new CapacitorBlockItem(block, props, CapacitorBlockItem.Kind.TIERED,
                        () -> ((CapacitorBlock) block).getTier().getCapacity()))
                .build()
                .register();
    }

    private ModBlocks() {
    }
}
