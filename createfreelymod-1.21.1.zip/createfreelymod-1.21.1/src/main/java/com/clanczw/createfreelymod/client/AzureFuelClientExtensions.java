package com.clanczw.createfreelymod.client;

import org.jetbrains.annotations.NotNull;
import org.joml.Vector3f;

import com.clanczw.createfreelymod.ModFluids;
import com.mojang.blaze3d.shaders.FogShape;
import com.mojang.blaze3d.systems.RenderSystem;

import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.FogRenderer.FogMode;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.material.FluidState;

import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;
import net.neoforged.neoforge.fluids.FluidStack;

/**
 * Matches Create honey/chocolate: pre-colored sprites, no stack tint,
 * world tint strips alpha so biome coloring does not override.
 */
public final class AzureFuelClientExtensions implements IClientFluidTypeExtensions {
    private static final int NO_TINT = 0xFFFFFFFF;

    private final ModFluids.AzureFuelType type;

    public AzureFuelClientExtensions(ModFluids.AzureFuelType type) {
        this.type = type;
    }

    @Override
    public ResourceLocation getStillTexture() {
        return type.stillTexture();
    }

    @Override
    public ResourceLocation getFlowingTexture() {
        return type.flowingTexture();
    }

    @Override
    public int getTintColor() {
        return NO_TINT;
    }

    @Override
    public int getTintColor(FluidStack stack) {
        return NO_TINT;
    }

    @Override
    public int getTintColor(FluidState state, BlockAndTintGetter getter, BlockPos pos) {
        return 0x00FFFFFF;
    }

    @Override
    public @NotNull Vector3f modifyFogColor(Camera camera, float partialTick, ClientLevel level,
            int renderDistance, float darkenWorldAmount, Vector3f fluidFogColor) {
        return type.fogColor();
    }

    @Override
    public void modifyFogRender(Camera camera, FogMode mode, float renderDistance, float partialTick,
            float nearDistance, float farDistance, FogShape shape) {
        float modifier = type.fogDistanceModifier();
        if (modifier != 1f) {
            RenderSystem.setShaderFogShape(FogShape.CYLINDER);
            RenderSystem.setShaderFogStart(-8);
            RenderSystem.setShaderFogEnd(96.0f * modifier);
        }
    }
}
