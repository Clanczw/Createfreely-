package com.clanczw.createfreelymod.content.jetpack;

import com.clanczw.createfreelymod.ModFluids;
import com.clanczw.createfreelymod.ModItems;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.material.Fluid;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.IFluidHandlerItem;

/**
 * Allows Create spouts to drip azure fuel into a jetpack sitting on a depot.
 */
public final class JetpackItemFluidHandler implements IFluidHandlerItem {
    private final ItemStack container;

    public JetpackItemFluidHandler(ItemStack container) {
        this.container = container;
    }

    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerItem(
                Capabilities.FluidHandler.ITEM,
                (stack, ctx) -> new JetpackItemFluidHandler(stack),
                ModItems.FUEL_JETPACK.get());
    }

    @Override
    public ItemStack getContainer() {
        return container;
    }

    @Override
    public int getTanks() {
        return 1;
    }

    @Override
    public FluidStack getFluidInTank(int tank) {
        int fuel = JetpackData.getFuel(container);
        if (fuel <= 0) {
            return FluidStack.EMPTY;
        }
        return new FluidStack(azureSource(), fuel);
    }

    @Override
    public int getTankCapacity(int tank) {
        return JetpackData.maxFuel();
    }

    @Override
    public boolean isFluidValid(int tank, FluidStack stack) {
        return isAzureFuel(stack);
    }

    @Override
    public int fill(FluidStack resource, IFluidHandler.FluidAction action) {
        if (container.getCount() != 1 || resource.isEmpty() || !isAzureFuel(resource)) {
            return 0;
        }
        int space = JetpackData.maxFuel() - JetpackData.getFuel(container);
        int accepted = Math.min(resource.getAmount(), space);
        if (accepted <= 0) {
            return 0;
        }
        if (action.execute()) {
            JetpackData.addFuel(container, accepted);
        }
        return accepted;
    }

    @Override
    public FluidStack drain(FluidStack resource, IFluidHandler.FluidAction action) {
        if (container.getCount() != 1 || resource.isEmpty() || !isAzureFuel(resource)) {
            return FluidStack.EMPTY;
        }
        return drain(resource.getAmount(), action);
    }

    @Override
    public FluidStack drain(int maxDrain, IFluidHandler.FluidAction action) {
        if (container.getCount() != 1 || maxDrain <= 0) {
            return FluidStack.EMPTY;
        }
        int fuel = JetpackData.getFuel(container);
        int drained = Math.min(maxDrain, fuel);
        if (drained <= 0) {
            return FluidStack.EMPTY;
        }
        if (action.execute()) {
            JetpackData.setFuel(container, fuel - drained);
        }
        return new FluidStack(azureSource(), drained);
    }

    private static Fluid azureSource() {
        return ModFluids.AZURE_FUEL.getSource();
    }

    private static boolean isAzureFuel(FluidStack stack) {
        return ModFluids.isAzureFuel(stack);
    }
}
