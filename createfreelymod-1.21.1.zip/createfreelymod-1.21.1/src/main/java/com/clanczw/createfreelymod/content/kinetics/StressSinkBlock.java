package com.clanczw.createfreelymod.content.kinetics;

import com.clanczw.createfreelymod.ModBlockEntityTypes;

import net.minecraft.world.level.block.entity.BlockEntityType;

public class StressSinkBlock extends HalfShaftKineticBlock<StressSinkBlockEntity> {
    public StressSinkBlock(Properties properties) {
        super(properties);
    }

    @Override
    public Class<StressSinkBlockEntity> getBlockEntityClass() {
        return StressSinkBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends StressSinkBlockEntity> getBlockEntityType() {
        return ModBlockEntityTypes.STRESS_SINK.get();
    }
}
