package com.clanczw.createfreelymod.content.kinetics;

import com.clanczw.createfreelymod.ModBlockEntityTypes;

import net.minecraft.world.level.block.entity.BlockEntityType;

public class FeMotorBlock extends HalfShaftKineticBlock<FeMotorBlockEntity> {
    public FeMotorBlock(Properties properties) {
        super(properties);
    }

    @Override
    public Class<FeMotorBlockEntity> getBlockEntityClass() {
        return FeMotorBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends FeMotorBlockEntity> getBlockEntityType() {
        return ModBlockEntityTypes.FE_MOTOR.get();
    }
}
