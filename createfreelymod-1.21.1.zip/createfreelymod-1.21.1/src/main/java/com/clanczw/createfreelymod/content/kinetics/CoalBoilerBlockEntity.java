package com.clanczw.createfreelymod.content.kinetics;

import java.util.List;
import java.util.Locale;

import com.clanczw.createfreelymod.ModBlockEntityTypes;
import com.clanczw.createfreelymod.ModFluids;
import com.clanczw.createfreelymod.config.CreateFreelyCommonConfig;
import com.simibubi.create.api.equipment.goggles.IHaveGoggleInformation;
import com.simibubi.create.content.kinetics.base.GeneratingKineticBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.fluid.SmartFluidTankBehaviour;
import com.simibubi.create.foundation.fluid.FluidHelper;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluids;

import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.fluids.FluidUtil;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.items.ItemStackHandler;

/**
 * 热力锅炉：固体燃料槽 + 1B 液体燃料槽；轴面不接流体，其它面可管道输入。
 */
public class CoalBoilerBlockEntity extends GeneratingKineticBlockEntity
        implements MenuProvider, IHaveGoggleInformation {
    public static final int FUEL_SLOT = 0;
    public static final int BUCKET_SLOT = 1;
    public static final int FLUID_CAPACITY = FluidType.BUCKET_VOLUME;

    public enum FuelGrade {
        NONE,
        NORMAL,
        LAVA,
        SUPER
    }

    private SmartFluidTankBehaviour tank;

    private final ItemStackHandler inventory = new ItemStackHandler(2) {
        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
        }

        @Override
        public void deserializeNBT(HolderLookup.Provider provider, CompoundTag nbt) {
            // Old worlds saved Size=1; without this, BUCKET_SLOT access throws
            // "Slot 1 not in valid range - [0,1)".
            nbt.putInt("Size", 2);
            super.deserializeNBT(provider, nbt);
        }

        @Override
        public boolean isItemValid(int slot, ItemStack stack) {
            if (slot == FUEL_SLOT) {
                return getBurnDuration(stack) > 0 && !isFillBucket(stack);
            }
            if (slot == BUCKET_SLOT) {
                return isFillBucket(stack);
            }
            return false;
        }

        @Override
        public int getSlotLimit(int slot) {
            return slot == BUCKET_SLOT ? 1 : super.getSlotLimit(slot);
        }
    };

    private int burnTimeRemaining;
    private int burnTimeTotal;
    private FuelGrade activeGrade = FuelGrade.NONE;
    private int generatedRpm;
    private float stressCapacity;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case 0 -> burnTimeRemaining;
                case 1 -> burnTimeTotal;
                case 2 -> getFluidAmount();
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case 0 -> burnTimeRemaining = value;
                case 1 -> burnTimeTotal = value;
                default -> {
                }
            }
        }

        @Override
        public int getCount() {
            return 3;
        }
    };

    public CoalBoilerBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    @Override
    public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
        super.addBehaviours(behaviours);
        tank = SmartFluidTankBehaviour.single(this, FLUID_CAPACITY);
        tank.getPrimaryHandler().setValidator(CoalBoilerBlockEntity::isValidFuelFluid);
        behaviours.add(tank);
    }

    public ItemStackHandler getInventory() {
        return inventory;
    }

    public FluidStack getFluid() {
        return tank == null ? FluidStack.EMPTY : tank.getPrimaryHandler().getFluid();
    }

    public int getFluidAmount() {
        return getFluid().getAmount();
    }

    public IFluidHandler getFluidHandler() {
        return tank == null ? null : tank.getCapability();
    }

    public boolean isBurning() {
        return burnTimeRemaining > 0 && activeGrade != FuelGrade.NONE;
    }

    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(
                Capabilities.ItemHandler.BLOCK,
                ModBlockEntityTypes.COAL_BOILER.get(),
                (be, side) -> be.inventory);
        event.registerBlockEntity(
                Capabilities.FluidHandler.BLOCK,
                ModBlockEntityTypes.COAL_BOILER.get(),
                (be, side) -> {
                    Direction shaft = CoalBoilerBlock.getShaftFacing(be.getBlockState());
                    if (side != null && side == shaft) {
                        return null;
                    }
                    return be.getFluidHandler();
                });
    }

    public static boolean isValidFuelFluid(FluidStack stack) {
        return gradeOfFluid(stack) != FuelGrade.NONE;
    }

    /** Bucket / fluid item that can pour a valid fuel fluid into the tank. */
    public static boolean isFillBucket(ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        return FluidUtil.getFluidContained(stack)
                .filter(CoalBoilerBlockEntity::isValidFuelFluid)
                .isPresent();
    }

    /**
     * Empty one fill-bucket into the tank only when there is room for the whole contents
     * and the fluid matches (or tank is empty). Otherwise leave the item untouched.
     */
    public boolean tryEmptyBucketIntoTank() {
        if (tank == null || level == null || level.isClientSide) {
            return false;
        }
        ItemStack stack = inventory.getStackInSlot(BUCKET_SLOT);
        if (!isFillBucket(stack)) {
            return false;
        }
        FluidStack contained = FluidUtil.getFluidContained(stack).orElse(FluidStack.EMPTY);
        if (!isValidFuelFluid(contained)) {
            return false;
        }
        FluidStack current = tank.getPrimaryHandler().getFluid();
        if (!current.isEmpty() && !FluidStack.isSameFluidSameComponents(current, contained)) {
            return false;
        }
        int free = FLUID_CAPACITY - current.getAmount();
        if (free < contained.getAmount()) {
            return false;
        }
        var result = FluidUtil.tryEmptyContainer(stack, tank.getPrimaryHandler(), contained.getAmount(), null, true);
        if (!result.isSuccess()) {
            return false;
        }
        inventory.setStackInSlot(BUCKET_SLOT, result.getResult());
        return true;
    }

    public static FuelGrade gradeOfFluid(FluidStack stack) {
        if (stack.isEmpty()) {
            return FuelGrade.NONE;
        }
        if (FluidHelper.isTag(stack, FluidTags.LAVA) || stack.getFluid().isSame(Fluids.LAVA)) {
            return FuelGrade.LAVA;
        }
        if (ModFluids.isAzureFuel(stack)) {
            return FuelGrade.SUPER;
        }
        return FuelGrade.NONE;
    }

    public static boolean isSuperFuelBucket(ItemStack stack) {
        return !stack.isEmpty()
                && ModFluids.AZURE_FUEL.getBucket().isPresent()
                && stack.is(ModFluids.AZURE_FUEL.getBucket().get());
    }

    public static FuelGrade gradeOf(ItemStack stack) {
        if (stack.isEmpty()) {
            return FuelGrade.NONE;
        }
        if (stack.is(Items.LAVA_BUCKET)) {
            return FuelGrade.LAVA;
        }
        if (isSuperFuelBucket(stack)) {
            return FuelGrade.SUPER;
        }
        if (stack.getBurnTime(RecipeType.SMELTING) > 0) {
            return FuelGrade.NORMAL;
        }
        return FuelGrade.NONE;
    }

    public static int getBurnDuration(ItemStack stack) {
        FuelGrade grade = gradeOf(stack);
        return switch (grade) {
            case NONE -> 0;
            case SUPER -> CreateFreelyCommonConfig.coalBoilerSuperFuelBurnTime();
            case LAVA, NORMAL -> Math.max(0, stack.getBurnTime(RecipeType.SMELTING));
        };
    }

    public static int burnDurationForFluidGrade(FuelGrade grade) {
        return switch (grade) {
            case NONE, NORMAL -> 0;
            case LAVA -> Math.max(1, Items.LAVA_BUCKET.getDefaultInstance().getBurnTime(RecipeType.SMELTING));
            case SUPER -> CreateFreelyCommonConfig.coalBoilerSuperFuelBurnTime();
        };
    }

    public static int rpmForGrade(FuelGrade grade) {
        return switch (grade) {
            case NONE -> 0;
            case NORMAL -> CreateFreelyCommonConfig.coalBoilerGeneratedRpm();
            case LAVA -> CreateFreelyCommonConfig.coalBoilerLavaRpm();
            case SUPER -> CreateFreelyCommonConfig.coalBoilerSuperFuelRpm();
        };
    }

    public void dropContents() {
        if (level == null) {
            return;
        }
        for (int i = 0; i < inventory.getSlots(); i++) {
            Containers.dropItemStack(level, worldPosition.getX(), worldPosition.getY(), worldPosition.getZ(),
                    inventory.getStackInSlot(i));
            inventory.setStackInSlot(i, ItemStack.EMPTY);
        }
    }

    @Override
    public void initialize() {
        super.initialize();
        if (!hasSource() || Math.abs(getGeneratedSpeed()) > Math.abs(getTheoreticalSpeed())) {
            updateGeneratedRotation();
        }
    }

    private boolean tryStartSolidFuel() {
        ItemStack fuel = inventory.getStackInSlot(FUEL_SLOT);
        FuelGrade grade = gradeOf(fuel);
        int duration = getBurnDuration(fuel);
        if (grade == FuelGrade.NONE || duration <= 0) {
            return false;
        }
        activeGrade = grade;
        burnTimeTotal = duration;
        burnTimeRemaining = duration;
        ItemStack remainder = fuel.hasCraftingRemainingItem()
                ? fuel.getCraftingRemainingItem()
                : ItemStack.EMPTY;
        fuel.shrink(1);
        if (fuel.isEmpty()) {
            inventory.setStackInSlot(FUEL_SLOT, remainder);
        } else {
            inventory.setStackInSlot(FUEL_SLOT, fuel);
        }
        return true;
    }

    private boolean tryStartFluidFuel() {
        if (tank == null) {
            return false;
        }
        FluidStack fluid = tank.getPrimaryHandler().getFluid();
        FuelGrade grade = gradeOfFluid(fluid);
        int duration = burnDurationForFluidGrade(grade);
        if (grade == FuelGrade.NONE || duration <= 0 || fluid.getAmount() < FLUID_CAPACITY) {
            return false;
        }
        FluidStack drained = tank.getPrimaryHandler().drain(FLUID_CAPACITY, IFluidHandler.FluidAction.EXECUTE);
        if (drained.getAmount() < FLUID_CAPACITY) {
            return false;
        }
        activeGrade = grade;
        burnTimeTotal = duration;
        burnTimeRemaining = duration;
        return true;
    }

    @Override
    public void tick() {
        super.tick();
        if (level == null || level.isClientSide) {
            return;
        }

        boolean wasBurning = isBurning();
        boolean inventoryChanged = false;

        if (tryEmptyBucketIntoTank()) {
            inventoryChanged = true;
        }

        if (burnTimeRemaining > 0) {
            burnTimeRemaining--;
        }

        if (burnTimeRemaining <= 0) {
            if (tryStartSolidFuel()) {
                inventoryChanged = true;
            } else if (tryStartFluidFuel()) {
                inventoryChanged = true;
            } else {
                activeGrade = FuelGrade.NONE;
                burnTimeTotal = 0;
                burnTimeRemaining = 0;
            }
        }

        boolean burning = isBurning();
        int targetRpm = burning ? rpmForGrade(activeGrade) : 0;
        float targetStress = burning
                ? (float) (targetRpm * CreateFreelyCommonConfig.coalBoilerStressPerRpm())
                : 0.0F;

        boolean rotationChanged = false;
        if (targetRpm != generatedRpm || Float.compare(targetStress, stressCapacity) != 0) {
            generatedRpm = targetRpm;
            stressCapacity = targetStress;
            updateGeneratedRotation();
            rotationChanged = true;
        }

        if (wasBurning != burning) {
            BlockState state = getBlockState();
            if (state.hasProperty(CoalBoilerBlock.LIT)
                    && state.getValue(CoalBoilerBlock.LIT) != burning) {
                level.setBlock(worldPosition, state.setValue(CoalBoilerBlock.LIT, burning), 2);
            }
        }

        // Avoid marking the chunk dirty every burning tick; persist/sync on real changes
        // or every second so burn progress still survives crashes / shows in open UIs.
        boolean needsSave = inventoryChanged || rotationChanged || wasBurning != burning;
        boolean needsSync = rotationChanged || wasBurning != burning;
        if (burning && Math.floorMod(level.getGameTime(), 20) == 0) {
            needsSave = true;
            needsSync = true;
        }
        if (needsSave) {
            setChanged();
        }
        if (needsSync) {
            sendData();
        }
    }

    @Override
    public float getGeneratedSpeed() {
        return convertToDirection(generatedRpm, CoalBoilerBlock.getShaftFacing(getBlockState()));
    }

    @Override
    public float calculateAddedStressCapacity() {
        this.lastCapacityProvided = stressCapacity;
        return stressCapacity;
    }

    @Override
    protected void write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(tag, registries, clientPacket);
        tag.put("Inventory", inventory.serializeNBT(registries));
        tag.putInt("BurnTime", burnTimeRemaining);
        tag.putInt("BurnTimeTotal", burnTimeTotal);
        tag.putString("FuelGrade", activeGrade.name());
        tag.putInt("GeneratedRpm", generatedRpm);
        tag.putFloat("StressCapacity", stressCapacity);
    }

    @Override
    protected void read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.read(tag, registries, clientPacket);
        if (tag.contains("Inventory")) {
            inventory.deserializeNBT(registries, tag.getCompound("Inventory"));
        }
        burnTimeRemaining = tag.getInt("BurnTime");
        burnTimeTotal = tag.getInt("BurnTimeTotal");
        activeGrade = parseGrade(tag.getString("FuelGrade"));
        if (burnTimeRemaining <= 0) {
            activeGrade = FuelGrade.NONE;
        } else if (activeGrade == FuelGrade.NONE) {
            activeGrade = FuelGrade.NORMAL;
        }
        generatedRpm = tag.getInt("GeneratedRpm");
        stressCapacity = tag.getFloat("StressCapacity");
    }

    private static FuelGrade parseGrade(String name) {
        if (name == null || name.isEmpty()) {
            return FuelGrade.NONE;
        }
        try {
            return FuelGrade.valueOf(name);
        } catch (IllegalArgumentException ignored) {
            return FuelGrade.NONE;
        }
    }

    @Override
    public Component getDisplayName() {
        return Component.translatable("block.createfreelymod.coal_boiler");
    }

    @Override
    public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
        return new CoalBoilerMenu(containerId, playerInventory, this, data);
    }

    @Override
    public boolean addToGoggleTooltip(List<Component> tooltip, boolean isPlayerSneaking) {
        super.addToGoggleTooltip(tooltip, isPlayerSneaking);
        containedFluidTooltip(tooltip, isPlayerSneaking,
                level.getCapability(Capabilities.FluidHandler.BLOCK, worldPosition, null));
        KineticTooltips.addLabeledValue(tooltip, "createfreelymod.tooltip.coal_boiler.fuel",
                Component.translatable("createfreelymod.tooltip.coal_boiler.fuel."
                                + activeGrade.name().toLowerCase(Locale.ROOT))
                        .getString());
        KineticTooltips.addLabeledValue(tooltip, "createfreelymod.tooltip.coal_boiler.burning",
                isBurning() ? burnTimeRemaining + " / " + burnTimeTotal : "—");
        KineticTooltips.addLabeledValue(tooltip, "createfreelymod.tooltip.coal_boiler.speed",
                generatedRpm + " RPM");
        KineticTooltips.addLabeledValue(tooltip, "createfreelymod.tooltip.coal_boiler.capacity",
                Math.round(stressCapacity) + " SU");
        return true;
    }
}
