package com.clanczw.createfreelymod.content.burner;

import com.mojang.blaze3d.vertex.PoseStack;
import com.simibubi.create.foundation.blockEntity.behaviour.fluid.SmartFluidTankBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.fluid.SmartFluidTankBehaviour.TankSegment;
import com.simibubi.create.foundation.blockEntity.renderer.SafeBlockEntityRenderer;

import net.createmod.catnip.platform.NeoForgeCatnipServices;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.AABB;

import net.neoforged.neoforge.fluids.FluidStack;

public class FluidBurnerRenderer extends SafeBlockEntityRenderer<FluidBurnerBlockEntity> {
    /** Matches the hollow scaffolding interior above the full-size basin. */
    private static final float FLUID_MIN = 2.1f / 16f;
    private static final float FLUID_MAX = 13.9f / 16f;
    private static final float FLUID_FLOOR = 2f / 16f;
    private static final float FLUID_HEIGHT = 13.5f / 16f;

    public FluidBurnerRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public boolean shouldRenderOffScreen(FluidBurnerBlockEntity be) {
        return false;
    }

    @Override
    public AABB getRenderBoundingBox(FluidBurnerBlockEntity blockEntity) {
        return new AABB(blockEntity.getBlockPos());
    }

    @Override
    protected void renderSafe(FluidBurnerBlockEntity be, float partialTicks, PoseStack ms, MultiBufferSource buffer,
            int light, int overlay) {
        SmartFluidTankBehaviour tank = be.getTank();
        if (tank == null) {
            return;
        }

        TankSegment primaryTank = tank.getPrimaryTank();
        FluidStack fluidStack = primaryTank.getRenderedFluid();
        float level = primaryTank.getFluidLevel().getValue(partialTicks);
        if (fluidStack.isEmpty() || level < 1 / 512f) {
            return;
        }

        float clampedLevel = Mth.clamp(level * FLUID_HEIGHT, 0.01f, FLUID_HEIGHT);
        boolean lighterThanAir = fluidStack.getFluid().getFluidType().isLighterThanAir();

        float yMin;
        float yMax;
        if (lighterThanAir) {
            yMax = FLUID_FLOOR + FLUID_HEIGHT;
            yMin = yMax - clampedLevel;
        } else {
            yMin = FLUID_FLOOR;
            yMax = FLUID_FLOOR + clampedLevel;
        }

        NeoForgeCatnipServices.FLUID_RENDERER.renderFluidBox(
                fluidStack,
                FLUID_MIN, yMin, FLUID_MIN,
                FLUID_MAX, yMax, FLUID_MAX,
                buffer, ms, light, false, true);
    }
}
