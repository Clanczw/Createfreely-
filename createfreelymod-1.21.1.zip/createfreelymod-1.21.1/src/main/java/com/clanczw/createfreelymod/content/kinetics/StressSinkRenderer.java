package com.clanczw.createfreelymod.content.kinetics;

import com.simibubi.create.content.kinetics.base.KineticBlockEntityRenderer;

import net.createmod.catnip.render.CachedBuffers;
import net.createmod.catnip.render.SuperByteBuffer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * Renders only a short shaft stub at the kinetic port so the block body stays clear
 * while still visually docking with shafts / bearings.
 */
public class StressSinkRenderer extends KineticBlockEntityRenderer<StressSinkBlockEntity> {
    public StressSinkRenderer(BlockEntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public boolean shouldRenderOffScreen(StressSinkBlockEntity be) {
        return false;
    }

    @Override
    public AABB getRenderBoundingBox(StressSinkBlockEntity blockEntity) {
        return new AABB(blockEntity.getBlockPos());
    }

    @Override
    protected SuperByteBuffer getRotatedModel(StressSinkBlockEntity be, BlockState state) {
        return CachedBuffers.partialFacing(ModPartialModels.SHAFT_STUB, state);
    }
}
