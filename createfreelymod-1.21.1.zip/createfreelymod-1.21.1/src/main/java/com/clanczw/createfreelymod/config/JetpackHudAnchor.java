package com.clanczw.createfreelymod.config;

import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.common.TranslatableEnum;

/**
 * Screen-corner anchors for the jetpack dial HUD.
 */
public enum JetpackHudAnchor implements TranslatableEnum {
    TOP_LEFT,
    TOP_RIGHT,
    BOTTOM_LEFT,
    BOTTOM_RIGHT;

    public String translationKey() {
        return "createfreelymod.hud.jetpack.anchor." + name().toLowerCase();
    }

    @Override
    public Component getTranslatedName() {
        return Component.translatable(translationKey());
    }
}
