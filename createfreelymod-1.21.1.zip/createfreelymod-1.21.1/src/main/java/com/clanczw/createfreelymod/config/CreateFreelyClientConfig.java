package com.clanczw.createfreelymod.config;

import com.clanczw.createfreelymod.CreateFreelyMod;

import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * 客户端配置，生成文件：{@code config/createfreelymod-client.toml}。
 */
public final class CreateFreelyClientConfig {
    public static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();
    public static final ModConfigSpec.EnumValue<JetpackHudAnchor> JETPACK_HUD_ANCHOR;
    public static final ModConfigSpec.BooleanValue JETPACK_HUD_ENABLED;
    public static final ModConfigSpec.IntValue JETPACK_HUD_MARGIN;
    public static final ModConfigSpec.IntValue JETPACK_HUD_RADIUS;
    public static final ModConfigSpec SPEC;

    static {
        BUILDER.comment(
                        "============================================================",
                        " Create Freely Mod — 客户端配置",
                        " 文件：config/createfreelymod-client.toml",
                        " 也可在游戏内修改：模组列表 → Create Freely Mod → 配置",
                        " 切换仪表盘角落快捷键（默认 [）：控制 → Create Freely",
                        " 说明：下列为按键名，请勿改成中文，否则配置无法识别。",
                        "============================================================")
                .push("jetpackHud");

        JETPACK_HUD_ENABLED = BUILDER
                .comment(
                        "【开关】是否显示喷气背包仪表盘。",
                        "穿戴喷气背包时，屏幕角落会画出速度/燃料/模式表盘。",
                        "true = 显示；false = 完全隐藏。")
                .define("enabled", true);
        JETPACK_HUD_ANCHOR = BUILDER
                .comment(
                        "【位置】仪表盘贴在屏幕的哪个角落。",
                        "可选：TOP_LEFT（左上）| TOP_RIGHT（右上）",
                        "      BOTTOM_LEFT（左下）| BOTTOM_RIGHT（右下，默认）",
                        "游戏内也可用快捷键循环切换（默认按键 [）。")
                .defineEnum("anchor", JetpackHudAnchor.BOTTOM_RIGHT);
        JETPACK_HUD_MARGIN = BUILDER
                .comment(
                        "【边距】仪表盘外缘距离屏幕边缘的像素。",
                        "数值越大，表盘越靠屏幕内侧；0 表示紧贴边缘。")
                .defineInRange("margin", 8, 0, 64);
        JETPACK_HUD_RADIUS = BUILDER
                .comment(
                        "【半径】仪表盘半径（GUI 像素）。",
                        "越大表盘越大，越小越不挡视野。建议 20～28。")
                .defineInRange("radius", 24, 16, 48);
        BUILDER.pop();
        SPEC = BUILDER.build();
    }

    private CreateFreelyClientConfig() {
    }

    private static <T> T value(ModConfigSpec.ConfigValue<T> config) {
        return SPEC.isLoaded() ? config.get() : config.getDefault();
    }

    public static boolean isJetpackHudEnabled() {
        return value(JETPACK_HUD_ENABLED);
    }

    public static int jetpackHudMargin() {
        return value(JETPACK_HUD_MARGIN);
    }

    public static int jetpackHudRadius() {
        return value(JETPACK_HUD_RADIUS);
    }

    public static JetpackHudAnchor getJetpackHudAnchor() {
        return value(JETPACK_HUD_ANCHOR);
    }

    public static void setJetpackHudAnchor(JetpackHudAnchor anchor) {
        if (anchor == null || !SPEC.isLoaded()) {
            return;
        }
        try {
            JETPACK_HUD_ANCHOR.set(anchor);
            SPEC.save();
        } catch (RuntimeException ex) {
            CreateFreelyMod.LOGGER.warn("Could not save jetpack HUD anchor preference", ex);
        }
    }

    public static JetpackHudAnchor cycleJetpackHudAnchor() {
        JetpackHudAnchor[] values = JetpackHudAnchor.values();
        JetpackHudAnchor current = getJetpackHudAnchor();
        JetpackHudAnchor next = values[(current.ordinal() + 1) % values.length];
        setJetpackHudAnchor(next);
        return next;
    }
}
