package com.clanczw.createfreelymod.content.jetpack;

import com.clanczw.createfreelymod.CreateFreelyMod;

import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class JetpackNetwork {
    private JetpackNetwork() {
    }

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(CreateFreelyMod.MOD_ID).versioned("1");
        registrar.playToServer(ToggleJetpackModePayload.TYPE, ToggleJetpackModePayload.STREAM_CODEC,
                ToggleJetpackModePayload::handle);
        registrar.playToServer(JetpackJumpPayload.TYPE, JetpackJumpPayload.STREAM_CODEC,
                JetpackJumpPayload::handle);
    }
}
