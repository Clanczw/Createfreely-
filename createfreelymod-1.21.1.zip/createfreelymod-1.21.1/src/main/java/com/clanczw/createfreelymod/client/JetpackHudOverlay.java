package com.clanczw.createfreelymod.client;

import com.clanczw.createfreelymod.CreateFreelyMod;
import com.clanczw.createfreelymod.config.CreateFreelyClientConfig;
import com.clanczw.createfreelymod.config.JetpackHudAnchor;
import com.clanczw.createfreelymod.content.jetpack.FuelJetpackItem;
import com.clanczw.createfreelymod.content.jetpack.JetpackData;
import com.clanczw.createfreelymod.content.jetpack.JetpackFlightMode;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderGuiEvent;

/**
 * Jetpack dial HUD with corner anchoring.
 * <p>
 * Outer speed arc + inner fuel arc; mode caption sits in the open bottom of the dial.
 * HUD corner is changed via config / keybind (no on-dial gear button).
 */
@EventBusSubscriber(modid = CreateFreelyMod.MOD_ID, value = Dist.CLIENT)
public final class JetpackHudOverlay {
    private static final float MAX_SPEED_BPS = 40.0F;
    private static final float ZERO_DEG = 135.0F;
    private static final float SWEEP_DEG = 270.0F;
    private static final float MODE_SCALE = 0.55F;
    private static final int MODE_FLASH_MS = 1600;
    private static final int HUB_RADIUS = 5;

    private static final int COL_FACE = 0xFF0E1218;
    private static final int COL_RIM_HI = 0xFFE8EEF4;
    private static final int COL_RIM = 0xFFB8C0C8;
    private static final int COL_RIM_MID = 0xFF7A848E;
    private static final int COL_RIM_DARK = 0xFF3A424A;
    private static final int COL_SHADOW = 0x66000000;
    private static final int COL_TICK = 0xFFF0F4F8;
    private static final int COL_TICK_DIM = 0xFF5A626A;
    private static final int COL_REDLINE = 0xFFD02828;
    private static final int COL_SPEED = 0xFFE8B840;
    private static final int COL_FUEL = 0xFF38B8E0;
    private static final int COL_FUEL_LOW = 0xFFE04038;
    private static final int COL_MODE = 0xFF9AD8EC;
    private static final int COL_MODE_FLASH = 0xFFE8F6FC;
    private static final int COL_MODE_SHADOW = 0xCC000000;
    private static final int COL_TRACK = 0xFF242A32;
    private static final int COL_HUB = 0xFF1A2028;
    private static final int COL_MODE_BG = 0xAA121820;

    private static float displayedSpeed;
    private static float displayedFuel;
    private static JetpackFlightMode lastMode;
    private static long modeFlashUntilMs;

    private static int dialCx;
    private static int dialCy;
    private static int dialRadius;

    private JetpackHudOverlay() {
    }

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || !CreateFreelyClientConfig.isJetpackHudEnabled()) {
            return;
        }

        ItemStack jetpack = FuelJetpackItem.getWorn(mc.player);
        if (jetpack.isEmpty()) {
            displayedSpeed = 0.0F;
            displayedFuel = 0.0F;
            lastMode = null;
            modeFlashUntilMs = 0L;
            return;
        }

        GuiGraphics graphics = event.getGuiGraphics();
        Font font = mc.font;
        int screenW = mc.getWindow().getGuiScaledWidth();
        int screenH = mc.getWindow().getGuiScaledHeight();
        JetpackHudAnchor anchor = CreateFreelyClientConfig.getJetpackHudAnchor();
        JetpackFlightMode mode = JetpackData.getMode(jetpack);
        if (lastMode != null && lastMode != mode) {
            modeFlashUntilMs = System.currentTimeMillis() + MODE_FLASH_MS;
        }
        lastMode = mode;

        displayedSpeed = Mth.lerp(0.25F, displayedSpeed, (float) (mc.player.getDeltaMovement().length() * 20.0));
        displayedFuel = Mth.lerp(0.2F, displayedFuel,
                JetpackData.getFuel(jetpack) / (float) JetpackData.maxFuel());

        layout(anchor, screenW, screenH);

        drawDialBezel(graphics, dialCx, dialCy, dialRadius);
        drawDial(graphics, font, dialCx, dialCy, dialRadius, displayedSpeed, displayedFuel);
        drawModeLabel(graphics, font, anchor, mode);
    }

    private static void layout(JetpackHudAnchor anchor, int screenW, int screenH) {
        boolean right = anchor == JetpackHudAnchor.TOP_RIGHT || anchor == JetpackHudAnchor.BOTTOM_RIGHT;
        boolean bottom = anchor == JetpackHudAnchor.BOTTOM_LEFT || anchor == JetpackHudAnchor.BOTTOM_RIGHT;
        int margin = CreateFreelyClientConfig.jetpackHudMargin();
        dialRadius = CreateFreelyClientConfig.jetpackHudRadius();

        dialCx = right ? screenW - margin - dialRadius : margin + dialRadius;
        dialCy = bottom ? screenH - margin - dialRadius : margin + dialRadius;
    }

    private static void drawDialBezel(GuiGraphics graphics, int cx, int cy, int radius) {
        fillCircle(graphics, cx + 1, cy + 2, radius + 4, COL_SHADOW);
        fillCircle(graphics, cx, cy, radius + 3, COL_RIM_DARK);
        fillCircle(graphics, cx, cy, radius + 2, COL_RIM_MID);
        fillCircle(graphics, cx, cy, radius + 1, COL_RIM);
        fillCircle(graphics, cx, cy, radius, COL_FACE);
        drawRimHighlight(graphics, cx, cy, radius + 1);
        drawRing(graphics, cx, cy, radius - 1, COL_RIM_DARK, 1);
    }

    private static void drawRimHighlight(GuiGraphics graphics, int cx, int cy, int r) {
        int steps = 28;
        for (int i = 0; i <= steps; i++) {
            float t = i / (float) steps;
            float a = (float) Math.toRadians(-40.0 + t * 110.0);
            int px = cx + Math.round(Mth.cos(a) * r);
            int py = cy + Math.round(Mth.sin(a) * r);
            graphics.fill(px, py, px + 1, py + 1, COL_RIM_HI);
        }
    }

    private static void drawRing(GuiGraphics graphics, int cx, int cy, int r, int color, int thickness) {
        int steps = Math.max(48, r * 6);
        int half = Math.max(0, thickness / 2);
        for (int i = 0; i < steps; i++) {
            float a = (float) (Math.PI * 2.0 * i / steps);
            int px = cx + Math.round(Mth.cos(a) * r);
            int py = cy + Math.round(Mth.sin(a) * r);
            graphics.fill(px - half, py - half, px - half + thickness, py - half + thickness, color);
        }
    }

    private static void drawDial(GuiGraphics graphics, Font font, int cx, int cy, int radius,
            float speed, float fuelRatio) {
        float speedRatio = Mth.clamp(speed, 0.0F, MAX_SPEED_BPS) / MAX_SPEED_BPS;
        float fuel = Mth.clamp(fuelRatio, 0.0F, 1.0F);

        int speedR = radius - 4;
        int fuelR = radius - 9;

        drawArc(graphics, cx, cy, speedR, 0.0F, 1.0F, COL_TRACK, 3);
        drawArc(graphics, cx, cy, fuelR, 0.0F, 1.0F, COL_TRACK, 3);

        drawArc(graphics, cx, cy, speedR, 30.0F / MAX_SPEED_BPS, 1.0F, COL_REDLINE, 3);
        if (speedRatio > 0.005F) {
            drawArc(graphics, cx, cy, speedR, 0.0F, speedRatio, COL_SPEED, 3);
        }

        if (fuel > 0.005F) {
            int fuelColor = fuel > 0.2F ? COL_FUEL : COL_FUEL_LOW;
            drawArc(graphics, cx, cy, fuelR, 0.0F, fuel, fuelColor, 3);
        }

        for (int mark = 0; mark <= (int) MAX_SPEED_BPS; mark += 10) {
            float t = mark / MAX_SPEED_BPS;
            float angle = dialAngle(t);
            boolean major = mark == 0 || mark == 20 || mark == 40;
            drawRadialLine(graphics, cx, cy, angle,
                    major ? radius - 7 : radius - 5,
                    radius - 2,
                    major ? COL_TICK : COL_TICK_DIM);
        }

        // Hub first so scale labels (0 / 40) are not covered by the black ring.
        fillCircle(graphics, cx, cy, HUB_RADIUS, COL_HUB);
        drawRing(graphics, cx, cy, HUB_RADIUS, COL_RIM_DARK, 1);
        String speedText = Integer.toString(Math.round(Mth.clamp(speed, 0.0F, MAX_SPEED_BPS)));
        graphics.drawString(font, speedText,
                cx - font.width(speedText) / 2, cy - 4, COL_TICK, false);

        for (int mark = 0; mark <= (int) MAX_SPEED_BPS; mark += 10) {
            if (mark != 0 && mark != 20 && mark != 40) {
                continue;
            }
            String label = Integer.toString(mark);
            float angle = dialAngle(mark / MAX_SPEED_BPS);
            // Keep 0/40 away from the hub: sit closer to the rim, slight outward angle nudge.
            float labelR = mark == 20 ? radius - 12.0F : radius - 10.0F;
            float nudge = mark == 20 ? 0.0F : (mark == 0 ? -0.18F : 0.18F);
            float la = angle + nudge;
            int lx = cx + Math.round(Mth.cos(la) * labelR) - font.width(label) / 2;
            int ly = cy + Math.round(Mth.sin(la) * labelR) - 4;
            graphics.drawString(font, label, lx, ly, COL_TICK, false);
        }
    }

    /**
     * Mode caption sits inside the dial's open bottom gap, scaled to fit.
     * Mode-switch flash still appears toward screen center.
     */
    private static void drawModeLabel(GuiGraphics graphics, Font font, JetpackHudAnchor anchor,
            JetpackFlightMode mode) {
        boolean right = anchor == JetpackHudAnchor.TOP_RIGHT || anchor == JetpackHudAnchor.BOTTOM_RIGHT;

        Component modeName = Component.translatable(mode.translationKey());
        boolean flashing = System.currentTimeMillis() < modeFlashUntilMs;
        float flashT = flashing
                ? Mth.clamp((modeFlashUntilMs - System.currentTimeMillis()) / (float) MODE_FLASH_MS, 0.0F, 1.0F)
                : 0.0F;
        int color = flashing ? COL_MODE_FLASH : COL_MODE;

        float modeY = dialCy + dialRadius - 9.0F;
        var pose = graphics.pose();
        pose.pushPose();
        pose.translate(dialCx, modeY, 0.0F);
        pose.scale(MODE_SCALE, MODE_SCALE, 1.0F);
        int nameW = font.width(modeName);
        graphics.drawString(font, modeName, -nameW / 2 + 1, -3, COL_MODE_SHADOW, false);
        graphics.drawString(font, modeName, -nameW / 2, -4, color, false);
        pose.popPose();

        if (!flashing) {
            return;
        }

        Component flash = Component.translatable("createfreelymod.hud.jetpack.mode", modeName);
        int flashW = font.width(flash);
        int padX = 4;
        int padY = 2;
        int boxW = flashW + padX * 2;
        int boxH = 9 + padY * 2;
        int gap = dialRadius + 10;
        int boxX = right ? dialCx - gap - boxW : dialCx + gap;
        int boxY = dialCy - boxH / 2;
        int alpha = Mth.clamp(Math.round(flashT * 220), 40, 220);
        int bg = (alpha << 24) | (COL_MODE_BG & 0x00FFFFFF);
        int border = (alpha << 24) | 0x0078A8C0;
        int textAlpha = Mth.clamp(Math.round(flashT * 255), 60, 255);
        int textColor = (textAlpha << 24) | (COL_MODE_FLASH & 0x00FFFFFF);

        graphics.fill(boxX, boxY, boxX + boxW, boxY + boxH, bg);
        graphics.fill(boxX, boxY, boxX + boxW, boxY + 1, border);
        graphics.fill(boxX, boxY + boxH - 1, boxX + boxW, boxY + boxH, border);
        graphics.fill(boxX, boxY, boxX + 1, boxY + boxH, border);
        graphics.fill(boxX + boxW - 1, boxY, boxX + boxW, boxY + boxH, border);
        graphics.drawString(font, flash, boxX + padX, boxY + padY + 1, textColor, false);
    }

    private static float dialAngle(float t) {
        return (float) Math.toRadians(ZERO_DEG + Mth.clamp(t, 0.0F, 1.0F) * SWEEP_DEG);
    }

    private static void drawArc(GuiGraphics graphics, int cx, int cy, int r, float from, float to, int color, int thickness) {
        float span = Math.max(0.0F, to - from);
        int steps = Math.max(6, (int) (span * 96));
        int half = thickness / 2;
        for (int i = 0; i <= steps; i++) {
            float t = from + span * (i / (float) steps);
            float a = dialAngle(t);
            int px = cx + Math.round(Mth.cos(a) * r);
            int py = cy + Math.round(Mth.sin(a) * r);
            graphics.fill(px - half, py - half, px - half + thickness, py - half + thickness, color);
        }
    }

    private static void drawRadialLine(GuiGraphics graphics, int cx, int cy, float angle, int inner, int outer, int color) {
        float cos = Mth.cos(angle);
        float sin = Mth.sin(angle);
        int steps = Math.max(1, outer - inner);
        for (int i = 0; i <= steps; i++) {
            float r = inner + i;
            int px = cx + Math.round(cos * r);
            int py = cy + Math.round(sin * r);
            graphics.fill(px, py, px + 1, py + 1, color);
        }
    }

    private static void fillCircle(GuiGraphics graphics, int cx, int cy, int radius, int color) {
        for (int dy = -radius; dy <= radius; dy++) {
            int span = (int) Math.sqrt(radius * radius - dy * dy);
            graphics.fill(cx - span, cy + dy, cx + span + 1, cy + dy + 1, color);
        }
    }
}
