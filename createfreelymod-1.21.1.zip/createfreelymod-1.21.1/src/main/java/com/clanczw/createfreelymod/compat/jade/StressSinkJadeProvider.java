package com.clanczw.createfreelymod.compat.jade;

import com.clanczw.createfreelymod.content.energy.EnergyFormat;
import com.clanczw.createfreelymod.content.kinetics.StressSinkBlockEntity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import snownee.jade.api.BlockAccessor;
import snownee.jade.api.IBlockComponentProvider;
import snownee.jade.api.IServerDataProvider;
import snownee.jade.api.ITooltip;
import snownee.jade.api.config.IPluginConfig;

public enum StressSinkJadeProvider implements IBlockComponentProvider, IServerDataProvider<BlockAccessor> {
    INSTANCE;

    @Override
    public void appendTooltip(ITooltip tooltip, BlockAccessor accessor, IPluginConfig config) {
        CompoundTag data = accessor.getServerData();
        if (!data.contains("Gen") || !data.contains("Energy") || !data.contains("MaxEnergy")) {
            return;
        }
        tooltip.add(Component.translatable(
                "createfreelymod.jade.generating",
                EnergyFormat.format(data.getInt("Gen"))));
        if (data.contains("Eff")) {
            tooltip.add(Component.translatable(
                    "createfreelymod.jade.efficiency",
                    data.getInt("Eff")));
        }
        tooltip.add(Component.translatable(
                "createfreelymod.jade.energy",
                EnergyFormat.format(data.getInt("Energy")),
                EnergyFormat.format(data.getInt("MaxEnergy"))));
        if (data.getBoolean("Overstressed")) {
            tooltip.add(Component.translatable("createfreelymod.jade.overstressed"));
        }
    }

    @Override
    public void appendServerData(CompoundTag data, BlockAccessor accessor) {
        if (!(accessor.getBlockEntity() instanceof StressSinkBlockEntity be)) {
            return;
        }
        data.putInt("Gen", be.getGeneratingFePerTick());
        data.putInt("Eff", be.getConversionEfficiencyPercent());
        data.putInt("Energy", be.getEnergyStored());
        data.putInt("MaxEnergy", be.getMaxEnergyStored());
        data.putBoolean("Overstressed", be.isOverStressed());
    }

    @Override
    public ResourceLocation getUid() {
        return CreateFreelyModJadePlugin.STRESS_SINK;
    }
}
