package com.clanczw.createfreelymod.content.energy;

import net.neoforged.neoforge.energy.EnergyStorage;

/**
 * 只能「生成」不能从管线吸入的 FE 缓冲（应力汇用）。
 * <p>
 * maxReceive = 0，推送失败退款走 {@link #generate}，避免被邻居反向灌满。
 */
public class GeneratingEnergyStorage extends EnergyStorage {
    public GeneratingEnergyStorage(int capacity, int maxExtract) {
        super(capacity, 0, maxExtract);
    }

    public int generate(int amount) {
        int accepted = Math.min(capacity - energy, Math.max(0, amount));
        energy += accepted;
        return accepted;
    }

    public void setStoredEnergy(int value) {
        energy = Math.max(0, Math.min(capacity, value));
    }

    public void setCapacity(int newCapacity) {
        capacity = Math.max(1, newCapacity);
        maxExtract = capacity;
        energy = Math.min(energy, capacity);
    }
}
