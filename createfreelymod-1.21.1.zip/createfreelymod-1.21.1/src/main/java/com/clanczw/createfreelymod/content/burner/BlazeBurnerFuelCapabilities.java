package com.clanczw.createfreelymod.content.burner;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.content.processing.burner.BlazeBurnerBlockEntity;

import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;

public final class BlazeBurnerFuelCapabilities {
    /**
     * Cache only. Buffered mB is persisted on the BE via {@link net.minecraft.world.level.block.entity.BlockEntity#getPersistentData()}.
     */
    private static final Map<BlazeBurnerBlockEntity, BlazeBurnerFluidHandler> FLUID_HANDLERS =
            Collections.synchronizedMap(new WeakHashMap<>());

    private BlazeBurnerFuelCapabilities() {
    }

    public static void register(RegisterCapabilitiesEvent event) {
        // Note: NeoForge keeps one FluidHandler provider per BE type. Other mods that also
        // attach fluids to Create's HEATER will conflict; load-order last-writer wins.
        event.registerBlockEntity(
                Capabilities.FluidHandler.BLOCK,
                AllBlockEntityTypes.HEATER.get(),
                // side == null: allow probes / null-facing lookups (pipes still pass a side)
                (be, side) -> {
                    if (be.isRemoved()) {
                        return null;
                    }
                    return FLUID_HANDLERS.computeIfAbsent(be, BlazeBurnerFluidHandler::new);
                });
    }
}
