package com.clanczw.createfreelymod.content.burner;

import java.util.List;

import com.clanczw.createfreelymod.ModBlockEntityTypes;
import com.clanczw.createfreelymod.ModFluids;
import com.clanczw.createfreelymod.config.CreateFreelyCommonConfig;
import com.simibubi.create.api.equipment.goggles.IHaveGoggleInformation;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.fluid.SmartFluidTankBehaviour;
import com.simibubi.create.foundation.fluid.FluidHelper;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.fluids.FluidStack;

/**
 * 流体燃烧室：一桶容积的催化剂槽，给风扇气流换加工类型。
 * <p>
 * <b>思路</b>：水 → 洗涤（splashing）；岩浆 / 天蓝燃料 → 冶炼（blasting）。
 * 不自己烧燃料产热，只当风扇「空气催化剂」；真实加热仍走原版烈焰人 + 管道燃料扩展。
 */
public class FluidBurnerBlockEntity extends SmartBlockEntity implements IHaveGoggleInformation {
    private SmartFluidTankBehaviour tank;

    public FluidBurnerBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(
                Capabilities.FluidHandler.BLOCK,
                ModBlockEntityTypes.FLUID_BURNER.get(),
                (be, context) -> be.tank.getCapability());
    }

    @Override
    public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
        tank = SmartFluidTankBehaviour.single(this, CreateFreelyCommonConfig.fluidBurnerCapacityMb());
        tank.getPrimaryHandler().setValidator(FluidBurnerBlockEntity::isValidFluid);
        behaviours.add(tank);
    }

    public FluidStack getFluid() {
        return tank == null ? FluidStack.EMPTY : tank.getPrimaryHandler().getFluid();
    }

    public SmartFluidTankBehaviour getTank() {
        return tank;
    }

    public boolean providesSplashing() {
        FluidStack fluid = getFluid();
        return !fluid.isEmpty() && FluidHelper.isTag(fluid, FluidTags.WATER);
    }

    public boolean providesBlasting() {
        FluidStack fluid = getFluid();
        if (fluid.isEmpty()) {
            return false;
        }
        return FluidHelper.isTag(fluid, FluidTags.LAVA) || ModFluids.isAzureFuel(fluid);
    }

    public static boolean isValidFluid(FluidStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        if (FluidHelper.isTag(stack, FluidTags.WATER) || FluidHelper.isTag(stack, FluidTags.LAVA)) {
            return true;
        }
        return ModFluids.isAzureFuel(stack);
    }

    @Override
    public boolean addToGoggleTooltip(List<Component> tooltip, boolean isPlayerSneaking) {
        return containedFluidTooltip(tooltip, isPlayerSneaking,
                level.getCapability(Capabilities.FluidHandler.BLOCK, worldPosition, null));
    }
}
