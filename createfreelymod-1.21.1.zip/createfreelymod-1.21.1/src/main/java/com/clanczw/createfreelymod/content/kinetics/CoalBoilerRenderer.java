package com.clanczw.createfreelymod.content.kinetics;

import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.kinetics.base.KineticBlockEntityRenderer;

import net.createmod.catnip.render.CachedBuffers;
import net.createmod.catnip.render.SuperByteBuffer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * Half-shaft sits in the rear tunnel so the brass casing wraps the rod.
 */
public class CoalBoilerRenderer extends KineticBlockEntityRenderer<CoalBoilerBlockEntity> {
    public CoalBoilerRenderer(BlockEntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public boolean shouldRenderOffScreen(CoalBoilerBlockEntity be) {
        return true;
    }

    @Override
    public AABB getRenderBoundingBox(CoalBoilerBlockEntity blockEntity) {
        return new AABB(blockEntity.getBlockPos()).inflate(0.25D);
    }

    @Override
    protected SuperByteBuffer getRotatedModel(CoalBoilerBlockEntity be, BlockState state) {
        Direction shaft = CoalBoilerBlock.getShaftFacing(state);
        return CachedBuffers.partialFacing(AllPartialModels.SHAFT_HALF, state, shaft);
    }
}
