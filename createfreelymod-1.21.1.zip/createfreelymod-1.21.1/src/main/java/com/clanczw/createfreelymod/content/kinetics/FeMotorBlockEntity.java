package com.clanczw.createfreelymod.content.kinetics;

import java.util.List;

import com.clanczw.createfreelymod.ModBlockEntityTypes;
import com.clanczw.createfreelymod.config.CreateFreelyCommonConfig;
import com.clanczw.createfreelymod.content.energy.EnergyBlockSync;
import com.clanczw.createfreelymod.content.energy.ModEnergyStorage;
import com.simibubi.create.content.kinetics.base.GeneratingKineticBlockEntity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.energy.IEnergyStorage;

/**
 * FE → Create 动力马达（方案 A：与应力发电机共用转速分档能效）。
 * <p>
 * 按可用 FE 自动升档；耗电 FE/t = RPM × fePerRpm ÷ 档位效率；
 * |RPM| &lt; minRpm 不出力；应力容量 = RPM × stressPerRpm（不分档）。
 * FE 仅从朝向反面吸入，轴面留给 Create 动能连接。
 */
public class FeMotorBlockEntity extends GeneratingKineticBlockEntity {
    /** Fallback for Jade / tooltips when packet omits max RPM. */
    public static final int MAX_RPM = 256;
    private static final int ENERGY_SYNC_INTERVAL = 10;

    private final ModEnergyStorage energy = new ModEnergyStorage(10_000);

    private int generatedRpm;
    private float stressCapacity;
    private int lastConsumedFe;
    private int resolvedRpm;
    private int resolvedCost;
    private int lastSyncedEnergy = Integer.MIN_VALUE;

    public FeMotorBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    public int getEnergyStored() {
        return energy.getEnergyStored();
    }

    public int getMaxEnergyStored() {
        return energy.getMaxEnergyStored();
    }

    public int getGeneratedRpm() {
        return generatedRpm;
    }

    public float getStressCapacityValue() {
        return stressCapacity;
    }

    public int getLastConsumedFe() {
        return lastConsumedFe;
    }

    public int getMaxRpm() {
        return CreateFreelyCommonConfig.feMotorMaxRpm();
    }

    /** Current tier efficiency percent (0 if below min RPM / idle). */
    public int getEfficiencyPercent() {
        if (generatedRpm <= 0) {
            return 0;
        }
        return (int) Math.round(CreateFreelyCommonConfig.feMotorEfficiencyForRpm(generatedRpm) * 100.0D);
    }

    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(
                Capabilities.EnergyStorage.BLOCK,
                ModBlockEntityTypes.FE_MOTOR.get(),
                (be, side) -> be.getEnergyCapability(side));
    }

    public IEnergyStorage getEnergyCapability(Direction side) {
        Direction facing = getBlockState().getValue(FeMotorBlock.FACING);
        if (side == null || side == facing.getOpposite()) {
            return energy;
        }
        return null;
    }

    private void syncCapacityFromConfig() {
        int cap = CreateFreelyCommonConfig.feMotorEnergyCapacity();
        if (energy.getMaxEnergyStored() != cap) {
            energy.setCapacity(cap);
        }
    }

    /**
     * Pick the highest RPM step affordable with the current buffer.
     */
    private void resolveRpmAndCost(int availableEnergy) {
        int maxRpm = Math.max(1, CreateFreelyCommonConfig.feMotorMaxRpm());
        int minRpm = CreateFreelyCommonConfig.stressSinkMinRpm();
        int step = Math.min(maxRpm, CreateFreelyCommonConfig.feMotorRpmStep());
        int rpm = maxRpm - (maxRpm % step);
        while (rpm > 0) {
            if (rpm < minRpm) {
                break;
            }
            int cost = CreateFreelyCommonConfig.feMotorFeCostForRpm(rpm);
            if (cost != Integer.MAX_VALUE && cost <= availableEnergy) {
                resolvedRpm = rpm;
                resolvedCost = cost;
                return;
            }
            rpm -= step;
        }
        resolvedRpm = 0;
        resolvedCost = 0;
    }

    @Override
    public void initialize() {
        super.initialize();
        if (!hasSource() || Math.abs(getGeneratedSpeed()) > Math.abs(getTheoreticalSpeed())) {
            updateGeneratedRotation();
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (level == null || level.isClientSide) {
            return;
        }

        syncCapacityFromConfig();
        boolean energyChanged = pullFromBack();

        resolveRpmAndCost(energy.getEnergyStored());
        int newRpm = resolvedRpm;
        int consume = resolvedCost;
        if (consume > 0) {
            energy.extractEnergy(consume, false);
            energyChanged = true;
        }
        lastConsumedFe = consume;

        boolean rotationChanged = false;
        float newCapacity = CreateFreelyCommonConfig.feMotorStressForRpm(newRpm);
        if (newRpm != generatedRpm || Float.compare(newCapacity, stressCapacity) != 0) {
            generatedRpm = newRpm;
            stressCapacity = newCapacity;
            updateGeneratedRotation();
            rotationChanged = true;
        }

        if (energyChanged || rotationChanged) {
            setChanged();
            syncToClient(rotationChanged);
        }
    }

    private void syncToClient(boolean force) {
        int stored = energy.getEnergyStored();
        if (EnergyBlockSync.shouldSyncEnergy(
                stored, energy.getMaxEnergyStored(), lastSyncedEnergy,
                level.getGameTime(), ENERGY_SYNC_INTERVAL, force)) {
            sendData();
            lastSyncedEnergy = stored;
        }
    }

    private boolean pullFromBack() {
        Direction facing = getBlockState().getValue(FeMotorBlock.FACING);
        Direction back = facing.getOpposite();
        int space = energy.getMaxEnergyStored() - energy.getEnergyStored();
        if (space <= 0) {
            return false;
        }

        IEnergyStorage source = level.getCapability(
                Capabilities.EnergyStorage.BLOCK,
                worldPosition.relative(back),
                facing);
        if (source == null || !source.canExtract()) {
            return false;
        }

        int canExtract = source.extractEnergy(space, true);
        if (canExtract <= 0) {
            return false;
        }
        int extracted = source.extractEnergy(canExtract, false);
        if (extracted <= 0) {
            return false;
        }
        energy.receiveEnergy(extracted, false);
        return true;
    }

    @Override
    public float getGeneratedSpeed() {
        return convertToDirection(generatedRpm, getBlockState().getValue(FeMotorBlock.FACING));
    }

    @Override
    public float calculateAddedStressCapacity() {
        this.lastCapacityProvided = stressCapacity;
        return stressCapacity;
    }

    @Override
    protected void write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(tag, registries, clientPacket);
        tag.putInt("Energy", energy.getEnergyStored());
        tag.putInt("GeneratedRpm", generatedRpm);
        tag.putFloat("StressCapacity", stressCapacity);
        tag.putInt("LastConsumedFe", lastConsumedFe);
    }

    @Override
    protected void read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.read(tag, registries, clientPacket);
        syncCapacityFromConfig();
        energy.setStoredEnergy(tag.getInt("Energy"));
        generatedRpm = tag.getInt("GeneratedRpm");
        stressCapacity = tag.getFloat("StressCapacity");
        lastConsumedFe = tag.getInt("LastConsumedFe");
    }

    @Override
    public boolean addToGoggleTooltip(List<Component> tooltip, boolean isPlayerSneaking) {
        super.addToGoggleTooltip(tooltip, isPlayerSneaking);

        KineticTooltips.addLabeledValue(tooltip, "createfreelymod.tooltip.fe_motor.consuming",
                lastConsumedFe + " FE/t");
        KineticTooltips.addLabeledValue(tooltip, "createfreelymod.tooltip.fe_motor.efficiency",
                getEfficiencyPercent() + "%");
        KineticTooltips.addLabeledValue(tooltip, "createfreelymod.tooltip.fe_motor.speed",
                generatedRpm + " / " + getMaxRpm() + " RPM");
        KineticTooltips.addLabeledValue(tooltip, "createfreelymod.tooltip.fe_motor.capacity",
                Math.round(stressCapacity) + " SU");
        KineticTooltips.addLabeledValue(tooltip, "createfreelymod.tooltip.fe_motor.stored",
                energy.getEnergyStored() + " / " + energy.getMaxEnergyStored() + " FE");
        return true;
    }
}
