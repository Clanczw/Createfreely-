package com.clanczw.createfreelymod.content.energy;

public enum CreativeCapacitorMode {
    FULL,
    EMPTY
}
