package com.clanczw.createfreelymod.content.energy;

import com.clanczw.createfreelymod.config.CreateFreelyCommonConfig;

public enum CapacitorTier {
    LOW("low", 2.0f, 0),
    MEDIUM("medium", 2.5f, 2),
    HIGH("high", 3.0f, 4);

    private final String idSuffix;
    private final float strength;
    private final int lightLevel;

    CapacitorTier(String idSuffix, float strength, int lightLevel) {
        this.idSuffix = idSuffix;
        this.strength = strength;
        this.lightLevel = lightLevel;
    }

    public int getCapacity() {
        return switch (this) {
            case LOW -> CreateFreelyCommonConfig.capacitorLowCapacity();
            case MEDIUM -> CreateFreelyCommonConfig.capacitorMediumCapacity();
            case HIGH -> CreateFreelyCommonConfig.capacitorHighCapacity();
        };
    }

    public String getIdSuffix() {
        return idSuffix;
    }

    public float getStrength() {
        return strength;
    }

    public int getLightLevel() {
        return lightLevel;
    }
}
