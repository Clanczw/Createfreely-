package com.clanczw.createfreelymod.content.ponder;

import com.clanczw.createfreelymod.CreateFreelyMod;
import com.clanczw.createfreelymod.ModBlocks;
import com.clanczw.createfreelymod.ModItems;

import net.createmod.ponder.api.registration.PonderPlugin;
import net.createmod.ponder.api.registration.PonderSceneRegistrationHelper;
import net.minecraft.resources.ResourceLocation;

/**
 * Registers in-game Ponder (思索) scenes for Create Freely blocks and items.
 */
public class CreateFreelyPonderPlugin implements PonderPlugin {
    @Override
    public String getModId() {
        return CreateFreelyMod.MOD_ID;
    }

    @Override
    public void registerScenes(PonderSceneRegistrationHelper<ResourceLocation> helper) {
        helper.forComponents(ModBlocks.STRESS_SINK.getId())
                .addStoryBoard("stress_sink", CreateFreelyPonderScenes::stressSink);

        helper.forComponents(ModBlocks.FE_MOTOR.getId())
                .addStoryBoard("fe_motor", CreateFreelyPonderScenes::feMotor);

        helper.forComponents(ModBlocks.FLUID_BURNER.getId())
                .addStoryBoard("fluid_burner", CreateFreelyPonderScenes::fluidBurner);

        helper.forComponents(ModBlocks.COAL_BOILER.getId())
                .addStoryBoard("coal_boiler", CreateFreelyPonderScenes::coalBoiler);

        helper.forComponents(
                        ModBlocks.CAPACITOR_LOW.getId(),
                        ModBlocks.CAPACITOR_MEDIUM.getId(),
                        ModBlocks.CAPACITOR_HIGH.getId())
                .addStoryBoard("capacitor", CreateFreelyPonderScenes::capacitor);

        helper.forComponents(ModItems.FUEL_JETPACK.getId())
                .addStoryBoard("fuel_jetpack", CreateFreelyPonderScenes::fuelJetpack);
    }
}
