package com.clanczw.createfreelymod.content.kinetics;

import java.util.List;

import org.jetbrains.annotations.Nullable;

import com.clanczw.createfreelymod.ModBlockEntityTypes;
import com.clanczw.createfreelymod.config.CreateFreelyCommonConfig;
import com.clanczw.createfreelymod.content.energy.EnergyBlockSync;
import com.clanczw.createfreelymod.content.energy.EnergyTransfer;
import com.clanczw.createfreelymod.content.energy.GeneratingEnergyStorage;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.energy.IEnergyStorage;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.IItemHandlerModifiable;

/**
 * 应力汇：Create 转速 → FE（对齐 Crafts &amp; Additions 交流发电机思路）。
 * <p>
 * 默认：应力冲击 64×RPM、≥16 RPM 才发电；
 * FE/t = |RPM| × fePerRpm × 分档效率（16–64→75%，64–128→80%，128–256→85%）。
 * 轴面不暴露 FE；向邻居推电，并给相邻容器内 FE 物品充电。过应力时停发。
 */
public class StressSinkBlockEntity extends KineticBlockEntity {
    /** Client energy sync interval (ticks) while generating / transferring. */
    private static final int ENERGY_SYNC_INTERVAL = 10;

    private final GeneratingEnergyStorage energy = new GeneratingEnergyStorage(10_000, 10_000);
    private int lastSyncedEnergy = Integer.MIN_VALUE;

    public StressSinkBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    public int getEnergyStored() {
        return energy.getEnergyStored();
    }

    public int getMaxEnergyStored() {
        return energy.getMaxEnergyStored();
    }

    public int getGeneratingFePerTick() {
        if (isOverStressed()) {
            return 0;
        }
        return CreateFreelyCommonConfig.stressSinkFePerTick(getSpeed());
    }

    public int getConversionEfficiencyPercent() {
        return (int) Math.round(CreateFreelyCommonConfig.stressSinkEfficiencyForRpm(getSpeed()) * 100.0D);
    }

    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(
                Capabilities.EnergyStorage.BLOCK,
                ModBlockEntityTypes.STRESS_SINK.get(),
                (be, side) -> be.getEnergyCapability(side));
    }

    public IEnergyStorage getEnergyCapability(Direction side) {
        Direction shaft = getBlockState().getValue(StressSinkBlock.FACING);
        if (side == shaft) {
            return null;
        }
        return energy;
    }

    private void syncCapacityFromConfig() {
        int cap = CreateFreelyCommonConfig.stressSinkEnergyCapacity();
        if (energy.getMaxEnergyStored() != cap) {
            energy.setCapacity(cap);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (level == null || level.isClientSide) {
            return;
        }

        syncCapacityFromConfig();

        boolean changed = false;
        int generated = getGeneratingFePerTick();
        if (generated > 0) {
            int produced = energy.generate(generated);
            if (produced > 0) {
                changed = true;
            }
        }

        Direction shaft = getBlockState().getValue(StressSinkBlock.FACING);
        // Generators must always feed neighbors — not only when theirs < ours.
        // Otherwise a fuller capacitor left after removing a mid link never gets charged.
        if (EnergyTransfer.pushToNeighbors(level, worldPosition, energy, shaft, energy::generate, false)) {
            changed = true;
        }

        if (chargeAdjacentInventories()) {
            changed = true;
        }

        if (changed) {
            setChanged();
            syncEnergyToClient(false);
        }
    }

    private void syncEnergyToClient(boolean force) {
        int stored = energy.getEnergyStored();
        if (EnergyBlockSync.shouldSyncEnergy(
                stored, energy.getMaxEnergyStored(), lastSyncedEnergy,
                level.getGameTime(), ENERGY_SYNC_INTERVAL, force)) {
            sendData();
            lastSyncedEnergy = stored;
        }
    }

    private boolean chargeAdjacentInventories() {
        int perTick = CreateFreelyCommonConfig.stressSinkDepotChargePerTick();
        if (perTick <= 0 || energy.getEnergyStored() <= 0) {
            return false;
        }
        boolean moved = false;
        for (Direction dir : EnergyTransfer.DIRECTIONS) {
            if (energy.getEnergyStored() <= 0) {
                break;
            }
            IItemHandler items = level.getCapability(
                    Capabilities.ItemHandler.BLOCK,
                    worldPosition.relative(dir),
                    dir.getOpposite());
            if (items == null) {
                continue;
            }
            for (int slot = 0; slot < items.getSlots(); slot++) {
                if (energy.getEnergyStored() <= 0) {
                    break;
                }
                if (items instanceof IItemHandlerModifiable modifiable) {
                    moved |= chargeStackInPlace(modifiable, slot, perTick);
                } else {
                    moved |= chargeStackExtractInsert(items, slot, perTick);
                }
            }
        }
        return moved;
    }

    private boolean chargeStackInPlace(IItemHandlerModifiable items, int slot, int perTick) {
        ItemStack stack = items.getStackInSlot(slot);
        if (stack.isEmpty()) {
            return false;
        }
        IEnergyStorage itemEnergy = stack.getCapability(Capabilities.EnergyStorage.ITEM);
        int received = transferToItem(itemEnergy, perTick);
        if (received <= 0) {
            return false;
        }
        items.setStackInSlot(slot, stack);
        return true;
    }

    private boolean chargeStackExtractInsert(IItemHandler items, int slot, int perTick) {
        ItemStack peeked = items.getStackInSlot(slot);
        if (peeked.isEmpty()) {
            return false;
        }
        IEnergyStorage probe = peeked.getCapability(Capabilities.EnergyStorage.ITEM);
        if (probe == null || !probe.canReceive()) {
            return false;
        }

        ItemStack stack = items.extractItem(slot, peeked.getCount(), false);
        if (stack.isEmpty()) {
            return false;
        }
        IEnergyStorage itemEnergy = stack.getCapability(Capabilities.EnergyStorage.ITEM);
        int received = transferToItem(itemEnergy, perTick);
        ItemStack leftover = items.insertItem(slot, stack, false);
        if (!leftover.isEmpty()) {
            if (received > 0) {
                energy.generate(received);
            }
            return false;
        }
        return received > 0;
    }

    private int transferToItem(@Nullable IEnergyStorage itemEnergy, int perTick) {
        if (itemEnergy == null || !itemEnergy.canReceive()) {
            return 0;
        }
        int want = Math.min(perTick, energy.getEnergyStored());
        int canAccept = itemEnergy.receiveEnergy(want, true);
        if (canAccept <= 0) {
            return 0;
        }
        int extracted = energy.extractEnergy(canAccept, false);
        int received = itemEnergy.receiveEnergy(extracted, false);
        if (received < extracted) {
            energy.generate(extracted - received);
        }
        return received;
    }

    @Override
    protected void write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(tag, registries, clientPacket);
        tag.putInt("Energy", energy.getEnergyStored());
    }

    @Override
    protected void read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.read(tag, registries, clientPacket);
        syncCapacityFromConfig();
        energy.setStoredEnergy(tag.getInt("Energy"));
    }

    @Override
    public boolean addToGoggleTooltip(List<Component> tooltip, boolean isPlayerSneaking) {
        super.addToGoggleTooltip(tooltip, isPlayerSneaking);

        KineticTooltips.addLabeledValue(tooltip, "createfreelymod.tooltip.stress_sink.generating",
                getGeneratingFePerTick() + " FE/t");
        KineticTooltips.addLabeledValue(tooltip, "createfreelymod.tooltip.stress_sink.efficiency",
                getConversionEfficiencyPercent() + "%");
        KineticTooltips.addLabeledValue(tooltip, "createfreelymod.tooltip.stress_sink.stored",
                energy.getEnergyStored() + " / " + energy.getMaxEnergyStored() + " FE");
        tooltip.add(Component.literal("    ")
                .append(Component.translatable("createfreelymod.tooltip.stress_sink.depot_charge")
                        .withStyle(ChatFormatting.GRAY)));
        if (Math.abs(getSpeed()) > 0.0F
                && Math.abs(getSpeed()) < CreateFreelyCommonConfig.stressSinkMinRpm()) {
            tooltip.add(Component.literal("    ")
                    .append(Component.translatable("createfreelymod.tooltip.stress_sink.min_rpm",
                                    CreateFreelyCommonConfig.stressSinkMinRpm())
                            .withStyle(ChatFormatting.GOLD)));
        }
        if (isOverStressed()) {
            tooltip.add(Component.literal("    ")
                    .append(Component.translatable("createfreelymod.tooltip.stress_sink.overstressed")
                            .withStyle(ChatFormatting.RED)));
        }
        return true;
    }
}
