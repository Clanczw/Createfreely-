package com.clanczw.createfreelymod;

import com.clanczw.createfreelymod.content.kinetics.CoalBoilerMenu;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModMenuTypes {
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(Registries.MENU, CreateFreelyMod.MOD_ID);

    public static final DeferredHolder<MenuType<?>, MenuType<CoalBoilerMenu>> COAL_BOILER =
            MENUS.register("coal_boiler", () -> IMenuTypeExtension.create(CoalBoilerMenu::new));

    public static void register(IEventBus modEventBus) {
        MENUS.register(modEventBus);
    }

    private ModMenuTypes() {
    }
}
