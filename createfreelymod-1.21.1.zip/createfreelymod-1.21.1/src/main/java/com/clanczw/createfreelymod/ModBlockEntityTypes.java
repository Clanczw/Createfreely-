package com.clanczw.createfreelymod;

import com.clanczw.createfreelymod.content.burner.FluidBurnerBlockEntity;
import com.clanczw.createfreelymod.content.burner.FluidBurnerRenderer;
import com.clanczw.createfreelymod.content.energy.CapacitorBlockEntity;
import com.clanczw.createfreelymod.content.energy.CreativeCapacitorBlockEntity;
import com.clanczw.createfreelymod.content.kinetics.CoalBoilerBlock;
import com.clanczw.createfreelymod.content.kinetics.CoalBoilerBlockEntity;
import com.clanczw.createfreelymod.content.kinetics.CoalBoilerRenderer;
import com.clanczw.createfreelymod.content.kinetics.FeMotorBlockEntity;
import com.clanczw.createfreelymod.content.kinetics.HalfShaftRenderer;
import com.clanczw.createfreelymod.content.kinetics.ModPartialModels;
import com.clanczw.createfreelymod.content.kinetics.StressSinkBlockEntity;
import com.clanczw.createfreelymod.content.kinetics.StressSinkRenderer;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.kinetics.base.OrientedRotatingVisual;
import com.tterrag.registrate.util.entry.BlockEntityEntry;

import dev.engine_room.flywheel.lib.model.Models;

import net.minecraft.core.Direction;

public final class ModBlockEntityTypes {
    public static final BlockEntityEntry<FluidBurnerBlockEntity> FLUID_BURNER =
            CreateFreelyMod.REGISTRATE
                    .blockEntity("fluid_burner", FluidBurnerBlockEntity::new)
                    .validBlock(ModBlocks.FLUID_BURNER)
                    .renderer(() -> FluidBurnerRenderer::new)
                    .register();

    public static final BlockEntityEntry<StressSinkBlockEntity> STRESS_SINK =
            CreateFreelyMod.REGISTRATE
                    .blockEntity("stress_sink", StressSinkBlockEntity::new)
                    .visual(() -> OrientedRotatingVisual.of(ModPartialModels.SHAFT_STUB), false)
                    .validBlock(ModBlocks.STRESS_SINK)
                    .renderer(() -> StressSinkRenderer::new)
                    .register();

    public static final BlockEntityEntry<FeMotorBlockEntity> FE_MOTOR =
            CreateFreelyMod.REGISTRATE
                    .blockEntity("fe_motor", FeMotorBlockEntity::new)
                    .visual(() -> OrientedRotatingVisual.of(AllPartialModels.SHAFT_HALF), false)
                    .validBlock(ModBlocks.FE_MOTOR)
                    .renderer(() -> HalfShaftRenderer::new)
                    .register();

    public static final BlockEntityEntry<CoalBoilerBlockEntity> COAL_BOILER =
            CreateFreelyMod.REGISTRATE
                    .blockEntity("coal_boiler", CoalBoilerBlockEntity::new)
                    .visual(() -> (context, blockEntity, partialTick) -> new OrientedRotatingVisual<>(
                            context,
                            blockEntity,
                            partialTick,
                            Direction.SOUTH,
                            CoalBoilerBlock.getShaftFacing(blockEntity.getBlockState()),
                            Models.partial(AllPartialModels.SHAFT_HALF)), false)
                    .validBlock(ModBlocks.COAL_BOILER)
                    .renderer(() -> CoalBoilerRenderer::new)
                    .register();

    public static final BlockEntityEntry<CapacitorBlockEntity> CAPACITOR =
            CreateFreelyMod.REGISTRATE
                    .blockEntity("capacitor", CapacitorBlockEntity::new)
                    .validBlocks(ModBlocks.CAPACITOR_LOW, ModBlocks.CAPACITOR_MEDIUM, ModBlocks.CAPACITOR_HIGH)
                    .register();

    public static final BlockEntityEntry<CreativeCapacitorBlockEntity> CREATIVE_CAPACITOR =
            CreateFreelyMod.REGISTRATE
                    .blockEntity("creative_capacitor", CreativeCapacitorBlockEntity::new)
                    .validBlocks(ModBlocks.CREATIVE_CAPACITOR_FULL, ModBlocks.CREATIVE_CAPACITOR_EMPTY)
                    .register();

    public static void init() {
    }

    private ModBlockEntityTypes() {
    }
}
