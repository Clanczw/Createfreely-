package com.clanczw.createfreelymod.compat.curios;

import com.clanczw.createfreelymod.client.FuelJetpackClientExtensions;
import com.clanczw.createfreelymod.client.FuelJetpackModel;
import com.clanczw.createfreelymod.content.jetpack.FuelJetpackItem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import top.theillusivec4.curios.api.SlotContext;
import top.theillusivec4.curios.api.client.ICurioRenderer;

/**
 * 背饰槽渲染：复用胸甲手写 {@link FuelJetpackModel}。
 * 胸甲已穿喷气背包时跳过，避免双模型叠画。
 */
public final class JetpackCurioRenderer implements ICurioRenderer {
    @Override
    @SuppressWarnings({"rawtypes", "unchecked"})
    public <T extends LivingEntity, M extends EntityModel<T>> void render(
            ItemStack stack,
            SlotContext slotContext,
            PoseStack poseStack,
            RenderLayerParent<T, M> renderLayerParent,
            MultiBufferSource buffer,
            int light,
            float limbSwing,
            float limbSwingAmount,
            float partialTicks,
            float ageInTicks,
            float netHeadYaw,
            float headPitch) {
        LivingEntity entity = slotContext.entity();
        if (FuelJetpackItem.isWornAsChest(entity)) {
            return;
        }
        if (!(renderLayerParent.getModel() instanceof HumanoidModel humanoidModel)) {
            return;
        }

        FuelJetpackModel model = FuelJetpackClientExtensions.INSTANCE.model();
        humanoidModel.copyPropertiesTo(model);
        ICurioRenderer.followBodyRotations(entity, model);
        model.prepareForRender();
        model.applyJetpackAnimation(entity, stack, ageInTicks);

        VertexConsumer consumer = ItemRenderer.getArmorFoilBuffer(
                buffer,
                RenderType.armorCutoutNoCull(FuelJetpackModel.TEXTURE),
                stack.hasFoil());
        model.renderToBuffer(poseStack, consumer, light, OverlayTexture.NO_OVERLAY);
    }
}
