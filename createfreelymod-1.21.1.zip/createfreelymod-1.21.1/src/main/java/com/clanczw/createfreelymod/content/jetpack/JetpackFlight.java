package com.clanczw.createfreelymod.content.jetpack;

import com.clanczw.createfreelymod.CreateFreelyMod;
import com.clanczw.createfreelymod.config.CreateFreelyCommonConfig;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.common.NeoForgeMod;

/**
 * 喷气背包飞行逻辑（服务端权威，客户端镜像用于动画/手感）。
 * <p>
 * <b>思路</b>：跳跃键由客户端经 {@link JetpackJumpPayload} 同步，避免服务端读不到 keyJump。
 * NORMAL：按住上升，松开时加快下落但仍消掉摔落伤害；HOVER：通过 {@link NeoForgeMod#CREATIVE_FLIGHT}
 * 临时授权飞行，耗油更省。卸下背包或没油时 {@link #clearHover} 收回权限。
 */
public final class JetpackFlight {
    public static final String HOVER_FLAG = "createfreelymod:jetpack_hover";
    public static final String JUMP_FLAG = "createfreelymod:jetpack_jump";
    private static final String NO_FUEL_COOLDOWN = "createfreelymod:jetpack_nofuel_cd";
    private static final ResourceLocation HOVER_FLIGHT_ID =
            ResourceLocation.fromNamespaceAndPath(CreateFreelyMod.MOD_ID, "jetpack_hover_flight");
    private static final AttributeModifier HOVER_FLIGHT_MODIFIER = new AttributeModifier(
            HOVER_FLIGHT_ID, 1.0, AttributeModifier.Operation.ADD_VALUE);

    private JetpackFlight() {
    }

    public static int thrustFuelPerTick() {
        return CreateFreelyCommonConfig.jetpackThrustFuelPerTick();
    }

    public static int hoverFuelPerTick() {
        return CreateFreelyCommonConfig.jetpackHoverFuelPerTick();
    }

    public static boolean isHoldingJump(Player player) {
        return player.getPersistentData().getBoolean(JUMP_FLAG);
    }

    public static void setHoldingJump(Player player, boolean jumping) {
        player.getPersistentData().putBoolean(JUMP_FLAG, jumping);
    }

    public static boolean isJetting(LivingEntity entity, ItemStack jetpack) {
        if (jetpack.isEmpty()) {
            return false;
        }
        if (!(entity instanceof Player player)) {
            return false;
        }
        boolean creative = player.getAbilities().instabuild;
        JetpackData.State state = JetpackData.readState(jetpack);
        if (!creative && state.fuel() <= 0) {
            return false;
        }
        if (state.mode() == JetpackFlightMode.HOVER) {
            return player.getAbilities().flying;
        }
        return isHoldingJump(player);
    }

    public static void tick(Player player, ItemStack jetpack) {
        if (jetpack.isEmpty()) {
            clearHover(player);
            return;
        }

        JetpackData.State state = JetpackData.readState(jetpack);
        if (!state.initialized()) {
            JetpackData.setFuel(jetpack, 0);
            state = new JetpackData.State(true, 0, JetpackFlightMode.NORMAL);
        }

        boolean creative = player.getAbilities().instabuild;
        if (state.mode() == JetpackFlightMode.HOVER) {
            tickHover(player, jetpack, creative, state.fuel());
        } else {
            clearHover(player);
            tickNormal(player, jetpack, creative, state.fuel());
        }
    }

    private static void tickNormal(Player player, ItemStack jetpack, boolean creative, int fuel) {
        int thrustCost = thrustFuelPerTick();
        boolean wantsThrust = isHoldingJump(player);
        boolean canThrust = wantsThrust && (creative || fuel >= thrustCost);
        boolean airborne = !player.onGround();

        if (wantsThrust && !canThrust) {
            warnNoFuel(player);
        }

        if (canThrust) {
            if (!creative && !player.level().isClientSide()) {
                JetpackData.consumeFuel(jetpack, thrustCost);
            }
            Vec3 motion = player.getDeltaMovement();
            double newY = Math.max(motion.y, 0.0) + 0.18;
            if (newY > 0.85) {
                newY = 0.85;
            }
            Vec3 look = player.getLookAngle();
            player.setDeltaMovement(
                    motion.x * 0.95 + look.x * 0.05,
                    newY,
                    motion.z * 0.95 + look.z * 0.05);
            player.fallDistance = 0.0F;
            player.hasImpulse = true;
            player.setOnGround(false);
        } else if (airborne) {
            Vec3 motion = player.getDeltaMovement();
            if (motion.y < 0.0) {
                player.setDeltaMovement(motion.x, Math.max(motion.y * 0.92, -0.78), motion.z);
                player.fallDistance = 0.0F;
                player.hasImpulse = true;
            }
        }
    }

    private static void tickHover(Player player, ItemStack jetpack, boolean creative, int fuel) {
        int hoverCost = hoverFuelPerTick();
        boolean canFly = creative || fuel >= hoverCost;
        if (!canFly) {
            clearHover(player);
            if (isHoldingJump(player)) {
                warnNoFuel(player);
            }
            if (!player.onGround()) {
                Vec3 motion = player.getDeltaMovement();
                if (motion.y < 0.0) {
                    player.setDeltaMovement(motion.x, Math.max(motion.y * 0.92, -0.78), motion.z);
                    player.fallDistance = 0.0F;
                }
            }
            return;
        }

        boolean abilitiesChanged = grantHoverFlight(player);
        if (!player.getPersistentData().getBoolean(HOVER_FLAG)) {
            player.getPersistentData().putBoolean(HOVER_FLAG, true);
            abilitiesChanged = true;
        }

        if (isHoldingJump(player) && !player.getAbilities().flying) {
            player.getAbilities().flying = true;
            abilitiesChanged = true;
        }

        if (player.getAbilities().flying) {
            if (!creative && !player.level().isClientSide()) {
                JetpackData.consumeFuel(jetpack, hoverCost);
            }
            player.fallDistance = 0.0F;
        }

        if (abilitiesChanged) {
            player.onUpdateAbilities();
        }
    }

    private static void warnNoFuel(Player player) {
        if (player.level().isClientSide()) {
            return;
        }
        long gameTime = player.level().getGameTime();
        if (gameTime - player.getPersistentData().getLong(NO_FUEL_COOLDOWN) < 40) {
            return;
        }
        player.getPersistentData().putLong(NO_FUEL_COOLDOWN, gameTime);
        player.displayClientMessage(Component.translatable("createfreelymod.message.jetpack.no_fuel")
                .withStyle(ChatFormatting.RED), true);
    }

    public static void clearHover(Player player) {
        if (!player.getPersistentData().getBoolean(HOVER_FLAG)) {
            return;
        }
        player.getPersistentData().remove(HOVER_FLAG);
        revokeHoverFlight(player);
        if (!player.isCreative() && !player.isSpectator()) {
            player.getAbilities().flying = false;
            player.onUpdateAbilities();
        }
    }

    /** @return true if the creative-flight modifier was newly applied */
    private static boolean grantHoverFlight(Player player) {
        AttributeInstance flight = player.getAttribute(NeoForgeMod.CREATIVE_FLIGHT);
        if (flight != null && !flight.hasModifier(HOVER_FLIGHT_ID)) {
            flight.addOrUpdateTransientModifier(HOVER_FLIGHT_MODIFIER);
            return true;
        }
        return false;
    }

    private static void revokeHoverFlight(Player player) {
        AttributeInstance flight = player.getAttribute(NeoForgeMod.CREATIVE_FLIGHT);
        if (flight != null) {
            flight.removeModifier(HOVER_FLIGHT_ID);
        }
    }
}
