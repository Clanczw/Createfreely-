package com.clanczw.createfreelymod.content.energy;

import org.jetbrains.annotations.Nullable;

import com.clanczw.createfreelymod.config.CreateFreelyCommonConfig;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;

import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;

/**
 * FE 邻接传输工具。
 * <p>
 * 电容之间用均分推送（只向电量更低的邻居推），避免乒乓；
 * 发电机用强制推送，即使邻居存量高于自身缓存也会继续灌电。
 */
public final class EnergyTransfer {
    /** Cached to avoid {@link Direction#values()} allocating every tick. */
    public static final Direction[] DIRECTIONS = Direction.values();

    private EnergyTransfer() {
    }

    public static int maxPushPerSide() {
        return CreateFreelyCommonConfig.energyPushPerSide();
    }

    /** Capacitor-style equalizing push (downhill only). */
    public static boolean pushToNeighbors(Level level, BlockPos pos, IEnergyStorage source) {
        return pushToNeighbors(level, pos, source, null, null, true);
    }

    /**
     * @param equalizeOnly if true, only push when neighbor has less FE (capacitor balance).
     *                     if false, always push up to the per-side cap (generators).
     */
    public static boolean pushToNeighbors(
            Level level,
            BlockPos pos,
            IEnergyStorage source,
            @Nullable Direction exclude,
            @Nullable IntRefund refund,
            boolean equalizeOnly) {
        if (level == null || level.isClientSide || source == null || source.getEnergyStored() <= 0) {
            return false;
        }

        boolean moved = false;
        int pushCap = maxPushPerSide();
        int start = Math.floorMod(level.getGameTime() + pos.asLong(), DIRECTIONS.length);
        for (int i = 0; i < DIRECTIONS.length; i++) {
            Direction dir = DIRECTIONS[(start + i) % DIRECTIONS.length];
            if (dir == exclude || source.getEnergyStored() <= 0) {
                continue;
            }

            IEnergyStorage target = level.getCapability(
                    Capabilities.EnergyStorage.BLOCK,
                    pos.relative(dir),
                    dir.getOpposite());
            if (target == null || !target.canReceive() || target == source) {
                continue;
            }

            int ours = source.getEnergyStored();
            int want;
            if (equalizeOnly) {
                int theirs = target.getEnergyStored();
                if (theirs >= ours) {
                    continue;
                }
                want = Math.min(pushCap, (ours - theirs + 1) / 2);
            } else {
                want = Math.min(pushCap, ours);
            }
            if (want <= 0) {
                continue;
            }

            int canAccept = target.receiveEnergy(want, true);
            if (canAccept <= 0) {
                continue;
            }

            int extracted = source.extractEnergy(canAccept, false);
            int received = target.receiveEnergy(extracted, false);
            int leftover = extracted - received;
            if (leftover > 0) {
                if (refund != null) {
                    refund.accept(leftover);
                } else {
                    source.receiveEnergy(leftover, false);
                }
            }
            if (received > 0) {
                moved = true;
            }
        }
        return moved;
    }

    public static void feedNeighborsInfinite(Level level, BlockPos pos) {
        feedNeighborsInfinite(level, pos, CreateFreelyCommonConfig.creativeTransferRate());
    }

    public static void feedNeighborsInfinite(Level level, BlockPos pos, int rate) {
        if (level == null || level.isClientSide || rate <= 0) {
            return;
        }
        for (Direction dir : DIRECTIONS) {
            IEnergyStorage target = level.getCapability(
                    Capabilities.EnergyStorage.BLOCK,
                    pos.relative(dir),
                    dir.getOpposite());
            if (target == null || !target.canReceive()) {
                continue;
            }
            int accepted = target.receiveEnergy(rate, true);
            if (accepted > 0) {
                target.receiveEnergy(accepted, false);
            }
        }
    }

    @FunctionalInterface
    public interface IntRefund {
        void accept(int amount);
    }
}
