package com.clanczw.createfreelymod.compat.curios;

import com.clanczw.createfreelymod.ModItems;
import com.clanczw.createfreelymod.content.jetpack.FuelJetpackItem;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import top.theillusivec4.curios.api.CuriosApi;
import top.theillusivec4.curios.api.SlotContext;
import top.theillusivec4.curios.api.SlotResult;
import top.theillusivec4.curios.api.type.capability.ICurioItem;

/**
 * Curios 公共侧接入（仅在 Curios 已加载时由 {@link JetpackCurios#bootstrap} 加载）。
 * <p>
 * 数据包给玩家挂 preset {@code back} 槽，物品打上 {@code curios:back} 标签。
 */
public final class JetpackCuriosCompat {
    private JetpackCuriosCompat() {
    }

    public static void bootstrap(IEventBus modEventBus) {
        modEventBus.addListener(JetpackCuriosCompat::onCommonSetup);
    }

    public static ItemStack findJetpack(LivingEntity entity) {
        return CuriosApi.getCuriosInventory(entity)
                .flatMap(inv -> inv.findFirstCurio(FuelJetpackItem::isJetpack))
                .map(SlotResult::stack)
                .orElse(ItemStack.EMPTY);
    }

    private static void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> CuriosApi.registerCurio(ModItems.FUEL_JETPACK.get(), new FuelJetpackCurio()));
    }

    private static final class FuelJetpackCurio implements ICurioItem {
        @Override
        public boolean canEquipFromUse(SlotContext slotContext, ItemStack stack) {
            return true;
        }

        @Override
        public boolean canEquip(SlotContext slotContext, ItemStack stack) {
            return !FuelJetpackItem.isWornAsChest(slotContext.entity());
        }
    }
}
