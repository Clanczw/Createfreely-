package com.clanczw.createfreelymod.config;

import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * 通用/服务端平衡配置，生成文件：{@code config/createfreelymod-common.toml}。
 * <p>
 * 多数数值每个游戏刻都会读取（动能、FE、喷气背包等），改完保存后一般无需重启世界。
 * 电容方块的硬度、亮度等方块属性仍以注册时为准。
 */
public final class CreateFreelyCommonConfig {
    public static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();
    public static final ModConfigSpec SPEC;

    // --- Kinetics ---
    public static final ModConfigSpec.DoubleValue STRESS_SINK_IMPACT;
    public static final ModConfigSpec.IntValue STRESS_SINK_MIN_RPM;
    public static final ModConfigSpec.DoubleValue STRESS_SINK_FE_PER_RPM;
    public static final ModConfigSpec.IntValue STRESS_SINK_TIER2_RPM;
    public static final ModConfigSpec.IntValue STRESS_SINK_TIER3_RPM;
    public static final ModConfigSpec.DoubleValue STRESS_SINK_EFFICIENCY_TIER1;
    public static final ModConfigSpec.DoubleValue STRESS_SINK_EFFICIENCY_TIER2;
    public static final ModConfigSpec.DoubleValue STRESS_SINK_EFFICIENCY_TIER3;
    public static final ModConfigSpec.IntValue STRESS_SINK_ENERGY_CAPACITY;
    public static final ModConfigSpec.IntValue STRESS_SINK_DEPOT_CHARGE_PER_TICK;

    public static final ModConfigSpec.IntValue FE_MOTOR_MAX_RPM;
    public static final ModConfigSpec.IntValue FE_MOTOR_RPM_STEP;
    public static final ModConfigSpec.DoubleValue FE_MOTOR_STRESS_PER_RPM;
    public static final ModConfigSpec.DoubleValue FE_MOTOR_FE_PER_RPM;
    public static final ModConfigSpec.IntValue FE_MOTOR_ENERGY_CAPACITY;

    public static final ModConfigSpec.IntValue COAL_BOILER_GENERATED_RPM;
    public static final ModConfigSpec.IntValue COAL_BOILER_LAVA_RPM;
    public static final ModConfigSpec.IntValue COAL_BOILER_SUPER_FUEL_RPM;
    public static final ModConfigSpec.IntValue COAL_BOILER_SUPER_FUEL_BURN_TIME;
    public static final ModConfigSpec.DoubleValue COAL_BOILER_STRESS_PER_RPM;

    // --- Energy storage / transfer ---
    public static final ModConfigSpec.IntValue CAPACITOR_LOW_CAPACITY;
    public static final ModConfigSpec.IntValue CAPACITOR_MEDIUM_CAPACITY;
    public static final ModConfigSpec.IntValue CAPACITOR_HIGH_CAPACITY;
    public static final ModConfigSpec.IntValue CREATIVE_EMPTY_CAPACITY;
    public static final ModConfigSpec.IntValue CREATIVE_TRANSFER_RATE;
    public static final ModConfigSpec.IntValue ENERGY_PUSH_PER_SIDE;

    // --- Jetpack ---
    public static final ModConfigSpec.IntValue JETPACK_MAX_FUEL;
    public static final ModConfigSpec.IntValue JETPACK_THRUST_FUEL_PER_TICK;
    public static final ModConfigSpec.IntValue JETPACK_HOVER_FUEL_PER_TICK;

    // --- Fluid burner ---
    public static final ModConfigSpec.IntValue FLUID_BURNER_CAPACITY_MB;

    static {
        BUILDER.comment(
                        "============================================================",
                        " Create Freely Mod — 通用配置（服务端 + 客户端共用）",
                        " 文件：config/createfreelymod-common.toml",
                        " 也可在游戏内修改：模组列表 → Create Freely Mod → 配置",
                        " 多人游戏请以服务端这份为准。",
                        " 说明：方括号里的英文是配置键名，请勿改成中文。",
                        "============================================================")
                .push("kinetics");

        BUILDER.comment(
                        "【动能 ↔ 电力】SU 与 FE 互换",
                        "应力发电机实际 FE/t ≈ |转速RPM| × fePerRpm × 当前档位效率",
                        "一档 min～tier2：75%；二档 tier2～tier3：80%；三档 ≥tier3：85%",
                        "FE 电机耗电 FE/t ≈ 转速RPM × fePerRpm；应力容量 ≈ RPM × stressPerRpm")
                .push("stressSink");
        STRESS_SINK_IMPACT = BUILDER
                .comment(
                        "【应力冲击】倍率。实际应力 = 倍率 × |转速RPM|。",
                        "越大越难带动、也越“吃”应力网络。默认 64。")
                .defineInRange("stressImpact", 64.0D, 0.0D, 1024.0D);
        STRESS_SINK_MIN_RPM = BUILDER
                .comment(
                        "【最低转速 / 一档起点】|RPM| 低于此值时不发电。",
                        "默认 16：进入一档（至二档门槛前）效率见 efficiencyTier1。")
                .defineInRange("minRpm", 16, 1, 256);
        STRESS_SINK_FE_PER_RPM = BUILDER
                .comment(
                        "【发电系数】效率 100% 时，每 1 RPM 每刻产出的 FE。",
                        "例：1.875 × 256 × 0.85（三档）≈ 408 FE/t。")
                .defineInRange("fePerRpm", 1.875D, 0.0D, 1024.0D);
        STRESS_SINK_TIER2_RPM = BUILDER
                .comment(
                        "【二档门槛】|RPM| ≥ 此值进入二档（至三档门槛前）。",
                        "默认 64。应大于 minRpm。")
                .defineInRange("tier2Rpm", 64, 1, 256);
        STRESS_SINK_TIER3_RPM = BUILDER
                .comment(
                        "【三档门槛】|RPM| ≥ 此值进入三档（直到满速）。",
                        "默认 128。应大于 tier2Rpm。")
                .defineInRange("tier3Rpm", 128, 1, 256);
        STRESS_SINK_EFFICIENCY_TIER1 = BUILDER
                .comment(
                        "【一档效率】minRpm ≤ |RPM| < tier2Rpm 时的转换效率（0～1）。",
                        "默认 0.75（75%）。")
                .defineInRange("efficiencyTier1", 0.75D, 0.0D, 1.0D);
        STRESS_SINK_EFFICIENCY_TIER2 = BUILDER
                .comment(
                        "【二档效率】tier2Rpm ≤ |RPM| < tier3Rpm 时的转换效率（0～1）。",
                        "默认 0.80（80%）。")
                .defineInRange("efficiencyTier2", 0.80D, 0.0D, 1.0D);
        STRESS_SINK_EFFICIENCY_TIER3 = BUILDER
                .comment(
                        "【三档效率】|RPM| ≥ tier3Rpm 时的转换效率（0～1）。",
                        "默认 0.85（85%）。")
                .defineInRange("efficiencyTier3", 0.85D, 0.0D, 1.0D);
        STRESS_SINK_ENERGY_CAPACITY = BUILDER
                .comment(
                        "【内部缓存】应力发电机自身可暂存的 FE 上限。",
                        "下游电容/机器一时接不住时，先堆在这里。")
                .defineInRange("energyCapacity", 10_000, 1, Integer.MAX_VALUE);
        STRESS_SINK_DEPOT_CHARGE_PER_TICK = BUILDER
                .comment(
                        "【置物台充能】每刻最多给相邻容器里可充 FE 物品充多少电。",
                        "0 = 关闭该功能。")
                .defineInRange("depotChargePerTick", 2_048, 0, Integer.MAX_VALUE);
        BUILDER.pop();

        BUILDER.comment(
                        "【FE 电机】用电驱动 Create 传动轴",
                        "分档门槛与能效与上方 kinetics.stressSink 共用（方案 A）：",
                        "耗电 FE/t = RPM × fePerRpm ÷ 当前档效率；|RPM| < minRpm 时不出力。",
                        "一档÷0.75、二档÷0.80、三档÷0.85；应力容量仍为 RPM × stressPerRpm（不分档）。")
                .push("feMotor");
        FE_MOTOR_MAX_RPM = BUILDER
                .comment(
                        "【最高转速】电机轴能达到的最大 RPM（Create 上限通常 256）。")
                .defineInRange("maxRpm", 256, 1, 256);
        FE_MOTOR_RPM_STEP = BUILDER
                .comment(
                        "【升速步进】电量够时每次尝试提高多少 RPM。",
                        "1 = 最平滑；数值越大档位越粗、计算越少。默认 8。")
                .defineInRange("rpmStep", 8, 1, 256);
        FE_MOTOR_STRESS_PER_RPM = BUILDER
                .comment(
                        "【应力容量系数】应力容量 ≈ 当前RPM × 此值（不分档）。",
                        "64 × 256 ≈ 16384 SU（满速时可带动的应力规模）。")
                .defineInRange("stressPerRpm", 64.0D, 0.0D, 1024.0D);
        FE_MOTOR_FE_PER_RPM = BUILDER
                .comment(
                        "【基准耗电系数】理论耗电 = RPM × 此值，再除以当前档效率。",
                        "例：256 × 1.875 ÷ 0.85（三档）≈ 565 FE/t。")
                .defineInRange("fePerRpm", 1.875D, 0.0D, 1024.0D);
        FE_MOTOR_ENERGY_CAPACITY = BUILDER
                .comment(
                        "【内部缓存】电机自身可暂存的 FE 上限。")
                .defineInRange("energyCapacity", 10_000, 1, Integer.MAX_VALUE);
        BUILDER.pop();

        BUILDER.comment(
                        "【热力锅炉】熔炉燃料 → Create 动力（独立动能源，无需水罐/蒸汽引擎）",
                        "档位：普通燃料 / 岩浆桶（更强）/ 超级燃料桶（很强）。",
                        "燃烧中输出固定 RPM，应力容量 = 当前档 RPM × stressPerRpm。")
                .push("coalBoiler");
        COAL_BOILER_GENERATED_RPM = BUILDER
                .comment(
                        "【普通燃料转速】煤、木炭等熔炉燃料燃烧时的轴转速（RPM）。",
                        "默认 16，接近水车量级，偏早期动力。")
                .defineInRange("generatedRpm", 16, 1, 256);
        COAL_BOILER_LAVA_RPM = BUILDER
                .comment(
                        "【岩浆桶转速】比普通燃料更强。默认 32（约 2 倍）。")
                .defineInRange("lavaRpm", 32, 1, 256);
        COAL_BOILER_SUPER_FUEL_RPM = BUILDER
                .comment(
                        "【超级燃料转速】超级燃料桶燃烧时转速。默认 128，明显强于岩浆。")
                .defineInRange("superFuelRpm", 128, 1, 256);
        COAL_BOILER_SUPER_FUEL_BURN_TIME = BUILDER
                .comment(
                        "【超级燃料燃烧时长】超级燃料桶每次燃烧持续刻数。",
                        "默认 6400（约 5.3 分钟）。岩浆桶仍用原版熔炉燃烧时长。")
                .defineInRange("superFuelBurnTime", 6400, 20, 200_000);
        COAL_BOILER_STRESS_PER_RPM = BUILDER
                .comment(
                        "【应力容量系数】应力容量 ≈ 当前档 RPM × 此值。",
                        "例：普通 64×16=1024；岩浆 64×32=2048；超级 64×128=8192 SU。")
                .defineInRange("stressPerRpm", 64.0D, 0.0D, 1024.0D);
        BUILDER.pop();
        BUILDER.pop();

        BUILDER.comment(
                        "【电力存储】普通电容与创造电容",
                        "单位均为 FE（Forge Energy）。")
                .push("energy");
        CAPACITOR_LOW_CAPACITY = BUILDER
                .comment("【低级电容】最大储能（FE）。")
                .defineInRange("capacitorLowCapacity", 100_000, 1, Integer.MAX_VALUE);
        CAPACITOR_MEDIUM_CAPACITY = BUILDER
                .comment("【中级电容】最大储能（FE）。")
                .defineInRange("capacitorMediumCapacity", 1_000_000, 1, Integer.MAX_VALUE);
        CAPACITOR_HIGH_CAPACITY = BUILDER
                .comment("【高级电容】最大储能（FE）。")
                .defineInRange("capacitorHighCapacity", 4_000_000, 1, Integer.MAX_VALUE);
        CREATIVE_EMPTY_CAPACITY = BUILDER
                .comment(
                        "【创造空电容】缓冲容量（FE）。",
                        "可大量收放电，但不会凭空发电。勿超过 Integer 上限。")
                .defineInRange("creativeEmptyCapacity", 2_000_000_000, 1, Integer.MAX_VALUE);
        CREATIVE_TRANSFER_RATE = BUILDER
                .comment(
                        "【创造满电容】每次向外邻居输送的 FE 量级。",
                        "满电容视为无限电源，此值影响灌充速度。")
                .defineInRange("creativeTransferRate", 100_000, 1, Integer.MAX_VALUE);
        ENERGY_PUSH_PER_SIDE = BUILDER
                .comment(
                        "【均衡推送】电容/机器每面每刻向邻居最多推多少 FE。",
                        "用于相邻电容之间自动均压，过大可能导致瞬间抽空。")
                .defineInRange("pushPerSide", 100_000, 1, Integer.MAX_VALUE);
        BUILDER.pop();

        BUILDER.comment(
                        "【燃料喷气背包】燃料单位与桶体积对齐（mB，1000 = 一桶）")
                .push("jetpack");
        JETPACK_MAX_FUEL = BUILDER
                .comment(
                        "【油箱容量】单个喷气背包最多存多少燃料（mB）。",
                        "默认 16000 ≈ 16 桶超级燃料。")
                .defineInRange("maxFuel", 16_000, 1_000, Integer.MAX_VALUE);
        JETPACK_THRUST_FUEL_PER_TICK = BUILDER
                .comment(
                        "【喷气耗油】喷气模式下按住跳跃上升时，每刻消耗的燃料。",
                        "越大飞得越短；0 = 喷气几乎不耗油（不建议）。")
                .defineInRange("thrustFuelPerTick", 2, 0, 1_000);
        JETPACK_HOVER_FUEL_PER_TICK = BUILDER
                .comment(
                        "【悬停耗油】悬停模式下飞行时，每刻消耗的燃料。",
                        "通常应小于喷气耗油。0 = 悬停几乎不耗油（不建议）。")
                .defineInRange("hoverFuelPerTick", 1, 0, 1_000);
        BUILDER.pop();

        BUILDER.comment("【流体燃烧室】风扇气流用的流体槽")
                .push("fluidBurner");
        FLUID_BURNER_CAPACITY_MB = BUILDER
                .comment(
                        "【槽容量】可装多少流体（mB）。",
                        "1000 = 一桶。装水可洗涤；装岩浆/超级燃料可冶炼。")
                .defineInRange("capacityMb", 1_000, 1, 64_000);
        BUILDER.pop();

        SPEC = BUILDER.build();
    }

    private CreateFreelyCommonConfig() {
    }

    private static <T> T value(ModConfigSpec.ConfigValue<T> config) {
        return SPEC.isLoaded() ? config.get() : config.getDefault();
    }

    public static double stressSinkImpact() {
        return value(STRESS_SINK_IMPACT);
    }

    public static int stressSinkMinRpm() {
        return value(STRESS_SINK_MIN_RPM);
    }

    public static double stressSinkFePerRpm() {
        return value(STRESS_SINK_FE_PER_RPM);
    }

    public static int stressSinkTier2Rpm() {
        return value(STRESS_SINK_TIER2_RPM);
    }

    public static int stressSinkTier3Rpm() {
        return value(STRESS_SINK_TIER3_RPM);
    }

    /**
     * Efficiency for the current |RPM| band.
     * <ul>
     * <li>min ≤ rpm &lt; tier2 → tier1 (default 75%)</li>
     * <li>tier2 ≤ rpm &lt; tier3 → tier2 (default 80%)</li>
     * <li>rpm ≥ tier3 → tier3 (default 85%)</li>
     * <li>rpm &lt; min → 0</li>
     * </ul>
     */
    public static double stressSinkEfficiencyForRpm(float rpm) {
        float abs = Math.abs(rpm);
        int min = stressSinkMinRpm();
        if (abs < min) {
            return 0.0D;
        }
        int tier2 = Math.max(min + 1, stressSinkTier2Rpm());
        int tier3 = Math.max(tier2 + 1, stressSinkTier3Rpm());
        if (abs < tier2) {
            return value(STRESS_SINK_EFFICIENCY_TIER1);
        }
        if (abs < tier3) {
            return value(STRESS_SINK_EFFICIENCY_TIER2);
        }
        return value(STRESS_SINK_EFFICIENCY_TIER3);
    }

    public static int stressSinkEnergyCapacity() {
        return value(STRESS_SINK_ENERGY_CAPACITY);
    }

    public static int stressSinkDepotChargePerTick() {
        return value(STRESS_SINK_DEPOT_CHARGE_PER_TICK);
    }

    public static int feMotorMaxRpm() {
        return value(FE_MOTOR_MAX_RPM);
    }

    public static int feMotorRpmStep() {
        return Math.max(1, value(FE_MOTOR_RPM_STEP));
    }

    public static double feMotorStressPerRpm() {
        return value(FE_MOTOR_STRESS_PER_RPM);
    }

    public static double feMotorFePerRpm() {
        return value(FE_MOTOR_FE_PER_RPM);
    }

    public static int feMotorEnergyCapacity() {
        return value(FE_MOTOR_ENERGY_CAPACITY);
    }

    public static double feMotorMaxStressCapacity() {
        return feMotorMaxRpm() * feMotorStressPerRpm();
    }

    public static int coalBoilerGeneratedRpm() {
        return value(COAL_BOILER_GENERATED_RPM);
    }

    public static int coalBoilerLavaRpm() {
        return value(COAL_BOILER_LAVA_RPM);
    }

    public static int coalBoilerSuperFuelRpm() {
        return value(COAL_BOILER_SUPER_FUEL_RPM);
    }

    public static int coalBoilerSuperFuelBurnTime() {
        return value(COAL_BOILER_SUPER_FUEL_BURN_TIME);
    }

    public static double coalBoilerStressPerRpm() {
        return value(COAL_BOILER_STRESS_PER_RPM);
    }

    public static double coalBoilerMaxStressCapacity() {
        int maxRpm = Math.max(coalBoilerGeneratedRpm(),
                Math.max(coalBoilerLavaRpm(), coalBoilerSuperFuelRpm()));
        return maxRpm * coalBoilerStressPerRpm();
    }

    public static int capacitorLowCapacity() {
        return value(CAPACITOR_LOW_CAPACITY);
    }

    public static int capacitorMediumCapacity() {
        return value(CAPACITOR_MEDIUM_CAPACITY);
    }

    public static int capacitorHighCapacity() {
        return value(CAPACITOR_HIGH_CAPACITY);
    }

    public static int creativeEmptyCapacity() {
        return value(CREATIVE_EMPTY_CAPACITY);
    }

    public static int creativeTransferRate() {
        return value(CREATIVE_TRANSFER_RATE);
    }

    public static int energyPushPerSide() {
        return value(ENERGY_PUSH_PER_SIDE);
    }

    public static int jetpackMaxFuel() {
        return value(JETPACK_MAX_FUEL);
    }

    public static int jetpackThrustFuelPerTick() {
        return value(JETPACK_THRUST_FUEL_PER_TICK);
    }

    public static int jetpackHoverFuelPerTick() {
        return value(JETPACK_HOVER_FUEL_PER_TICK);
    }

    public static int fluidBurnerCapacityMb() {
        return value(FLUID_BURNER_CAPACITY_MB);
    }

    public static int stressSinkFePerTick(float rpm) {
        float abs = Math.abs(rpm);
        if (abs < stressSinkMinRpm()) {
            return 0;
        }
        double generated = abs * stressSinkFePerRpm() * stressSinkEfficiencyForRpm(abs);
        if (generated <= 0.0D || Double.isNaN(generated) || Double.isInfinite(generated)) {
            return 0;
        }
        return (int) Math.min(Integer.MAX_VALUE, Math.floor(generated));
    }

    /**
     * FE cost for running at the given RPM (scheme A).
     * <p>
     * Uses the same RPM bands / efficiencies as the Stress Generator:
     * {@code cost ≈ RPM × fePerRpm ÷ tierEfficiency}. Below min RPM → unaffordable.
     */
    public static int feMotorFeCostForRpm(int rpm) {
        if (rpm <= 0) {
            return 0;
        }
        if (rpm < stressSinkMinRpm()) {
            return Integer.MAX_VALUE;
        }
        double efficiency = stressSinkEfficiencyForRpm(rpm);
        if (efficiency <= 0.0D) {
            return Integer.MAX_VALUE;
        }
        double rate = feMotorFePerRpm();
        if (rate <= 0.0D) {
            return Integer.MAX_VALUE;
        }
        long cost = Math.round(rpm * rate / efficiency);
        if (cost <= 0L) {
            return 1;
        }
        return (int) Math.min(Integer.MAX_VALUE, cost);
    }

    /** Current FE→stress conversion efficiency for this RPM (0 if below min). */
    public static double feMotorEfficiencyForRpm(float rpm) {
        return stressSinkEfficiencyForRpm(rpm);
    }

    public static float feMotorStressForRpm(int rpm) {
        if (rpm <= 0 || rpm < stressSinkMinRpm()) {
            return 0.0F;
        }
        double stress = rpm * feMotorStressPerRpm();
        if (stress <= 0.0D || Double.isNaN(stress) || Double.isInfinite(stress)) {
            return 0.0F;
        }
        return (float) Math.min(stress, Float.MAX_VALUE);
    }
}
