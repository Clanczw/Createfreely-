package com.clanczw.createfreelymod.content.jetpack;

import com.clanczw.createfreelymod.CreateFreelyMod;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record ToggleJetpackModePayload() implements CustomPacketPayload {
    public static final Type<ToggleJetpackModePayload> TYPE = new Type<>(
            ResourceLocation.fromNamespaceAndPath(CreateFreelyMod.MOD_ID, "toggle_jetpack_mode"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ToggleJetpackModePayload> STREAM_CODEC =
            StreamCodec.unit(new ToggleJetpackModePayload());

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    static void handle(ToggleJetpackModePayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (!(context.player() instanceof ServerPlayer player)) {
                return;
            }
            ItemStack jetpack = FuelJetpackItem.getWorn(player);
            if (jetpack.isEmpty()) {
                return;
            }
            // Mode feedback is drawn next to the client HUD dial (not action bar).
            JetpackData.cycleMode(jetpack);
        });
    }
}
