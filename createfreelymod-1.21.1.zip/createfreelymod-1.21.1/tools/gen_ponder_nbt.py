"""Generate gzip structure NBTs for Create Freely ponder scenes."""
from __future__ import annotations

import gzip
import io
import pathlib

import nbtlib
from nbtlib import Byte, Compound, File, Int, List, String

OUT = pathlib.Path(
    r"d:\Mccode\curosrcc\createfreelymod-1.21.1\src\main\resources\assets\createfreelymod\ponder"
)
DATA_VERSION = 3955


def andesite_casing_base(size: int = 5) -> tuple[list, list]:
    """Single-layer square platform of andesite casing (y=0)."""
    palette = [Compound({"Name": String("create:andesite_casing")})]
    blocks = []
    for x in range(size):
        for z in range(size):
            blocks.append(
                Compound(
                    {
                        "pos": List[Int]([Int(x), Int(0), Int(z)]),
                        "state": Int(0),
                    }
                )
            )
    return palette, blocks


def add_block(palette: list, blocks: list, name: str, pos: tuple[int, int, int], props: dict | None = None):
    entry = Compound({"Name": String(name)})
    if props:
        entry["Properties"] = Compound({k: String(v) for k, v in props.items()})
    # reuse existing palette entry if identical
    idx = None
    for i, p in enumerate(palette):
        if dict(p) == dict(entry):
            idx = i
            break
    if idx is None:
        idx = len(palette)
        palette.append(entry)
    blocks.append(
        Compound(
            {
                "pos": List[Int]([Int(pos[0]), Int(pos[1]), Int(pos[2])]),
                "state": Int(idx),
            }
        )
    )


def write_structure(filename: str, size: tuple[int, int, int], palette: list, blocks: list):
    root = File(
        {
            "size": List[Int]([Int(size[0]), Int(size[1]), Int(size[2])]),
            "entities": List[Compound]([]),
            "blocks": List[Compound](blocks),
            "palette": List[Compound](palette),
            "DataVersion": Int(DATA_VERSION),
        }
    )
    # nbtlib writes uncompressed named compound; Minecraft structure is gzip of that
    buf = io.BytesIO()
    root.write(buf)
    raw = buf.getvalue()
    out = OUT / filename
    with gzip.GzipFile(filename="", mode="wb", fileobj=out.open("wb"), mtime=0) as gz:
        gz.write(raw)
    print("wrote", out, "bytes", out.stat().st_size)


def make_stress_sink():
    # 5x3x5: single-layer casing platform + shaft + stress_sink + capacitor
    palette, blocks = andesite_casing_base(5)
    add_block(palette, blocks, "create:shaft", (1, 1, 2), {"axis": "x", "waterlogged": "false"})
    add_block(palette, blocks, "createfreelymod:stress_sink", (2, 1, 2), {"facing": "west"})
    add_block(palette, blocks, "createfreelymod:capacitor_medium", (3, 1, 2))
    write_structure("stress_sink.nbt", (5, 3, 5), palette, blocks)


def make_fe_motor():
    # capacitor(west) + fe_motor(facing east, FE from back/west) + shaft(east)
    palette, blocks = andesite_casing_base(5)
    add_block(palette, blocks, "createfreelymod:capacitor_medium", (1, 1, 2))
    add_block(palette, blocks, "createfreelymod:fe_motor", (2, 1, 2), {"facing": "east"})
    add_block(palette, blocks, "create:shaft", (3, 1, 2), {"axis": "x", "waterlogged": "false"})
    write_structure("fe_motor.nbt", (5, 3, 5), palette, blocks)


def make_fluid_burner():
    palette, blocks = andesite_casing_base(5)
    add_block(palette, blocks, "createfreelymod:fluid_burner", (2, 1, 2))
    write_structure("fluid_burner.nbt", (5, 3, 5), palette, blocks)


def make_coal_boiler():
    # Front faces west; shaft / kinetic port is on the back (east).
    palette, blocks = andesite_casing_base(5)
    add_block(
        palette,
        blocks,
        "createfreelymod:coal_boiler",
        (2, 1, 2),
        {"facing": "west", "lit": "false"},
    )
    add_block(palette, blocks, "create:shaft", (3, 1, 2), {"axis": "x", "waterlogged": "false"})
    write_structure("coal_boiler.nbt", (5, 3, 5), palette, blocks)


def make_capacitor():
    palette, blocks = andesite_casing_base(5)
    add_block(palette, blocks, "createfreelymod:capacitor_low", (1, 1, 2))
    add_block(palette, blocks, "createfreelymod:capacitor_medium", (2, 1, 2))
    add_block(palette, blocks, "createfreelymod:capacitor_high", (3, 1, 2))
    write_structure("capacitor.nbt", (5, 3, 5), palette, blocks)


def make_fuel_jetpack():
    # Depot + spout above for Super Fuel drip-refuel demo
    palette, blocks = andesite_casing_base(5)
    add_block(palette, blocks, "create:depot", (2, 1, 2))
    add_block(palette, blocks, "create:spout", (2, 2, 2))
    write_structure("fuel_jetpack.nbt", (5, 3, 5), palette, blocks)


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    make_stress_sink()
    make_fe_motor()
    make_fluid_burner()
    make_coal_boiler()
    make_capacitor()
    make_fuel_jetpack()
